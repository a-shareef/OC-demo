@extends('layouts.plain')
   @section('style')

     <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
      <link rel="stylesheet" href="//cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css">

    @endsection
@section('body')
	<div class="container">
		@yield('content')
	</div>
@endsection

@section('breadcrumbs')
{!! Breadcrumbs::render('home') !!}
@endsection

@section('script')

 <!-- Included to make vible export button -->
<script src="//cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>

<script src="{{url('/')}}/assets/js/dashboard.js"></script>
<!-- <script src="{{url('/')}}/assets/js/manage_product.js"></script> -->
<script src="{{url('/')}}/assets/js/manage_template.js"></script>
<script src="{{url('/')}}/assets/js/manage_tagno.js"></script>
<script type="text/javascript">


  $('form').submit(function() {
  $(":submit").attr("disabled", true);
});
  $( ":input" ).focus(function() {
      $(":submit").attr("disabled", false);
  });

</script>
@endsection
