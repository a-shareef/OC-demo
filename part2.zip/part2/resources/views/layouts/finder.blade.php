   @extends('layouts.front')
   @section('style')
    <link href="{{url('/')}}/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
    
    <link href="{{url('/')}}/assets/css/common_rtl.css" rel="stylesheet">
 
    <meta name="csrf-token" content="{{ csrf_token() }}">
 @endsection
@section('body')
  <div class="container">
    @yield('content')
  </div>

@endsection
@section('script')
<script src="{{url('/')}}/assets/bootstrap/js/validator.js"></script>
<script src="{{url('/')}}/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="{{url('/')}}/assets/js/manage_tagno.js"></script>
 
 <script type="text/javascript">
 $(".alert").delay(10000).fadeOut();
 $(".alert-message").delay(10000).fadeOut();
</script>
@endsection