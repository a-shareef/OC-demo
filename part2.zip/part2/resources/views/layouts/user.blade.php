   @extends('layouts.plain')
   @section('style')
   @parent
    <link href="{{url('/')}}/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
    <link href="{{url('/')}}/assets/css/common.css" rel="stylesheet">
    <link rel="stylesheet" href="{{url('/')}}/assets/bootstrap/css/Jcrop.css">
    <link href="{{url('/')}}/assets/css/select2/select2.min.css" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
 @endsection
@section('body')
	<div class="container">
		@yield('content')
	</div>
@endsection
@section('script')
@parent
<script src="{{url('/')}}/assets/bootstrap/js/validator.js"></script>
<script src="{{url('/')}}/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="{{url('/')}}/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="{{url('/')}}/assets/js/manage_language.js"></script>
<script src="{{url('/')}}/assets/js/admin_product.js"></script>
<script src="{{url('/')}}/assets/js/user_language.js"></script>
<script src="{{url('/')}}/assets/js/admin_language.js"></script>
<script src="{{url('/')}}/assets/js/manage_product.js"></script>
<script src="{{url('/')}}/assets/bootstrap/js/select2.min.js"></script> 

<script type="text/javascript" src="{{url('/')}}/assets/bootstrap/js/Jcrop.min.js"></script>
<script type="text/javascript" src="{{url('/')}}/assets/js/piexif.js"></script>
<script type="text/javascript">


  $('form').submit(function() {
  $(":submit").attr("disabled", true);
});
  $( ":input" ).focus(function() {
      $(":submit").attr("disabled", false);
  });

</script>
@endsection
