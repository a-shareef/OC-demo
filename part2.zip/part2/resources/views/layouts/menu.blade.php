@php
    $arr = session('arr');
    $url_param = request()->route()->parameters;
    $url_pip = '';
    if(count($url_param) > 0){
    if(isset(request()->route()->parameters['user_id'])){
    $url_pip = request()->route()->parameters['user_id'];
    }else{
    $url_pip = userIdEncode(Auth::id());
    }
    }else{
    $url_pip = userIdEncode(Auth::id());
    }	

@endphp

<nav class="navbar-default navbar-static-side" role="navigation">
          <div class="sidebar-collapse" id="myNavbar">
            <ul class="nav metismenu" id="side-menu">  
        @if(hasrole() == 2)
            @if(session('back_role_id'))
                <li @if($pagePath == 'admin/dashboard') class="active dashIcon" @else class="dashIcon" @endif>
                    <a href="{{url('/')}}/user/backtoadmin">
                       <i class="fa fa-dashboard"></i><span class="nav-label">{{$languageTrans['admin_dashboard']}}</span>
                   </a>
               </li>
               @else
               <li @if($pagePath == 'admin/dashboard') class="active dashIcon" @else class="dashIcon" @endif>
                    <a href="{{url('/')}}/admin/dashboard">
                       <i class="fa fa-dashboard"></i><span class="nav-label">{{$languageTrans['admin_dashboard']}}</span>
                   </a>
               </li>
           @endif           
        @endif

        @if(hasrole() == 1)        
            @if(session('back_role_id'))
                <li @if($pagePath == 'admin/dashboard') class="active dashIcon" @else class="dashIcon" @endif>
                  <a href="{{url('/')}}/user/backtoadmin">
                      <i class="fa fa-dashboard"></i><span class="nav-label">{{$languageTrans['sadmin_dashboard']}}</span>
                  </a>
                </li>
            @else
                <li @if($pagePath == 'admin/dashboard') class="active dashIcon" @else class="dashIcon" @endif>
                  <a href="{{url('/')}}/admin/dashboard">
                      <i class="fa fa-dashboard"></i><span class="nav-label">{{$languageTrans['sadmin_dashboard']}}</span>
                  </a>
                </li>
            @endif
        @endif

        @if(hasrole() == 4)
        <li @if($pagePath == 'agents/dashboard') class="active dashIcon" @else class="dashIcon" @endif>
          <a href="{{url('/')}}/agents/dashboard">
             <i class="fa fa-dashboard"></i><span class="nav-label">{{$languageTrans['agent_dashboard']}}</span>
          </a>
        </li>
        @endif

        <li
        @if($pagePath == 'user/profile' || $pagePath == 'user/profile{user_id?}' || $pagePath == 'user/add'
        || $pagePath == 'user/csa/{userId}' || $pagePath == 'user/admin/{user_id}')

        class="active profileIcon" @else class="profileIcon" @endif>
        @if(empty(session('userId')))
        <a href="{{url('/')}}/user/profile">
          <i class="fa fa-user"></i>
                <span class="nav-label">{{$languageTrans['user_my_profile']}}</span>
        </a>
        @else
        <a href="{{url('/')}}/user/profile/{{session('userId')}}">
          <i class="fa fa-user"></i>
                <span class="nav-label">{{$languageTrans['user_my_profile']}}</span>
        </a>
        @endif
      </li>

      @if((session('userId')) || (isset($arr) && in_array("FT Product", $arr)))

    
      <li @if($pagePath == 'admin/product/user/{user_id}' || $pagePath == 'admin/product/usersproduct/{user_id}') class="active manageProductIcon"
      @else class="manageProductIcon" @endif>
      <a href="{{url('/')}}/admin/product/usersproduct/{{session('userId')}}">
        <i class="fa fa-files-o"></i>
                   <span class="nav-label">FT Product</span>
      </a>
    </li>

    @elseif(hasrole() == 2 || hasrole() == 1)

    <li @if($pagePath == 'admin/manage-email') class="active manageEmailIcon"
    @else class="manageEmailIcon" @endif>
    <a href="{{url('/')}}/admin/manage-email">
      <i class="fa fa-envelope"></i>
                <span class="nav-label">{{$languageTrans['admin_email_template']}}</span>
    </a>
  </li>

<li @if($pagePath == 'admin/product') class="active manageMasterProductIcon"
  @else class="manageMasterProductIcon" @endif>
  <a href="{{url('/')}}/admin/product">
   <i class="fa fa-files-o"></i>
                 <span class="nav-label">Setup FT Product</span>
 </a>
</li>

 <li @if($pagePath == 'user/productDetails') class="active manageMasterProductIcon"
  @else class="manageMasterProductIcon" @endif>
  <a href="{{url('/')}}/user/productDetails">
   <i class="fa fa-files-o"></i>
                 <span class="nav-label">FT Lookup Tool</span>
 </a>
</li> 

@if(hasrole() == 1)

<li @if($pagePath == 'admin/manageproduct/{product_id?}' || $pagePath == 'admin/manageproduct') class="active manageProductIcon"
@else class="manageProductIcon" @endif>
<a href="{{url('/')}}/admin/manageproduct">
 <i class="fa fa-files-o"></i>
                 <span class="nav-label">Manage FT Products</span>
</a>
</li>

<li @if($pagePath == 'user/site-config') class="active confIcon" @else class="confIcon" @endif>
  <a href="{{url('/')}}/user/site-config">
    <i class="fa fa-cogs"></i>
                <span class="nav-label">{{$languageTrans['site_configuration']}}</span>
  </a>
</li>
<li @if($pagePath == 'admin/reports') class="active reportIcon" @else class="reportIcon" @endif>
 <a href="/admin/reports">
   <i class="fa fa-file-text-o"></i>
                <span class="nav-label">Reports</span>
 </a>
</li>
@endif
@endif
@if(empty(session('userId')) && hasrole() == 4)
<li @if($pagePath == 'admin/manageproduct/{product_id?}' || $pagePath == 'admin/manageproduct') class="active manageMasterProductIcon"
@else class="manageMasterProductIcon" @endif>
<a href="{{url('/')}}/admin/manageproduct">
<i class="fa fa-files-o"></i>
                 <span class="nav-label">Manage FT Products</span>
</a>
</li>
@endif
<li @if("/".$pagePath == '/trainingvideos') class="active videoIcon" @else class="videoIcon" @endif>
<a href="/trainingvideos">
    <i class="fa fa-video-camera"></i>
                <span class="nav-label">Training Videos</span>
  </a>
</li>

@if(hasrole() == 1 || hasrole() == 4)
<li class="linkIcon">
  <a href="/direct/profile/{{$url_pip}}/{{userIdEncode('PIP')}}">
    <i class="fa fa-link"></i>
                <span class="nav-label">UberID PIP</span>
  </a>
</li>
@endif

@if((isset($arr) && in_array("Shop", $arr)) || session('userId'))
<li class="shopIcon">
  <a href="http://www.uberid.com/foundthemshop" target="_BLANK">
   <i class="fa fa-shopping-cart"></i>
                   <span class="nav-label">{{$languageTrans['user_shop']}}</span>
 </a>
</li>
@if(Auth::user()->client_flag == 3 && (hasrole() == 3 || hasrole() == 5 || hasrole() == 6))
<li class="linkIcon">
  <a href="/direct/profile/{{$url_pip}}/{{userIdEncode('PIP')}}">
    <i class="fa fa-link"></i>
                <span class="nav-label">UberID PIP</span>
  </a>
</li>
@endif
@endif
<li class="logIcon">
  <a href="{{url('/')}}/auth/logout">
    <i class="fa fa-sign-out"></i>
                  <span class="nav-label">{{$languageTrans['user_logout']}}</span>
  </a>
</li>

</ul>
</div>
</nav>
