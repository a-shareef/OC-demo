<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
	<meta charset="utf-8"/>
	<title>UberID FT - @yield('title')</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport"/>
	<meta content="" name="description"/>
	<meta content="" name="author"/>
  <meta name="csrf_token" content="{{ csrf_token() }}">
  <link rel="shortcut icon" type="image/png" href="{{url('/')}}/assets/images/UberID-Favicon.png"/>
<link href="{{url('/')}}/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="{{url('/')}}/assets/css/jquery.tokenize.css">
<link href="{{url('/')}}/assets/bootstrap/css/style.css" rel="stylesheet">
<link href="{{url('/')}}/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/style.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/responsive.css" rel="stylesheet">
<link href="{{url('/')}}/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.css"/>
      @yield('style')
</head>
<body class="fixed-nav fixed-sidebar pace-done">
<div id="wrapper" class="">
  @php $languageTrans = languageTranslate("Menu") @endphp
  @php $pagePath = \Request::path(); @endphp
  @if(!session('userId') &&  (hasrole() == 3 || hasrole() == 5 || hasrole() == 6) )
    @php \Request::session()->put('userId', userIdEncode(\Auth::id())) @endphp
  @endif
  @include('layouts.menu')

  <div id="page-wrapper" class="gray-bg">
    <div class="row border-bottom">
      <nav class="navbar white-bg navbar-fixed-top" role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
            <a class="logo" href="{{env('LOGOURL')}}" target="_blank"><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a>
            <div class="slogan">{{siteSlogan()}}</div>
          </div>
        <ul class="nav navbar-top-links navbar-right">
          <li class="hidden-xs"> <a @if(session('back_role_id')) href="{{url('/')}}/user/backtoadmin" @else href="{{url('/')}}/auth/logout" @endif class="btn btn-primary"> <i class="fa fa-sign-out"></i>{{$languageTrans['user_logout']}} </a> </li>
          <li><a class="navbar-minimalize minimalize-styl-2 btn btn-primary hidden visible-xs" href="#"><i class="fa fa-bars"></i></a></li>
        </ul>
      </nav>
    </div>
  @yield('breadcrumbs')
      <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight">@yield('content')</div>

      <div class="footer">
      	<p class="col-xs-7 text-left">
         &#169; {{ date('Y')}} UberID, LLC. All Rights Reserved. </p>
      	<p class="col-xs-5 text-right">
          Powered by UberID. (Build 1.1.5.7)‎&#x200E;
        </p>
      </div>
  </div>
</div>
</body>
<footer>
<script src="{{url('/')}}/assets/js/GoogleAnalytics.js"></script>
<script src="{{url('/')}}/assets/js/jquery-1.10.2.min.js"></script>
  <script type="text/javascript" src="{{url('/')}}/assets/bootstrap/js/Jcrop.min.js"></script>
  <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="{{url('/')}}/assets/js/metisMenu/jquery.metisMenu.js"></script>
  <script src="{{url('/')}}/assets/js/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="{{url('/')}}/assets/js/iCheck/icheck.min.js"></script>
  <script src="{{url('/')}}/assets/js/switchery/switchery.js"></script>
  <script src="{{url('/')}}/assets/js/dataTables/datatables.min.js"></script>
  <script src="{{url('/')}}/assets/js/inspinia.js"></script>
  <script src="{{url('/')}}/assets/js/manage_product.js"></script>
  <script src="{{url('/')}}/assets/js/pace/pace.min.js"></script>
  <script src="/assets/bootstrap/js/moment-with-locales.js"></script>
  <script src="/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
  <script src="{{url('/')}}/assets/bootstrap/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.js"></script>
<script src="{{url('/')}}/assets/js/jquery.tokenize.js"></script>
@yield('script')
<script type="text/javascript">
 $(".alert").delay(2000).fadeOut();
 $(".alert-message").delay(4000).fadeOut();
 $(".external").click(function(event) {
   var confirmation = confirm("Are you sure you want to leave this page? Content will open in a new window");
   if (!confirmation) {
     event.preventDefault();
   }
 });
</script>

<script type="text/javascript">

  $('form').submit(function() {
  $(":submit").attr("disabled", true);
});
  $( ":input" ).focus(function() {
      $(":submit").attr("disabled", false);
  });
  
  // $(window).load(function() {
  //     $('.tooltip-demo1').tooltip({
  //     selector: "[data-toggle=tooltip]",
  //     container: "body"
  // });
  //   });
</script>
</footer>
</html>
