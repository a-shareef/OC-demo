@extends('layouts.plain')   
<link rel="stylesheet" type="text/css" media="screen" href="{{url('/')}}/assets/css/jquery-ui.css" />   
@section('body')
    <div class="container">
        @yield('content')
    </div>
@endsection
 
@section('script')
<script src="{{url('/')}}/assets/js/jquery.min.js"></script> 
{{-- <script src="{{url('/')}}/assets/js/datepicker/jquery-ui.min.js"></script> --}}
<script src="{{url('/')}}/assets/js/highstock.js"></script>
<script src="{{url('/')}}/assets/js/exporting.js"></script>    
<script src="{{url('/')}}/assets/js/ftunitschart.js"></script>
<script src="{{url('/')}}/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="{{url('/')}}/assets/js/chartValidation.js"></script>
<script src="{{url('/')}}/assets/js/metisMenu/jquery.metisMenu.js"></script>
@endsection