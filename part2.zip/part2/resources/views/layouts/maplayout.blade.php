@extends('layouts.plain')
@section('body')
    <div class="container">
        @yield('content')
    </div>
@endsection

@section('script')
<script src="{{url('/')}}/assets/js/map/jquery-3.1.1.min.js"></script> 
<script src="{{url('/')}}/assets/js/map/highmaps.js"></script>
<script src="{{url('/')}}/assets/js/map/data.js"></script>    
<script src="{{url('/')}}/assets/js/map/world.js"></script>
<script src="{{url('/')}}/assets/js/map/mapchart.js"></script>
<script src="{{url('/')}}/assets/js/metisMenu/jquery.metisMenu.js"></script>
@endsection

