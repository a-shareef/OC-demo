<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8"/>
<title>UberID FT - @yield('title')</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<meta content="" name="description"/>
<meta content="" name="author"/>
<meta name="csrf_token" content="{{ csrf_token() }}">
<link rel="shortcut icon" type="image/png" href="/assets/images/UberID-Favicon.png"/>
@if (getLtrRtl() == 1)
<link rel="shortcut icon" type="image/png" href="{{url('/')}}/assets/images/UberID-Favicon.png"/>
<link href="{{url('/')}}/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="{{url('/')}}/assets/bootstrap/css/style.css" rel="stylesheet">
<link href="{{url('/')}}/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/footable.core.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/select2/select2.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/style.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/responsive.css" rel="stylesheet">
<link href="{{url('/')}}/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
@else
<link href="{{url('/')}}/assets/bootstrap/css/bootstrap_rtl.min.css" rel="stylesheet" id="bootstrap-css">
<link href="{{url('/')}}/assets/bootstrap/css/style_rtl.css" rel="stylesheet">
<link href="{{url('/')}}/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/footable.core.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/select2/select2.min_rtl.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/style_rtl.css" rel="stylesheet">
<link href="{{url('/')}}/assets/css/responsive_rtl.css" rel="stylesheet">
@endif
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.css"/>
@yield('style')
</head>
<body class="fixed-nav fixed-sidebar pace-done">
<div id="wrapper" class="mainBox">
  <div id="page-wrapper" class="gray-bg page-wrapper2">
    <div class="row">
      <nav class="navbar white-bg navbar-fixed-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header"> <a class="logo" href="{{url('/')}}" ><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a>
          <div class="slogan">{{siteSlogan()}}</div>
        </div>
        <?php $currentRoutes = Route::currentRouteName();?>
        @if($currentRoutes == 'finderfront')
        <ul class="nav navbar-top-links navbar-right">
          <li>
            <form id="languageForm" method=@if(getAuthData()) "POST" @else "GET" @endif
              action=@if(getAuthData()) "/user/language-change" @else "/frontUser/language-change" @endif>
            {!! csrf_field() !!}
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 input-group">
                <select onchange="langChange()" id="language" name="language" class="select2_demo_1 form-control" required >
                  
                  
                  
                
                    @foreach(getLanguages() as $lang)
                      
                
                  
                  
                  <option value="{{$lang->language_id}}"
                        @if(getAuthenticateUserLanguage() == $lang->language_id)
                  selected="selected" @endif >
                  {{$lang->language_name}} </option>
                  
                  
                  
                
                    @endforeach
                  
              
                
                
                </select>
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger">{{$errors->first('language')}}</div>
              </div>
            </div>
            </form>
          </li>
        </ul>
        @endif </nav>
    </div>
    <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight">@yield('content')</div>
    <div class="footer">
      <p class="col-xs-7 text-left"> &#169; {{ date('Y')}} UberID, LLC. All Rights Reserved. </p>
      <p class="col-xs-5 text-right"> Powered by UberID. (Build 1.1.5.6)‎&#x200E; </p>
    </div>
  </div>
</div>
</body>
<footer>
  <script src="{{url('/')}}/assets/js/jquery-1.10.2.min.js"></script>
  <script src="{{url('/')}}/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="{{url('/')}}/assets/js/GoogleAnalytics.js"></script>
  <script type="text/javascript" src="{{url('/')}}/assets/bootstrap/js/Jcrop.min.js"></script>
  <script src="{{url('/')}}/assets/js/metisMenu/jquery.metisMenu.js"></script>
  <script src="{{url('/')}}/assets/js/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="{{url('/')}}/assets/js/iCheck/icheck.min.js"></script>
  <script src="{{url('/')}}/assets/js/switchery/switchery.js"></script>
  <script src="{{url('/')}}/assets/js/dataTables/datatables.min.js"></script>
  <script src="{{url('/')}}/assets/js/select2/select2.full.min.js"></script>
  <script src="{{url('/')}}/assets/js/inspinia.js"></script>
  <script src="{{url('/')}}/assets/js/pace/pace.min.js"></script>
  @if(empty(session('locationData')))
  <script src="{{url('/')}}/assets/js/geolocation.js"></script>
  @endif
  <script src="{{url('/')}}/assets/bootstrap/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.js"></script>
  <script type="text/javascript">
function langChange(){
   $( "#languageForm" ).submit();
}

</script>
  <script>
            $(document).ready(function () {
            $(".select2_demo_1").select2();
            
            if ($('.userhistorydata').html()) {
                $('.userhistorydata').DataTable({
                    "paging": false,
                    "ordering": false,
                    "info": false,
                    "searching": false,
                }); //user datatable initialized
            }
           
            });
			
        </script>
  @yield('script')</footer>
</html>
