<!-- resources/views/user/profile.blade.php -->

@extends('layouts.auth')
@section('title', 'User Profile')
@section('style')
@parent
<link href="{{url('/')}}/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
<link href="{{url('/')}}/assets/css/common.css" rel="stylesheet">
<meta name="csrf-token" content="{{ csrf_token() }}">
@endsection
@section('content')

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
<form id="userRegisterForm"  class="regTabsForm form-horizontal" data-toggle="validator" method="POST" action="{{route('register_users')}}" role="form" style="display: block;">
  {!! csrf_field() !!}
  <h2>Register User</h2>
  <div class="form-group">
    <div class="col-sm-12 text-center asterisk_notice_text"><span class="asterisk_notice text-center">(* Fields marked as mandatory)</span></div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="user_title"> {{$transLanguage['edit_title']}}: </label>
    <div class=" col-sm-7">
      <select required id="user_title" name="user_title" class="form-control" >
        <option value="">Select  {{$transLanguage['edit_title']}}</option>
        
          
          
      @foreach($titleArray as $title)
      
          
          
        <option  value="{{$title}}"
      @if(old('user_title') == $title)
      selected="selected" @endif> {{$title}} </option>
        
          
          
    @endforeach
  
        
        
      </select>
      <div class="alert-message alert-warning">{{$errors->first('user_title')}}</div>
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="firstname"> {{$transLanguage['edit_first_name']}}: </label>
    <div class=" col-sm-7">
      <input id="firstname" name="firstname" type="text" placeholder="{{$transLanguage['edit_first_name']}}"
    class="form-control input-md" pattern="[^0-9]*"  required=""
    value="{{ old('firstname')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('firstname')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="lastname"> {{$transLanguage['edit_last_name']}}: </label>
    <div class=" col-sm-7">
      <input id="lastname" name="lastname" type="text" placeholder="{{$transLanguage['edit_last_name']}}"
    class="form-control input-md" pattern="[^0-9]*" required=""
    value="{{ old('lastname')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('lastname')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="email"> {{$transLanguage['edit_email']}}: </label>
    <div class=" col-sm-7">
      <input id="email" readonly name="email"  type="email" placeholder="{{$transLanguage['edit_email']}}"
  class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
  required value="{{ $email }}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('email')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="country_code"> {{$transLanguage['edit_country_code']}}: </label>
    <div class="col-sm-7">
      <div class="input-group">          
        <input id="countrys_code" type="hidden" value="{{ old('country_code') }}"> 
        <span class="input-group-addon" id="ccPlus">+</span>
        <span class="input-group-addon" id="ccdid" type="text" style="display:none"></span>
        <select required id="country_code" name="country_code" class="form-control country_code_common" required>
            <option value="">Country Code</option>            
            @if(isset($countryArray))
                @foreach($countryArray as $countryArrays)                            
                    <option data-ccdid="{{$countryArrays->id}}" value="{{$countryArrays->countryId}}" 
                @if(old('country_code') == $countryArrays->countryId) selected="selected" @endif >
                       {{$countryArrays->text}} - +{{$countryArrays->id}} 
                    </option>
                @endforeach
            @endif
        </select>
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        <div class="alert-message alert-danger">{{$errors->first('country_code')}}</div>
         </div>
        @if(isset($countryArray))
            <div id="countryCo"  data-field-id="{{json_encode($countryArray)}}"></div>
        @endif
        <span class="profile_asterik">*</span></div>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="form-group">
      <label class="col-sm-3 control-label" for="phone"> {{$transLanguage['edit_phone']}}: </label>
    <div class="col-sm-7">
      <input id="phone" name="phone" pattern="^\D*(?:\d\D*){10}" type="tel"
    placeholder="{{$transLanguage['edit_phone']}}"
    class="form-control input-md" required=""
    value="{{ old('phone')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('phone')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div id="optional_data">
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address1"> {{$transLanguage['edit_address_1']}}: </label>
    <div class=" col-sm-7">
      <input id="address1" name="address1" type="text" placeholder="{{$transLanguage['edit_address_1']}}"
      class="form-control input-md"
      value="{{ old('address1')}}">
      <div class="alert-message alert-danger">{{$errors->first('address1')}}</div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address2"> {{$transLanguage['edit_address_2']}}: </label>
    <div class=" col-sm-7">
      <input id="address2" name="address2" type="text" placeholder="{{$transLanguage['edit_address_2']}}"
      class="form-control input-md"
      value="{{ old('address2')}}">
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address3"> {{$transLanguage['edit_address_3']}}: </label>
    <div class=" col-sm-7">
      <input id="address3" name="address3" type="text" placeholder="{{$transLanguage['edit_address_3']}}"
      class="form-control input-md"
      value="{{ old('address3')}}">
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="city"> {{$transLanguage['edit_city']}}: </label>
    <div class=" col-sm-7">
      <input id="city" name="city" type="text" placeholder="{{$transLanguage['edit_city']}}"
        class="form-control input-md" required="" pattern="[A-z ]+$"
        value="{{ old('city')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span>
      <div class="alert-message alert-danger">{{$errors->first('city')}}</div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="state"> {{$transLanguage['edit_state_province']}}: </label>
    <div class="col-sm-7">
      <input id="state" name="state" type="text" placeholder="{{$transLanguage['edit_state_province']}}"
        class="form-control input-md" required="" pattern="[A-z ]+$"
        value="{{ old('state')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('state')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="country"> {{$transLanguage['edit_country']}}: </label>
    <div class="col-sm-7">
      <select required id="country" name="country" class="form-control">
        <option value="">Select {{$transLanguage['edit_country']}}</option>
        
            
            
          @foreach($countries as $country)
          
            
            
        <option value="{{$country->country_code}}"
            @if((old('country')) == $country->country_code)
        selected="selected"
        @endif >
        {{$country->country_name}} </option>
        
            
            
          @endforeach
        
          
          
      </select>
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span>
      <div class="alert-message alert-danger">{{$errors->first('country')}}</div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="zip"> {{$transLanguage['edit_zip_postcode']}}: </label>
    <div class="col-sm-7">
      <input id="zip" name="zip" type="text" placeholder="{{$transLanguage['edit_zip_postcode']}}"
        class="form-control input-md" required="" style="text-transform:uppercase"
        value="{{ old('zip')}}">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('zip')}}</div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="user_title"> {{$transLanguage['edit_date_format']}}: </label>
    <div class=" col-sm-7">
      <select id="date_format" name="date_format" class="form-control" >
        
          
          
              @foreach($dateArray as $key => $date)
              
          
          
        <option  value="{{$key}}"
              @if((old('date_format')) == $key)
              selected="selected" @endif> {{$date}} </option>
        
          
          
              @endforeach
            
        
        
      </select>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="dob"> {{$transLanguage['edit_date_of_birth']}}: </label>
    <div class=" col-sm-7">
      <div class="input-group date" id="date_of_birth">
        <input id="dob" name="dob" type="text" placeholder=" {{$transLanguage['edit_date_of_birth']}}"
          class="form-control input-md" required
          value="">
        <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span>
        <div class="alert-message alert-danger">{{$errors->first('dob')}}</div>
         </div><span class="profile_asterik">*</span>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="agree"></label>
    <div class=" col-sm-7 terms_policy">
      <input required type="checkbox" name="agree" id="agreecheckbox" value="agree" class="switch js-switch_1" />
      I have read and agree to the <a target="_blank" href="https://www.uberid.com/terms-of-service">Terms of Service</a> and <a target="_blank" href="https://www.uberid.com/privacy-policy">Privacy Policy</a> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Button -->
  <div class="form-group">
    <div class=" col-xs-12 text-center">
  <div class="loader2"></div>
  </div></div>
  <div class="form-group">
    <div class=" col-xs-12 text-center">
      <input class="btn btn-primary" type="button" id="regFormBack" value="Back">
      <button id="profile_submit" name="profile_submit"
          class="btn btn-primary"> {{$transLanguage['edit_submit']}} </button>
      <input class="btn btn-primary" type="reset" id="reset" value="{{$transLanguage['edit_reset']}}">
    </div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
  </div>
  <!--   -->
  <input type="hidden" id="token" value="{{ csrf_token() }}">
  <input type="hidden" id="tagno" name="tagno" value="{{$tagno}}">
  <input type="hidden" id="lastTInsertIdT" name="lastTInsertIdT" value="{{$lastTInsertIdT}}">
  <input type="hidden" name="package_id" id="package_id" value="10" >
  <input type="hidden" name="package" value="P" />
  <input type="hidden" name="roleId" id="roleId" value="3" >
</form>
@endsection
@section('style')  
    @parent 
    <link href="{{url('/')}}/assets/css/select2/select2.min.css" rel="stylesheet">
@endsection
@section('script')
@parent 

<script src="{{url('/')}}/assets/bootstrap/js/validator.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/bootstrap-datetimepicker.js"></script> 
<script src="{{url('/')}}/assets/js/profile.js"></script> 
<script src="{{url('/')}}/assets/js/select2/select2.full.min.js"></script>
<script src="{{url('/')}}/assets/js/countryCode.js"></script> 
<script type="text/javascript">
   $("#profile_submit").prop('disabled',false);
  $('#agreecheckbox').change(function(){

    if($(this).prop("checked") == true){
      
      $("#profile_submit").removeClass('disabled');
      $("#profile_submit").prop('disabled',false);
    }
    else if($(this).prop("checked") == false){

      // $("#profile_submit").addClass('disabled');
      $("#profile_submit").prop('disabled',true);

    }
  });
  $("#reset").click(function(){

    var haserrclass = $( ".form-group" ).hasClass( "has-error" );
    var hassucclass = $( ".form-group" ).hasClass( "has-success" );
    
    if(haserrclass){
      $( ".form-group" ).removeClass( "has-error" );   
    }
    if(hassucclass){
      $( ".form-group" ).removeClass( "has-success" );   
    }

    var spanerr = $( ".glyphicon" ).hasClass( "glyphicon-remove" );
    var spanscc = $( ".glyphicon" ).hasClass( "glyphicon-ok" );

    if(spanerr){
     $( ".glyphicon" ).removeClass( "glyphicon-remove" );  
   }
   if(spanscc){
     $( ".glyphicon" ).removeClass( "glyphicon-ok" );  
   }
   
    $("#profile_submit").addClass('disabled');
  });
</script> 
@endsection 