<!-- resources/views/auth/password.blade.php -->

@extends('layouts.auth')
@section('title', 'Product Register')
@section('style')
@section('content')
<div id="page-wrapper" class="gray-bg page-wrapper2">
  <div class="row">
    <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
      <div class="navbar-header"> <a class="logo" href="{{url('/')}}" ><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a></a></div>
      <ul class="nav navbar-top-links navbar-right">
        <li></li>
      </ul>
    </nav>
  </div>
  <div id="wrapper">
    <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight wrapper2-content">
      <div class="container">
      <div class="row">
      	<div class="col-md-8 col-md-offset-2">

        <div class="ibox">
          <div class="ibox-title">
            <h5>FT Product Registration</h5>
          </div>
          <div class="ibox-content"> {!! csrf_field() !!}
            @if (session('status')) 
            <!-- <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> -->
            <div>
              <p class="msgBannerTxt"> {{ session('status') }} 
                <!-- </div> --> 
              </p>
            </div>
            @endif
            @if(session('error'))
            <div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
            @endif
            <div class="row">
              <div class="col-md-12 col-sm-12 col-sx-12 text-center"> @if (session('screenName') == 'existingUser') <a href="/auth/login" class="btn btn-primary successLoginBtn" id="productemailBtn" type="button">Login</a> @else <a href="{{env('FOUNDTHEM_URL')}}" target="_blank" class="btn btn-primary successLoginBtn" id="foundtbtn" >FoundThem™</a> @endif </div>
            </div>
          </div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection 