@extends('layouts.plain')
@section('title', 'List of Roles')
@section('content')

<div class="container">
	@if (session('error'))
	<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
		<div>
			{{ session('error') }}
		</div>
	</div>
	@endif
	@if (session('success'))
	<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
		<div>
			{{ session('success') }}
		</div>
	</div>
	@endif
</div>
<div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>List of Videos</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
<div class="list_of_videos">

@foreach($listOfVideos as $key => $value)

<ul class="metismenu videoList" id="side-menu">
                <li><a href="/videoplayer?page={{$key+1}}"><i class="fa fa-video-camera" aria-hidden="true"></i> <span>{{$value->title}}</span></a></li>
                </ul>
@endforeach
</div>


@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/listofvideos/') !!}
@endsection
