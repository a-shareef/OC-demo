@extends('layouts.user')
@section('title', 'FT Products')
@section('content')

<!-- Form Name -->
@if(Session::has('alert-success'))
<div class="alert alert-success">
  <p>{{ Session::get('alert-success') }}</p>
</div>
@endif
<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Setup FT Product</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">
<a href="{{url('/')}}/admin/product/add" class="btn btn-primary btn-xs pull-right"><i class="fa fa-plus" aria-hidden="true"></i> {{ $getTranslatedLang['manage_id_products_add_new_product'] }} </a>
  <div class="table-responsive">
    <table cellspacing="0" cellpadding="0" border="0" width="100%"
 class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer responsive" id="productDisplay">
      <thead>
        <tr>
          <th data-priority="1">{{ $getTranslatedLang['manage_id_products_products'] }}</th>
          <th>Product Initials</th>
          <th>{{ $getTranslatedLang['manage_id_products_description'] }}</th>
          <th data-priority="2">Action</th>
        </tr>
      </thead>
      <tbody>

      @foreach($getProductList as $product)
      <tr>
        <td>{{ $product->product_name }}</td>
        <td>{{ $product->product_initials }}</td>
        <td>{{ $product->product_description }}</td>
        <input type="hidden" value="{{$product->id}}" id="id"/>

        <td><span class="tooltip-demo">
          @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Edit') == true))
          <a href="{{url('/')}}/admin/product/edit/{{$product->id}}"
                      class="btn btn-primary" data-toggle = "tooltip" data-placement = "top"
     title = "Edit Product"> <i class="fa fa-pencil"></i></a>
          @endif
          <form id="form-delete-product"  name="delete-product"
                     class="form-delete-product" data-toggle="validator"
                     method="POST" action="product/delete/{{$product->id}}" role="form">
            {!! csrf_field() !!} 
            @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Delete') == true))
             <a class="btn btn-primary delete-product" id="delete-product"
                     data-toggle = "tooltip" data-placement = "top" title = "Delete Product"><i class="fa fa-trash"></i></a>
             @endif        
          </form></span></td>
      </tr>
      @endforeach
        </tbody>

    </table>
  </div>
</div>
@endsection
@section('breadcrumbs')
{!! Breadcrumbs::render('admin/product') !!}
@endsection
