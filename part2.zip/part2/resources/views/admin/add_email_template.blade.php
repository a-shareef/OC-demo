@extends('layouts.dashboard')
@section('title', 'Manage Email Templates')
@section('content') 
<!-- Form Name -->

<form name="insertTemplate" id="insertTemplate" class="form-horizontal" method="POST" action="{{ route('insertTemplate') }}">
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>{{ $getTranslatedLang['manage_email_template_create_new_email_message_template'] }}</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    {!! csrf_field() !!}
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="Template Name">{{ $getTranslatedLang['manage_email_template_template_name'] }}</label>
        <div class="col-sm-7">
          <input id="template_name" name="template_name" type="text" placeholder="{{ $getTranslatedLang['manage_email_template_template_name'] }}" class="form-control input-md" required="">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="template_content">{{ $getTranslatedLang['manage_email_template_template_content'] }}</label>
        <div class="col-sm-7">
          <textarea id="template_content" name="template_content" rows="7" class="form-control ckeditor"></textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label"></label>
        <div class="col-sm-7">
          <input type="submit" value="{{ $getTranslatedLang['manage_email_template_add'] }}" class='btn btn-primary'>
        </div>
      </div>
    </div>
  </div>
 @ckeditor('template_content')
</form>
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/manage-email/add-template') !!}
@endsection 