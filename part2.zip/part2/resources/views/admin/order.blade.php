<!-- resources/views/user/profile.blade.php -->

@extends('layouts.user')
@section('style')
@parent
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/css/select2.min.css" rel="stylesheet" />
<link href="{{url('/')}}/assets/bootstrap/css/typeahead.css" rel="stylesheet">
@endsection
@section('title', 'Add Order')

@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
<form  id="profileForm"  class="form-horizontal formFiled" data-toggle="validator" method="POST" action="@if(isset($orderData[0]->product_initials)){{ route('order_update') }}@else{{ route('orders') }}@endif" role="form" style="display: block;">
  <div class="ibox float-e-margins">
    <div class="ibox-title"> {!! csrf_field() !!}
      @if(isset($orderData[0]))
      <h5>Edit Order </h5>
      @else
      <h5>Add Order </h5>
      @endif
      
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
    @if(isset($orderData[0]->product_initials))<fieldset disabled>@endif
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product"> Product: </label>
        <div class="col-sm-7">
          <select required id="product" name="product" class="form-control" >
            <option value="">Select  Product</option>
               
              @foreach($products as $product)  
            
            <option  value="{{$product->product_initials}}"
                  @if(isset($orderData) && $orderData[0]->product_initials == $product->product_initials)
            selected
            @endif
            >
            {{$product->product_name}} </option>
            
              @endforeach
            
          
          </select>
          <div class="alert-message alert-warning">{{$errors->first('product')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="company"> Company: </label>
        <div class="col-sm-7">
          <input id="company" required name="company" type="text" placeholder="Company"
          class="form-control input-md"
          value="@if(isset($orderData[0]->company_name)) {{$orderData[0]->company_name}} @endif">
          <div class="alert-message alert-warning">{{$errors->first('company')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      
      <!-- Textarea -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea"> Description: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description"
        name="product_description">@if(isset($orderData[0]->description)){{$orderData[0]->description}}@endif</textarea>
        </div>
      </div>
      <!-- Text input-->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="quantity"> Qty: </label>
        <div class="col-sm-7">
          <input id="quantity" required name="quantity" maxlength="3" type="text" pattern="\d{1,3}" placeholder="Qty"
          class="form-control input-md"
          value="@if(isset($orderData[0]->quantity)){{$orderData[0]->quantity}}@endif">
          <div class="alert-message alert-warning">{{$errors->first('quantity')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <!-- Text input-->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="order_no"> Order No: </label>
        <div class="col-sm-7">
          <input id="order_no" required name="order_no" type="text" placeholder="Order No"
          class="form-control input-md"
          value="@if(isset($orderData[0]->order_no)) {{$orderData[0]->order_no}} @endif">
          <div class="alert-message alert-warning">{{$errors->first('order_no')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
   @if(isset($orderData[0]))</fieldset>@endif
      @if(isset($orderData[0]->order_status))
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="order_status"> Order status: </label>
        <div class="col-sm-7">
          <select required id="order_status" name="order_status" class="form-control" >
            <option value="">Select  Status</option>
            
              @foreach($orderStatus as $key => $status)
            
            <option  value="{{$key}}"
                  @if($orderData[0]->order_status == $key)
            selected
            @endif>
            {{$status}} </option>
            
              @endforeach
            
          </select>
          <div class="alert-message alert-warning">{{$errors->first('product')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <input type="hidden" value="{{$orderData[0]->order_id}}" name="order_id" />
      @endif 
      
      <!-- Button -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label"></label>
        <div class="col-sm-7">
                 <button id="profile_submit" name="profile_submit"
            class="btn btn-primary">@if(isset($orderData[0]->order_no)) Update @else Submit @endif</button>
          @if(isset($orderData[0]->order_no)) <a id="edit-cancel-button" name="button2id" class="btn  btn-primary" href="{{url('/')}}">Cancel</a> @else
          <input  class="btn reset  btn-primary" type="reset" value="Reset">
          <a id="edit-cancel-button" name="button2id" class="btn  btn-primary" href="{{url('/')}}">Cancel</a> @endif </div>
      </div>
    </div>
  </div>
</form>
@if(isset($company))
<div id="pre"  data-field-id="{{$company}}"></div>
@endif
@endsection
@section('script')
@parent 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/js/select2.min.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/typeahead.min.js"></script> 
<script src="{{url('/')}}/assets/js/orders.js"></script> 
@endsection
<?php $currentRoutes = Route::currentRouteName();?>
@section('breadcrumbs')
@if($currentRoutes == 'order')
    {!! Breadcrumbs::render('admin/order/add') !!}
@endif
 @if($currentRoutes == 'edit_order')
      {!! Breadcrumbs::render('admin/order/edit/{order_id}') !!}
  @endif

@endsection 