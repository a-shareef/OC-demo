@extends('layouts.dashboard')
@section('title', 'Manage FT Products')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> {{ session('status') }} </div>
</div>
@endif

@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> {{ session('error') }} </div>
</div>
@endif
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage FT Products</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row"> @if (hasrole() == 1)
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="ft_orders" name="ft_orders" class="form-control" >
          <option value="">Select Order</option>
            @foreach($ordersArray as $key => $order)
          <option value="{{$order->id}}" @if($orderId == $order->order_no) selected="selected" @endif> 
          {{$order->order_no}} </option>
                       
          @endforeach
                
        </select>
      </div>
      @endif
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="ft_company" name="ft_company" class="form-control" >
          <option value="">Select Company</option>

            @foreach($companyArray as $key => $company)
               
          <option value="{{$company->id}}"> {{$company->company_name}}</option>
     
          @endforeach
                
        </select>
      </div>
    </div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer responsive productDataTable" cellspacing="0" width="100%" id="mftprod-table">
        <thead>
          <tr>
            <th data-priority="1">Tag #</th>
            <th>Product</th>
            <th>Description</th>
            @if (hasrole() == 1)
            <th>Product Status</th>
            @endif
            @if (hasrole() == 4)
            <th>Registration Status</th>
            @endif
            <th>Last Updated On</th>
            <th data-priority="2">Action</th>
            @if (hasrole() == 1)
            <th >Order No</th>
            <th> Company</th>
            @endif </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<input type="hidden" id="orderId" value="{{$orderId}}">
<input type="hidden" id="search" value="Search">
<input type="hidden" id="next" value="Next">
<input type="hidden" id="first" value="First">
<input type="hidden" id="last" value="Last">
<input type="hidden" id="previous" value="Previous">
<input type="hidden" id="record_per_page" value="Records Per Page">
<input type="hidden" id="display" value="Display">
<input type="hidden" id="dashboard_of" value="of">
<input type="hidden" id="showing_page" value="Showing page">
<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="hasrole" value="{{ hasrole() }}">
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/manageproduct') !!}
@endsection