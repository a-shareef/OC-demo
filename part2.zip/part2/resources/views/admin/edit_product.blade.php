@extends('layouts.user')
@section('title', 'Edit Products')
@section('content')
@foreach($getProduct as $product)
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>{{ $getTranslatedLang['manage_id_products_heading_edit_product'] }}</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <form id="form-update-product"  class="form-horizontal" data-toggle="validator" method="POST" action="{{url('/')}}/admin/product/edit/{{$product->id}}" role="form">
    <!-- Form Name --> 
    {!! csrf_field() !!} 
    <!-- Text input-->
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textinput">{{ $getTranslatedLang['manage_id_products_product_name'] }}</label>
        <div class="col-sm-7">
          <input id="product_name" name="product_name" type="text" placeholder="" class="form-control input-md" value="{{$product->product_name}}" required>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea">{{ $getTranslatedLang['manage_id_products_product_description'] }}</label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description" name="product_description" required>{{$product->product_description}}</textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Button (Double) -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="button1id"></label>
        <div class="col-sm-7">
         @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Edit') == true))
          <input type="submit" class="btn btn-primary" value="{{ $getTranslatedLang['manage_id_products_update'] }}"/>
          @endif
          <a id="edit-cancel-button" name="button2id" class="btn btn-primary" href="{{route('product-list')}}">{{ $getTranslatedLang['manage_id_products_cancel'] }}</a> </div>
      </div>
      @endforeach </div>
  </form>
</div>
@endsection
@section('breadcrumbs')
{!! Breadcrumbs::render('admin/product') !!}
@endsection 