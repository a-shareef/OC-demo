@extends('layouts.dashboard')
@section('title', 'Manage Email Templates')
@section('content') 
<!-- Form Name --> 

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon"></span> {{ session('error') }} </div>
@endif

<form class="form-horizontal"  method="POST" action="">
{!! csrf_field() !!}
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>{{ $getTranslatedLang['manage_email_template_manage_email_template'] }}</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content"> <a href="{{route('manage_email')}}" class="btn btn-primary"><i class="fa fa-envelope"></i> {{ $getTranslatedLang['manage_email_template_message'] }}</a> <a href="{{route('assign_template')}}" class="btn btn-primary"><i class="fa fa-check"></i> {{ $getTranslatedLang['manage_email_template_assign'] }}</a> </div>
</div>
<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>{{ $getTranslatedLang['manage_email_template_email_message_template'] }}</h5>
  <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">
<a href="{{route('add_template')}}" class='btn btn-primary btn-xs pull-right'><i class="fa fa-plus" aria-hidden="true"></i> {{ $getTranslatedLang['manage_email_template_add'] }}</a>
<div class="table-responsive">
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer responsive" id="manage-email-table">
<thead>
  <tr>
    <th data-priority="1">{{ $getTranslatedLang['manage_email_template_template_name'] }}</th>
    <th>{{ $getTranslatedLang['manage_email_template_checkpoint_assigned'] }}</th>
    <th>{{ $getTranslatedLang['manage_email_template_created_on'] }}</th>
    <th data-priority="2">{{ $getTranslatedLang['manage_email_template_action'] }}</th>
  </tr>
</thead>
<tbody>

@if($retriveTemplates)
        @foreach($retriveTemplates as $retriveTemplate)
<tr>
  <td>{{$retriveTemplate->template_name}}</td>
  <td>{{getCheckpointAssigned($retriveTemplate->fk_checkpoint_id)}}</td>
  <td>{{Carbon\Carbon::parse($retriveTemplate->created_at)->format('d/m/Y')}}</td>
  <td> <span class="tooltip-demo">@if($retriveTemplate->template_activation_mode == 1) <a href="{{route('activateTemplate', ['id' => $retriveTemplate->id])}}" class='btnDeactive' data-toggle="tooltip" data-placement="top" title="This template is currently Activated.. Click to Deactivate!"><span class="switchery" id="firstswitch" name="chk_fname" style="background-color: rgb(239, 134, 35);border-color: rgb(239, 134, 35);box-shadow: rgb(239, 134, 35) 0px 0px 0px 16px inset;transition: border 0.4s, box-shadow 0.4s, background-color 1.2s;"><small style="left: 24px; transition: left 0.2s;"></small></span></a> @endif
    @if($retriveTemplate->template_activation_mode == 0) <a href="{{route('activateTemplate', ['id' => $retriveTemplate->id])}}" class='btnActive' data-toggle="tooltip" data-placement="top" title="This template is currently Deactivated.. Click to Activate!"><span class="switchery" name="chk_dob" style="box-shadow: rgb(223, 223, 223) 0px 0px 0px 0px inset; border-color: rgb(223, 223, 223); transition: border 0.4s, box-shadow 0.4s;"><small style="left: 0px; transition: left 0.2s;"></small></span> </a> @endif
     <a href="{{route('editTemplate', ['id' => $retriveTemplate->id])}}" class="btn btn-primary" data-toggle = "tooltip" data-placement = "top" title = "Edit Template"><i class="fa fa-pencil"></i></a>

<form id="form-delete-template"  name="delete-template" class="form-delete-template d-inline-block" data-toggle="validator" method="POST" action="{{route('deleteTemplate',$retriveTemplate->id)}}" role="form">
  {!! csrf_field() !!} <a class="btn btn-primary delete-template" id="delete-template"
                     data-toggle = "tooltip" data-placement = "top" title = "Delete Template"/><i class="fa fa-trash"></i></a>
</form></span>
</td>
</tr>
@endforeach
    @endif
</tbody>
</table>
</div>
</div>
</div>
</form>
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/manage-email') !!}
@endsection