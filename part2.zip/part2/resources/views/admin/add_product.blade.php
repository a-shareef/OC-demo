@extends('layouts.user')
@section('title', 'Add New Product')
@section('content')
<form id="form-add-product"  class="form-horizontal" data-toggle="validator" method="POST"
action="{{url('/')}}/admin/product/add" role="form">
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>{{ $getTranslatedLang['manage_id_products_heading_add_new_product'] }}</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    {!! csrf_field() !!}
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product_name"> {{ $getTranslatedLang['manage_id_products_product_name'] }}: </label>
        <div class="col-sm-7">
          <input id="product_name" name="product_name" type="text" placeholder="Product Name"
   class="form-control input-md" required value="{{old('product_name')}}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="productInitials"> Product Initials: </label>
        <div class="col-sm-7">
          <input id="productInitials" name="productInitials" type="text" placeholder="Product Initials"
   class="form-control input-md" maxlength="2" required value="{{old('productInitials')}}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-warning">{{$errors->first('productInitials')}}</div>
        </div>
      </div>
      <div class="hr-line-dashed"></div>      
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea"> {{ $getTranslatedLang['manage_id_products_product_description'] }}: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description" placeholder="Product Description"
    name="product_description" required>{{old('product_description')}}</textarea>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>      
      <!-- Button (Double) -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="button1id"></label>
        <div class="col-sm-7">
        @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Add') == true))          
        <input type="submit" class="btn btn-primary" value="{{ $getTranslatedLang['manage_id_products_add'] }}"/>
        @endif
          <a id="edit-cancel-button" name="button2id" class="btn btn-primary" href="{{route('product-list')}}">{{ $getTranslatedLang['manage_id_products_cancel'] }}</a> </div>
      </div>
    </div>
  </div>
</form>
@endsection
@section('breadcrumbs')
{!! Breadcrumbs::render('admin/product/add') !!}
@endsection