 @extends('layouts.front')
@section('title', 'Finder Details')
@section('content')
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Lost/Found/Suspended History:</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <dl class="dl-horizontal">
      <dt>Product Status :</dt>
      <dd> Found </dd>
      <div class="hr-line-dashed"></div>
      <dt>Name :</dt>
      <dd> {{$data[0]->first_name}}{{$data[0]->last_name}} </dd>
      <div class="hr-line-dashed"></div>
      <dt>Email :</dt>
      <dd> {{$data[0]->email}} </dd>
      <div class="hr-line-dashed"></div>
      <dt>Phone :</dt>
      <dd> {{$data[0]->country_code}}{{$data[0]->user_phone}} </dd>
      <div class="hr-line-dashed"></div>
      <dt>IP :</dt>
      <dd> {{$data[0]->ip}} </dd>
      <div class="hr-line-dashed"></div>
      <dt>Remarks :</dt>
      <dd> {{$data[0]->remarks}} </dd>
      <div class="hr-line-dashed"></div>
    </dl>
  </div>
</div>
@endsection 