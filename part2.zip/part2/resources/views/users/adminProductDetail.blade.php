@extends('layouts.dashboard')
@section('title', 'FT Lookup Tool')
@section('content')

 <link href="{{url('/')}}/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.css"/>
<div class="ibox float-e-margins">
<!-- <dt>Search : <input type="text" name="history_details" id="history_details"></dt>
<input type="hidden" id="token" value="{{ csrf_token() }}"> -->
<div class="ibox-title">

<h5>FT Lookup Tool</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
  <div class="ibox-content">
    <div class="form-inline dt-bootstrap">
  <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="users-table">
    <thead>
      <tr>
        <th data-priority="1">Tag #</th>
        <th>Registered Date</th>
        <th>Product Status</th>
        <th data-priority="2">Action</th>
      </tr>
    </thead>
    <tbody>
      @foreach($retriveProduct as $value)
       <tr>
        <td data-priority="1">{{ $value->order_sequence }}</td>
        <td>{{ $value->registration_date ? $value->registration_date : '-' }}</td>
        <td>{{ $value->product_status }}</td>
       @php
              $historyLink = '/products/historyDetails/' . userIdEncode($value->order_sequence);
        @endphp
        <td data-priority="2"><span class='tooltip-demo1'><a data-toggle='tooltip' data-placement='top' title='Product History Detail' href='{{ $historyLink }}' class='btn btn-primary'/>
        <i class='fa fa-history'></i></a></td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
  </div>
  </div>
@endsection
@section('script')
 
 <script type="text/javascript">
    
    $(document).ready(function() {
     // Adding Datatable and removing sorting feature from Action column 
      $('#users-table').DataTable( {
          "processing": true,
          "columnDefs": [{
              "targets": 3,
              "orderable": false
          }]
      });
});

  </script>
@endsection 
@section('breadcrumbs')
{!! Breadcrumbs::render('user/productDetails') !!}
@endsection







