
@extends('layouts.reportfront')
@section('title', 'User Data')
@section('content')
<dl class="dl-horizontal">
@if($userVisibilityData['chk_title'] == 'true' || $userVisibilityData['chk_fname'] == 'true' || $userVisibilityData['chk_lname'] == 'true')
<dt>{{$transLanguage['public_name']}}:</dt>
<dd>
	@if($userVisibilityData['chk_title'] == 'true')
	{{$data[0]->user_title}}
	@endif
	@if($userVisibilityData['chk_fname'] == 'true')
	{{$data[0]->first_name}}
	@endif
	@if($userVisibilityData['chk_lname'] == 'true')
	{{$data[0]->last_name}}
	@endif
</dd>
@endif
@if($userVisibilityData['chk_email'] == 'true')
<dt>{{$transLanguage['public_email']}}:</dt>
<dd>
	{{$data[0]->email}}
</dd>
@endif
@if($userVisibilityData['chk_phone'] == 'true')
<dt>{{$transLanguage['public_phone']}}:</dt>
<dd>
	{{$data[0]->country_code}} {{$data[0]->user_phone}}

</dd>
@endif
@if($userVisibilityData['chk_country'] == 'true')
<dt>{{$transLanguage['public_country']}}:</dt>
<dd>
    {{getCountry($data[0]->user_country)}}

</dd>
@endif
</dl>
<dl class="dlcity dl-horizontal">
@if($userVisibilityData['chk_city'] == 'true')
<div>
<dt>{{$transLanguage['public_city']}}:</dt>
<dd>
    {{$data[0]->user_city}}

</dd>
</div>
@endif


@if($userVisibilityData['chk_state'] == 'true')
<div>
<dt>{{$transLanguage['public_state']}}:</dt>
<dd>
    {{$data[0]->user_state}}

</dd>
</div>
@endif


@if($userVisibilityData['chk_zip'] == 'true')
<div>
<dt>{{$transLanguage['public_zip']}}:</dt>
<dd>
    {{$data[0]->user_zip}}
</dd>
</div>
@endif

</dl>
<dl class="dl-horizontal">
@if($userVisibilityData['chk_dob'] == 'true')
<dt>{{$transLanguage['public_date_of_birth']}}:</dt>
<dd>
 {{$data[0]->date_of_birth}}   <strong>({{$data[0]->date_format}})</strong>
</dd>
@endif
@if($userVisibilityData['chk_language'] == 'true')
<dt>{{$transLanguage['public_language']}}:</dt>
<dd>
		 {{$data[0]->fk_language_id}}
</dd>
@endif
</dl>

@if($connectionData)
<hr>
<h3>{{$transLanguage['public_connections']}}:</h3>
	<div class="tblScroll">
	<table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$transLanguage['public_name']}}</th>
               <th>{{$transLanguage['public_relationship']}}</th>
               <th>{{$transLanguage['public_contact']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($connectionData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
                <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}} {{$value->user_phone}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</dd>

@endif
@if($surgeryData || (isset($bloodInfo[0]) && $data[0]->chk_blood == 'true') || $medicationData)
 <hr>
<h2>{{$transLanguage['public_medical_profile']}}:</h2>
@if(isset($bloodInfo[0]) && $data[0]->chk_blood == 'true')
<dl class="dl-horizontal">
<dt><h3>{{$transLanguage['public_blood_type']}}:</h3></dt>
<dd>
    {{$bloodInfo[0]->blood_group}}
</dd>
</dl>
@endif
 @if($surgeryData)
<h3>{{$transLanguage['public_prior_surgery']}}:</h3>
<div class="tblScroll">
  <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$transLanguage['public_title']}}</th>
               <th>{{$transLanguage['public_date']}} <span>({{$data[0]->date_format}})</span></th>
               <th>{{$transLanguage['public_outcome']}}</th>
               <th>{{$transLanguage['public_doctor']}}</th>
               <th>{{$transLanguage['public_file_linked']}}</th>
            </tr>
        </thead>

        <tbody>
            @foreach($surgeryData as $value)
            @if($value->available_status == 0)
            <tr>
            <td>{{$value->surgery_title}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->surgery_date))}}</td>
            <td>{{$value->surgery_outcome}}</td>
            <td>{{$value->doctor_name}}</td>
            <td>
            @if(preg_match("/http/i", $value->file_link))
                <a target="_blank" href="{{$value->file_link}}">click here</a>
            @else
                {{$value->file_link}}
            @endif
            </td>
            </tr>
            @endif
            @endforeach
        </tbody>

    </table>
</div>
 @endif
 @if($medicationData)
 <h3>{{$transLanguage['public_current_medication']}}:</h3>
<div class="tblScroll">
  <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
                <th>{{$transLanguage['public_drug_name']}}</th>
               <th>{{$transLanguage['public_drug_dose']}}</th>
               <th>{{$transLanguage['public_drug_freq']}}</th>
               <th>{{$transLanguage['public_doctor']}}</th>
               <th>{{$transLanguage['public_notes']}}</th>
               <th>{{$transLanguage['public_start_date']}} <span>({{$data[0]->date_format}})</span></th>
               <th>{{$transLanguage['public_end_date']}} <span>({{$data[0]->date_format}})</span></th>
            </tr>
        </thead>

        <tbody>
            @foreach($medicationData as $value)
             @if($value->available_status == 0)
            <tr>
            <td>{{$value->drug_name}}</td>
            <td>{{$value->drug_dose}}</td>
            <td>{{$value->drug_frequency}}</td>
            <td>{{$value->doctor_name}}</td>
            <td>{{$value->user_notes}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->start_date))}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->end_date))}}</td>
            </tr>
            @endif
            @endforeach
        </tbody>

    </table>
</div>
@endif
@endif
@if($allergyFoodData || $allergyNonFoodData)
<h3>{{$transLanguage['public_allergy_profile']}}:</h3>
<div class="allergyBox">
    @if($allergyFoodData)
    <div class="allergyHd"><strong>{{$transLanguage['public_food']}}:</strong>
        <ul>
            @foreach($allergyFoodData as $value)
            @if($value->available_status == 0)
            <li>{{$value->text}}&nbsp;&nbsp;</li>
            @endif
            @endforeach
        </ul>
    </div>
    @endif
     @if($allergyNonFoodData)
    <div class="allergyHd"><strong>{{$transLanguage['public_non_food']}}:</strong>
        <ul>
            @foreach($allergyNonFoodData as $value)
            @if($value->available_status == 0)
            <li>{{$value->text}}&nbsp;&nbsp;</li>
            @endif
            @endforeach
        </ul>
    </div>
     @endif
</div>
@endif
@endsection
