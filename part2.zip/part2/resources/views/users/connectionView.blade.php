
@extends('layouts.front')
@section('title', 'User Data')
@section('content')
@if(session('connectionView'))
<dl class="dl-horizontal">
<dt>{{$transLanguage['public_name']}}:</dt>
<dd>
	{{$data[0]->user_title}}

	{{$data[0]->first_name}}

	{{$data[0]->last_name}}

</dd>

<dt>{{$transLanguage['public_email']}}:</dt>
<dd>
	{{$data[0]->email}}
</dd>


<dt>{{$transLanguage['public_phone']}}:</dt>
<dd>
	{{$data[0]->country_code}}{{$data[0]->user_phone}}

</dd>


<dt>{{$transLanguage['public_country']}}:</dt>
<dd>
    {{getCountry($data[0]->user_country)}}

</dd>

</dl>
<dl class="dlcity dl-horizontal">
<div>

<dt>{{$transLanguage['public_city']}}:</dt>
<dd>
    {{$data[0]->user_city}}

</dd>

</div>
<div>

<dt>{{$transLanguage['public_state']}}:</dt>
<dd>
    {{$data[0]->user_state}}

</dd>

</div>
<div>

<dt>{{$transLanguage['public_zip']}}:</dt>
<dd>
    {{$data[0]->user_zip}}
</dd>

</div>
</dl>
<dl class="dl-horizontal">

<dt>{{$transLanguage['public_date_of_birth']}}:</dt>
<dd>
 {{$data[0]->date_of_birth}}   <strong>({{$data[0]->date_format}})</strong>
</dd>


<dt>{{$transLanguage['public_language']}}:</dt>
<dd>
		 {{$data[0]->fk_language_id}}
</dd>

</dl>

@if($connectionData)
<hr>
<h3>{{$transLanguage['public_connections']}}:</h3>
	<div class="tblScroll">
	<table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$transLanguage['public_name']}}</th>
               <th>{{$transLanguage['public_relationship']}}</th>
               <th>{{$transLanguage['public_contact']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($connectionData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
                <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}}{{$value->user_phone}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</dd>

@endif
@if(isset($bloodInfo[0]))
<dl class="dl-horizontal">
<dt>{{$transLanguage['public_blood_type']}}:</dt>
<dd>
    {{$bloodInfo[0]->blood_group}}
</dd>
</dl>
@endif
 @if($surgeryData)
 <hr>
<h2>{{$transLanguage['public_medical_profile']}}:</h2>
<h3>{{$transLanguage['public_prior_surgery']}}:</h3>
<div class="tblScroll">
  <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$transLanguage['public_title']}}</th>
               <th>{{$transLanguage['public_date']}} <span>({{$data[0]->date_format}})</span></th>
               <th>{{$transLanguage['public_outcome']}}</th>
               <th>{{$transLanguage['public_doctor']}}</th>
               <th>{{$transLanguage['public_file_linked']}}</th>
            </tr>
        </thead>

        <tbody>
            @foreach($surgeryData as $value)

            <tr>
            <td>{{$value->surgery_title}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->surgery_date))}}</td>
            <td>{{$value->surgery_outcome}}</td>
            <td>{{$value->doctor_name}}</td>
            <td>
            @if(preg_match("/http/i", $value->file_link))
                <a target="_blank" href="{{$value->file_link}}">click here</a>
            @else
                {{$value->file_link}}
            @endif
            </td>
            </tr>

            @endforeach
        </tbody>

    </table>
</div>
 @endif
 @if($medicationData)
 <h3>Current Medication:</h3>
<div class="tblScroll">
  <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
                <th>{{$transLanguage['public_drug_name']}}</th>
               <th>{{$transLanguage['public_drug_dose']}}</th>
               <th>{{$transLanguage['public_drug_freq']}}</th>
               <th>{{$transLanguage['public_doctor']}}</th>
               <th>{{$transLanguage['public_notes']}}</th>
               <th>{{$transLanguage['public_start_date']}} <span>({{$data[0]->date_format}})</span></th>
               <th>{{$transLanguage['public_end_date']}} <span>({{$data[0]->date_format}})</span></th>
            </tr>
        </thead>

        <tbody>
            @foreach($medicationData as $value)

            <tr>
            <td>{{$value->drug_name}}</td>
            <td>{{$value->drug_dose}}</td>
            <td>{{$value->drug_frequency}}</td>
            <td>{{$value->doctor_name}}</td>
            <td>{{$value->user_notes}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->start_date))}}</td>
            <td>{{date(dateFormatReplace($data[0]->date_format), strtotime($value->end_date))}}</td>
            </tr>

            @endforeach
        </tbody>

    </table>
</div>
@endif
@if($allergyFoodData)
<h3>{{$transLanguage['public_allergy_profile']}}:</h3>
<div class="allergyBox">
    <div class="allergyHd"><strong>Food:</strong>
        <ul>
            @foreach($allergyFoodData as $value)

            <li>{{$value->text}}&nbsp;&nbsp;</li>

            @endforeach
        </ul>
    </div>
    <div class="allergyHd"><strong>Non Food:</strong>
        <ul>
            @foreach($allergyNonFoodData as $value)

            <li>{{$value->text}}&nbsp;&nbsp;</li>

            @endforeach
        </ul>
    </div>
</div>
@endif
@endif
@endsection
