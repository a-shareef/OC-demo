<!-- resources/views/auth/login.blade.php -->

@extends('layouts.auth')
@section('title', 'Login')
@section('style')
<style type="text/css">
body{
  padding:0;
  }
.navbar-inverse{
  border-width: 0;
  }
.logBtn form{
  float:right;
  width:200px;
  }
</style>
@endsection
@section('content')
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> {{ session('error') }} </div>
</div>
@endif
<div id="sidebar-wrapper">
  <nav class="navbar navbar-inverse">
    <div class="container-fluid"> 
      <!--<div class="navbar-header"> <a class="navbar-brand" href="/"><img src="/assets/images/logo.png"></a> </div>-->
      <div class="logBtn">
        <form id="languageForm" method="GET" action="/frontUser/language-change">
          {!! csrf_field() !!} 
          <!-- <input type="hidden" name="_token" value="DoopM93tVwZBAuOic8lGK5Z9Fb5uBoF5Zo3cOUF7"> -->
          <div class="form-group">
            <div class="col-md-12 col-sm-12 col-xs-12 input-group">
              <select onchange="langChange()" id="language" name="language" class="form-control" required >
                
                @foreach(getLanguages() as $lang)
                  
                <option value="{{$lang->language_id}}"
                    @if(getAuthenticateUserLanguage() == $lang->language_id)
                selected="selected" @endif >
                {{$lang->language_name}} </option>
                
                @endforeach
              
              </select>
              <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
              <div class="alert-message alert-danger" style="display: none;"></div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </nav>
</div>
<div class="row">
  <div class="col-md-6 col-md-offset-3">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row"> <a href="/"><img src="/assets/images/{{siteLogo()}}"></a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
          <div class="col-lg-12"> @php $languageTrans = languageTranslate("Channel Screen") @endphp
            <p>{{$languageTrans['channel_screen_first_half']}}</p>
            <p>{{$languageTrans['channel_screen_second_half']}}</p>
            <form  method="POST" action="/front/users" role="form" >
              {!! csrf_field() !!}
              <div class="form-group">
                <input type="password" name="password" id="password"
                    tabindex="2" class="form-control" placeholder="{{$languageTrans['channel_enter_pin']}}">
                <div class="alert-message alert-danger"> {{ $errors->first('password') }} </div>
              </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-sm-6 col-sm-offset-3 submitBtn">
                    <input type="submit" name="login-submit" id="login-submit" tabindex="4"
                            class="form-control btn btn-primary" value="{{$languageTrans['channel_enter_btn']}}">
                  </div>
                </div>
              </div>
              <input type="hidden" value="{{$userId}}" name="user_id" />
              <input type="hidden" value="{{$pin}}" name="upin" />
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
@section('script') 
<script type="text/javascript">
 $(".alert").delay(2000).fadeOut();
 $(".alert-message").delay(4000).fadeOut();
function langChange(){
   $( "#languageForm" ).submit();
}
</script> 
@endsection 