
@extends('layouts.reportfront')
@section('title', 'Finder Details')
@section('content')

<button class="btn btn-primary pull-right mb-10" onclick="window.history.go(-1); return false;">
<i class="fa fa-chevron-left"></i> Back
</button>

@if(isset($data[0]))
<div class="ibox float-e-margins">
    <div class="ibox-title"><h5>User Details:</h5>
      <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
@foreach($data as $key => $values)

		<dl class="dl-horizontal">
		<dt>Tag No :</dt>
		<dd>
		   {{$values->order_sequence}}
		</dd>
        <div class="hr-line-dashed"></div>
		<dt>Registered Owner :</dt>
		<dd>
		    {{$values->first_name}} &nbsp; {{$values->last_name}}
		</dd>
        <div class="hr-line-dashed"></div>
		<dt>Email :</dt>
		<dd>
		    {{$values->email}}
		</dd>
        <div class="hr-line-dashed"></div>
		<dt>Registration Date :</dt>
		<dd>
		{{$values->created_on}}
		</dd>
        <div class="hr-line-dashed"></div>
		 	<dt>User Description :</dt>
		<dd>
		{{$values->description}}
		</dd>
 	</dl>
@endforeach

@else

<dl class="dl-horizontal">

		<dd>
		  No Records Found for this Tag No.
		</dd>
		</dl>

@endif


</div>
</div>

@if(isset($data[0]))
<div class="ibox float-e-margins">
    <div class="ibox-title"><h5>Tag Transfer Details:</h5>
      <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
@foreach($data as $key => $values)
 	@if(!empty($values->transfer_notes))
 		@foreach($tagTransferFrom as $transfer)
 		<dl class="dl-horizontal">
 		 <div class="hr-line-dashed"></div>
		 	<dt>This Tag was Transfered From :</dt>
		<dd>
		{{ $transfer->email }}
		</dd>
		 <div class="hr-line-dashed"></div>
		 	<dt>Tag Transaction Notes :</dt>
		<dd>
		{{ $values->transfer_notes }}
		</dd>
		 <div class="hr-line-dashed"></div>
		 	<dt>Tag Transfered Date :</dt>
		<dd>
		{{ $values->updated_on }}
		</dd>
		@endforeach
 	@endif
 	</dl>
@endforeach

@else

<dl class="dl-horizontal">

		<dd>
		  No Records Found for this Tag No.
		</dd>
		</dl>

@endif
@endsection

</div>
</div>
