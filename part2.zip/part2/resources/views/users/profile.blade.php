<!-- resources/views/user/profile.blade.php -->

@extends('layouts.user')
@section('title', 'User Profile')

@section('content')
@php 
  $uid = (isset($users->uid))?$users->uid:'';
@endphp
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
<form id="profileForm"  class="form-horizontal" data-toggle="validator" method="POST"
action="{{url('/')}}/user/profile" role="form" style="display: block;">
  <div class="ibox float-e-margins">
    <div class="ibox-title"> @if(isset($users->fk_role_id) && $users->fk_role_id == PROFILE_CS_AGENT)
      @if(hasrole() == PROFILE_SUPER_ADMIN && empty($users->email))
      <h5>{{$transLanguage['edit_csagent_profile']}}</h5>
      @else
      <h5>{{$transLanguage['edit_csagent_profile']}}</h5>
      @endif
      @elseif(isset($users->fk_role_id) && $users->fk_role_id == PROFILE_ADMIN)
      <h5>{{$transLanguage['edit_admin_profile']}}</h5>
      @else
      <h5>{{$transLanguage['edit_user_profile']}}</h5>
      @endif
      {!! csrf_field() !!}
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="role"></label>
        <div class="col-sm-7"><span class="asterisk_notice">(* Fields marked as mandatory)</span></div>
      </div>
      <!-- Select Basic -->
      
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="user_title"> {{$transLanguage['edit_title']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <select required id="user_title" name="user_title" class="form-control blurclass" >
            <option value="">Select  {{$transLanguage['edit_title']}}</option>
            
        @foreach($titleArray as $title)
              
          <option  value="{{$title}}"
              @if((old('user_title') ? old('user_title') : $users->   
        
          user_title) == $title)
              selected="selected" @endif>
              {{$title}}
   
        
            </option>
  
              @endforeach
        
          </select>
          <div class="alert-message alert-warning">{{$errors->first('user_title')}}</div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="firstname"> {{$transLanguage['edit_first_name']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <input id="firstname" name="firstname" type="text" placeholder="{{$transLanguage['edit_first_name']}}"
          class="form-control input-md blurclass" pattern="[^0-9]*"  required=""
          value="{{ old('firstname') ? old('firstname') : $users->first_name }}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger">{{$errors->first('firstname')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="lastname"> {{$transLanguage['edit_last_name']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <input id="lastname" name="lastname" type="text" placeholder="{{$transLanguage['edit_last_name']}}"
          class="form-control input-md blurclass" pattern="[^0-9]*" required=""
          value="{{ old('lastname') ? old('lastname') : $users->last_name}}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger">{{$errors->first('lastname')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="email"> {{$transLanguage['edit_email']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div id="emaildiv" class="col-sm-7">
          <input id="email" name="email" type="email" placeholder="{{$transLanguage['edit_email']}}"
  class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
  required value="{{ old('email') ? old('email') : $users->email }}">
          <input id="email_cpy" name="email_cpy" type="hidden" placeholder="{{$transLanguage['edit_email']}}"
  class="form-control input-md" value="{{ old('email') ? old('email') : $users->email }}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger">{{$errors->first('email')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="row" id="emailPwdid" style="display:none;">
        <div  class="col-md-12 col-sm-12 col-xs-12 " >
          <div class="form-group">
            <label class="col-sm-3 control-label" for="email"> Enter Current Password: </label>
            <div id="emailpassdiv" class="col-sm-7">
              <input type="password" name="emailPassword" id="emailPassword" tabindex="2" class="form-control" placeholder="Enter Current Password">
              <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
              <div class="alert-message alert-danger">{{$errors->first('email')}}</div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label emailPasswrd"></label>
            <div class="col-sm-4">
              <input type="hidden" value="{{$uid}}" name="pass_user_id" id="pass_user_id" />
              <input type="button" name="checkEmailPwd" id="checkEmailPwd" class="btn btn-primary" value="Confirm">
            </div>
          </div>
          <div class="hr-line-dashed"></div>
        </div>
      </div>
      <!-- Text input--> 
      
      <!-- Text input-->
    <div class="row">
      <div class="col-sm-10 col-md-5">
        <div class="form-group countary-code">
          <label class="col-sm-7 control-label" for="country_code"> {{$transLanguage['edit_country_code']}}:
              <span class="profile_asterik profile_asterik_mob">*</span> 
          </label>
          <div class="col-sm-3">
          <div class="input-group">
                <input id="countrys_code" type="hidden" value="{{ old('country_code') ? old('country_code') : $users->country_code }}"> 
                <span class="input-group-addon" id="ccPlus">+</span>
                <span class="input-group-addon" id="ccdid" type="text" style="display:none"></span>
                <select required id="country_code" name="country_code" class="form-control country_code_common" required>
                    <option value="">Country Code</option>            
                    @if(isset($countryArray))
                        @foreach($countryArray as $countryArrays)                            
                            <option data-ccdid="{{$countryArrays->id}}" value="{{$countryArrays->countryId}}" {{ isset($cookieData['country_code']) && $cookieData['country_code'] == $countryArrays->id ?  'selected="selected"' : '' }}
                        @if((old('country_code') ? old('country_code') : $users->country_code)  == $countryArrays->countryId) selected="selected" @endif >
                               {{$countryArrays->text}} - +{{$countryArrays->id}}  
                            </option>
                        @endforeach
                    @endif
                </select>
          </div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger">{{$errors->first('country_code')}}</div>
            @if(isset($countryArray))
                <div id="countryCo"  data-field-id="{{json_encode($countryArray)}}"></div>
            @endif
          </div>
        </div>
      </div>
      <div class="hidden-lg hidden-md col-xs-12">
        <div class="hr-line-dashed"></div>
      </div>
      <div class="col-sm-10 col-md-5">
        <div class="form-group countary-number">
          <label class="col-sm-3 control-label" for="phone"> {{$transLanguage['edit_phone']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-md-3 col-sm-7">
          <input id="phone" name="phone" pattern="^\D*(?:\d\D*){10}" type="tel"
          placeholder="{{$transLanguage['edit_phone']}}"
          class="form-control input-md" required=""
          value="{{ old('phone') ? old('phone') : $users->user_phone }}">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger">{{$errors->first('phone')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div id="optional_data"> 
        <!-- Text input-->
        <div class="form-group">
          <label class="col-sm-3 control-label" for="address1"> {{$transLanguage['edit_address_1']}}: </label>
          <div class="col-sm-7">
            <input id="address1" name="address1" type="text" placeholder="{{$transLanguage['edit_address_1']}}"
          class="form-control input-md blurclass"
          value="{{ old('address1') ? old('address1') : $users->street_address1 }}">
            <div class="alert-message alert-danger">{{$errors->first('address1')}}</div>
          </div>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="address2"> {{$transLanguage['edit_address_2']}}: </label>
        <div class="col-sm-7">
          <input id="address2" name="address2" type="text" placeholder="{{$transLanguage['edit_address_2']}}"
          class="form-control input-md blurclass"
          value="{{ old('address2') ? old('address2') : $users->street_address2 }}">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="address3"> {{$transLanguage['edit_address_3']}}: </label>
        <div class="col-sm-7">
          <input id="address3" name="address3" type="text" placeholder="{{$transLanguage['edit_address_3']}}"
          class="form-control input-md blurclass"
          value="{{ old('address3') ? old('address3') : $users->street_address3 }}">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="city"> {{$transLanguage['edit_city']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="city" name="city" type="text" placeholder="{{$transLanguage['edit_city']}}"
          class="form-control input-md blurclass" required="" pattern="[A-z ]+$"
          value="{{ old('city') ? old('city') : $users->user_city }}">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger">{{$errors->first('city')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="state"> {{$transLanguage['edit_state_province']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="state" name="state" type="text" placeholder="{{$transLanguage['edit_state_province']}}"
          class="form-control input-md blurclass" required="" pattern="[A-z ]+$"
          value="{{ old('state') ? old('state') : $users->user_state }}">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger">{{$errors->first('state')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Select Basic -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="country"> {{$transLanguage['edit_country']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <select required id="country" name="country" class="form-control blurclass">
              <option value="">Select {{$transLanguage['edit_country']}}</option>
              
              @foreach($countries as $country)
          
              <option value="{{$country->country_code}}"
                    @if((old('country') ? old('country') : $users->
                   
          
            user_country ) == $country->country_code)
                    selected="selected"
                     @endif >
                    {{$country->country_name}}   
          
              </option>       
            
               @endforeach    
        
            </select>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger">{{$errors->first('country')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="zip"> {{$transLanguage['edit_zip_postcode']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="zip" name="zip" type="text" placeholder="{{$transLanguage['edit_zip_postcode']}}"
          class="form-control input-md blurclass" required="" style="text-transform:uppercase"
          value="{{ old('zip') ? old('zip') : $users->user_zip }}">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger">{{$errors->first('zip')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <!-- Select Basic -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="user_title"> {{$transLanguage['edit_date_format']}}: </label>
        <div class="col-sm-7">
          <select id="date_format" name="date_format" class="form-control blurclass" >      
          
              @foreach($dateArray as $key => $date)
        
            <option  value="{{$key}}"
              @if((old('date_format') ? old('date_format') : $users->       
        
          date_format) == $key)
              selected="selected" @endif>
              {{$date}}        
        
            </option>
                     
              @endforeach    
      
          </select>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="dob"> {{$transLanguage['edit_date_of_birth']}}:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group date" id="date_of_birth">
            <input id="dob" name="dob" type="text" placeholder=" {{$transLanguage['edit_date_of_birth']}}"
          class="form-control input-md blurclass" required
          value="{{ old('dob') ? old('dob') : $users->date_of_birth}}">
            <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span></div>
          <div class="alert-message alert-danger">{{$errors->first('dob')}}</div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      @if(count($packageList) > 0) 
         <!-- Select Basic -->
         <div class="form-group">
         <label class="col-sm-3 control-label" for="package"> Package: </label>
         <input type="hidden" name="package" value="{{ $package_flag }}" /> 
          <div class="col-sm-7">
            <div class="input-group">
             @if(hasrole() == 3)
           {{--   {{dd($users->package_id)}} --}}
             <input type='hidden' id="package_profile" name="package_id" value="{{$users->package_id}}">
             @endif
              <select id="package_profile" name="package_id" class="blurclass form-control" required @if(hasrole() == 3) disabled="disabled" @endif>
                  <option value="">Select Package</option>
                    @foreach($packageList as $key => $package)              
                      <option  value="{{$package->id}}" @if((old('package_id') ? old('package_id') : $users->package_id) == $package->id)
                  selected="selected" @endif >
                        {{$package->name}}
                      </option>
                    @endforeach
              </select>

            </div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
            <div class="alert-message alert-danger">{{$errors->first('package')}}</div>
          </div>
        </div> 
        <div class="hr-line-dashed"></div>
        @endif
     <!-- Button -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="cancel"></label>
        <div class="col-sm-7">
      @if($users->email)
        @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('My Profile', 'Edit') == true))

          <button id="profile_submit" name="profile_submit"
            class="btn btn-primary"> {{$transLanguage['edit_update']}} </button>
        @endif 
      @else
          @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('My Profile', 'Add') == true))

            <button id="profile_submit" name="profile_submit"
            class="btn btn-primary"> {{$transLanguage['edit_submit']}} </button>
          @endif 
      @endif
          
        @if($users->email)
          <input type="button" class="btn btn-secondary" onclick="window.history.go(-1); return false;" value="{{$transLanguage['edit_cancel']}}"/>
          @else
          <input class="btn btn-secondary" type="reset" value="{{$transLanguage['edit_reset']}}">
          @endif </div>
        <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
      </div>
      @if($users->email)
      <input type="hidden" value="PUT" name="_method" />
      <input type="hidden" value="{{$uid}}" name="user_id" />
      @endif
      
      
      @if(isset($users->fk_role_id) && ($users->fk_role_id == PROFILE_SUPER_ADMIN || $users->fk_role_id == PROFILE_ADMIN))
      <input type="hidden" value="{{$users->fk_role_id}}" id="role_id"/>
      @endif
      @if(isset($users->fk_role_id))
      @if(empty($users->email) && (hasrole() == PROFILE_SUPER_ADMIN || hasrole() == PROFILE_ADMIN || hasrole() == PROFILE_CS_AGENT))
      <input type="hidden" value="1" id="ajaxEmail" />
      <input type="hidden" name="_token" id="fttoken" value="{{ csrf_token()}}"/>
      @endif
      <input type="hidden" value='{{$users->fk_role_id}}' id="role_id" name="roleId" />
      @endif </div>
  </div>
</form>
@endsection
@section('breadcrumbs')
<?php $currentRoutes = Route::currentRouteName();?>
@if($currentRoutes == 'add')
    {!! Breadcrumbs::render('admin/add') !!}
@endif
@if($currentRoutes == 'csa')
    {!! Breadcrumbs::render('user/csa') !!}
@endif
@if($currentRoutes == 'edit_csa')
    {!! Breadcrumbs::render('user/csa/{userId}') !!}
@endif
@if($currentRoutes == 'edit_admin')
    {!! Breadcrumbs::render('user/admin/{userId}') !!}
@endif
@if($currentRoutes == 'profile')
    {!! Breadcrumbs::render('user/profile/{user_id?}') !!}
@endif


@endsection
@section('style')  
    @parent 
    <link href="{{url('/')}}/assets/css/select2/select2.min.css" rel="stylesheet">
@endsection
@section('script')
@parent 
<script src="{{url('/')}}/assets/js/select2/select2.full.min.js"></script>
<script src="{{url('/')}}/assets/js/countryCode.js"></script> 
<script src="/assets/js/profile.js"></script> 
@endsection 