<!-- resources/views/auth/login.blade.php -->
@extends('layouts.finder')
@section('title', 'User-Details')
@section('content')
 
<div class="row">
<div class="col-md-6 col-sm-8 col-md-offset-2">
  <div class="">
    <div class="panel-body">
      <div class="row text-justify"> 
      <div class="form-group col-md-12 col-sm-12 col-xs-12 col-lg-12"><span> 


      @foreach($userdetails as $key => $user)
      <pre> Username : {{$user->first_name}}  {{$user->last_name}}</pre>
      <pre> Phone : {{$user->user_phone}}</pre>
      <pre> Email : {{$user->email}}</pre>
      <pre> Registration Date : {{$user->created_on}}</pre>

      @endforeach

      </span></div>
      </div>
       
    </div>
  </div>
</div>
@endsection 