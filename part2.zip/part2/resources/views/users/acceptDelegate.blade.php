<!-- resources/views/user/acceptDelegate.blade.php -->
@extends('layouts.auth')
@section('title', 'Delegate Activation')
@section('content')
@if (isset($status))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ $status }}
    </div>
</div>
@endif
@if (isset($errorStatus))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        {{ $errorStatus }}
    </div>
</div>
@endif
<script type="text/javascript">
window.setTimeout(function() {
    window.location.href = '/';
}, 3000);
</script>
@endsection