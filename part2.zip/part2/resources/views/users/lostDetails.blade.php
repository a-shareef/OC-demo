 @extends('layouts.plain')
@section('title', 'Finder Details')
@section('content')

  <!--<div class="row"><div class="col-xs-12"><button class="btn btn-primary pull-right mb-10" onclick="window.history.go(-1); return false;"><i class="fa fa-chevron-left"></i> Back</button></div></div>-->
<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Lost / Found / Suspended History:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">

  @if(isset($data[0]))
   <ul class="sortable-list connectList agile-list ui-sortable" id="todo">  
  @foreach($data as $key => $values)
   <li class="warning-element ui-sortable-handle" id="task1">
  @if($values->status == 3)
  <dl class="dl-horizontal">  
      <div class="hr-line-dashed"></div>
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost </dd>
   
      @if((int)$values->updated_by > 0)
      <div class="hr-line-dashed"></div>


    <dt>Updated By :</dt>
    @if(!empty(getUserdetails($values->updated_by)))
    <dd> {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} 
      @if($values->updated_by == 1)
      (Super Admin)
      @elseif($values->updated_by == 4)
      (CS Agents)
      @else
      (User)
      @endif
      @else
      -
      @endif
      @else
      - 
      @endif
      </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Last seen :</dt>
    <dd> {{$values->lastseen_location}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Last seen On :</dt>
    <dd> {{$values->lastseen_on}} {{$values->lastseen_time}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{ date('m-d-Y h:i A', strtotime($values->created_on)) }} </dd>
  </dl>
  @elseif($values->status == 4)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Suspend </dd>
      <div class="hr-line-dashed"></div>
    @if($values->updated_by != '')
    <dt>Suspended By :</dt>
    <dd> {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    @endif
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{date('m-d-Y h:i A', strtotime($values->created_on))}} </dd>
  </dl>

  @elseif($values->status == 5)
  @if($values->fk_user_id == 0 || $values->fk_user_id == '')
  <dl class="dl-horizontal">
    <dt>Product Never Registered.</dt>
  </dl>
      <div class="hr-line-dashed"></div>
  @endif
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    @if(!empty($values->country_code) && !empty($values->phone))
    <dt>Phone :</dt>
    <dd> +{{$values->country_code}} {{$values->phone}} </dd>
      <div class="hr-line-dashed"></div>
    @endif
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{date('m-d-Y h:i A', strtotime($values->created_on))}} </dd>
  </dl>
  
  @elseif($values->status == 6)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Phone :</dt>
    <dd> +{{$values->country_code}} {{$values->phone}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{date('m-d-Y h:i A', strtotime($values->created_on))}} </dd>
  </dl>
  
  @elseif($values->status == 7)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found Lost </dd>
      <div class="hr-line-dashed"></div>
    <dt>Updated By :</dt>
    @if(!empty(getUserdetails($values->updated_by)))
    <dd> {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} 
      @if($values->updated_by == 1)
      (Super Admin)
      @elseif($values->updated_by == 4)
      (CS Agents)
      @else
      (User)
      @endif 
      @else
      - 
      @endif
      </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Last seen :</dt>
    <dd> {{$values->lastseen_location}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Last seen On :</dt>
    <dd> {{$values->lastseen_on}} {{$values->lastseen_time}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{date('m-d-Y h:i A', strtotime($values->created_on))}} </dd>
  </dl>
  @elseif($values->status == 8)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Reactivated </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{date('m-d-Y h:i A', strtotime($values->created_on))}} </dd>
      <div class="hr-line-dashed"></div>
  </dl>
  @endif 
  
  </li><br/>
  @endforeach
  </ul>
  @endif  
  
  @if(!isset($data[0]))
  <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  @endif </div>
  </div>
@endsection
@section('breadcrumbs')
 {!! Breadcrumbs::render('products/details/{tagId}') !!}   
@endsection 