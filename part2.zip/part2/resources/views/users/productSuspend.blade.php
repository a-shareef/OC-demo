@extends('layouts.user')
@section('title', 'Product Suspend')
@section('content')

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        {{ session('error') }}
    </div>
</div>
@endif

<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span><div></div></div>
<form name="productsuspend" class="form-horizontal" data-toggle="validator" method="POST" action="{{ route('productsuspendadd') }}">
{!! csrf_field() !!}
<!-- Form Name -->
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Product Suspend Information</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div><div class="ibox-content">
<fieldset class="formFiled">
<input type="hidden" value="{{ $loggedinuserid }}" name="loggedinuserid" />
<input type="hidden" value="{{$currentproductid}} " name="currentproductid" />
<input type="hidden" value="{{ $ip }}" name="ip" />


<!-- Product Details From -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="product">
   Product Name:
  </label>
  <div class="col-sm-7">
  <input id="productname" name="productname" type="text"  class="form-control input-md" disabled="disabled" value=" {{$current_productname}} ({{$current_productsequence}})">
 
  </div>
</div>
 <div class="hr-line-dashed"></div>
<!-- Textarea -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="remarks">
   Reason:
  </label>
  <div class="col-sm-7">
    <textarea class="form-control" id="remarks" name="remarks" required value=""></textarea>
  </div>
</div>

        <!-- Button -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="cancel"></label>
  <div class="col-sm-7">
  @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Report Suspend') == true))
    <input type="submit"  name="Submit" value="Submit" id="productsuspend_submit" name="productsuspend_submit" class="btn btn-primary"/>
  @endif  
    <input class="btn btn-secondary" type="reset" value="Reset">
</div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group">

  </div>
  </div>

</fieldset>
</form>
 
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/product/productsuspend/{product_id}') !!}
@endsection

 