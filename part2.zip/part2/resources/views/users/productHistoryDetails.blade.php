 @extends('layouts.plain')
@section('title', 'Tag # Details')
@section('content')

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag Details:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">

  @if(!$viewData->isEmpty())

  @php
    $values =  $viewData[0];
  @endphp

   <dl class="dl-horizontal">  
      <div class="hr-line-dashed"></div>
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Product :</dt>
    <dd> {{$values->product_name}} </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Order Number :</dt>
    <dd> {{$values->order_no}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Company Name :</dt>
    <dd> {{$values->company_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Order Description :</dt>
    <dd> 
      @if(!empty($values->description) && isset($values->description)) {{$values->description}} @else {{ '-' }} @endif
    </dd>
      <div class="hr-line-dashed"></div>
       <dt>Order Status :</dt>
    <dd> @if(!empty($orderStatus) && isset($orderStatus)){{$orderStatus}} @else {{ '-' }} @endif </dd>
      <div class="hr-line-dashed"></div>
    <dt>Order Date :</dt>
    <dd> {{$values->order_date}} </dd>
      <div class="hr-line-dashed"></div>  
    <dt>Product Status :</dt>
    <dd> {{$values->product_status}} </dd>
      <div class="hr-line-dashed"></div>
    @if($values->fk_user_id != '' && $values->fk_user_id > 0) 
   
    <dt>User Name :</dt>

    <dd> 
     @if(!empty(getUserdetails($values->fk_user_id)))

      {{getUserdetails($values->fk_user_id)[0]->first_name}} {{getUserdetails($values->fk_user_id)[0]->last_name}}
      @else
      {{ "No record" }}
      @endif
    </dd>
  
    <div class="hr-line-dashed"></div>
     <dt>Registered Date :</dt>
    <dd> {{$values->registration_date}} </dd>
     <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$reg_ipaddr}} </dd>
     @endif
  </dl>
  @endif  

   @if($viewData->isEmpty())
  <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  @endif </div>
  </div>

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag History:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>


<div class="ibox-content">

  @if(isset($tagHistory))
  <ul class="sortable-list connectList agile-list ui-sortable" id="todo"> 

  @foreach($tagHistory as $key => $values)
  <li class="warning-element ui-sortable-handle" id="task1">
  
  @if($values->status == 3)
  <dl class="dl-horizontal">  
      
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>

    <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Updated By :</dt>

    <dd> 

      @if(!empty($values->updated_by) && $values->updated_by > 0)

      @if(!empty(getUserdetails($values->updated_by)))
      {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} 
     

      @if($values->updated_by == 1)
      (Super Admin)
      @elseif($values->updated_by == 4)
      (CS Agents)
      @else
      (User)
      @endif
      @else
      {{ 'No record' }}
       @endif 
       @endif
        </dd>

      <div class="hr-line-dashed"></div>
    <dt>Product Last seen :</dt>
    <dd> {{$values->lastseen_location}} </dd>
      <div class="hr-line-dashed"></div>

    <dt>Last seen On :</dt>
    <dd> {{$values->lastseen_on}} {{$values->lastseen_time}} </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>

    <dt>Date :</dt>

    <dd> {{$values->created_at}} </dd>
  </dl>

  @elseif($values->status == 4)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Suspend </dd>
      <div class="hr-line-dashed"></div>
    @if($values->updated_by != '')
    <dt>Suspended By :</dt>

    @if(!empty(getUserdetails($values->updated_by)))
    <dd> {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} </dd>
    @else
    <dd>No record</dd>
    @endif
      <div class="hr-line-dashed"></div>
    @endif
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{$values->created_at}}</dd>
  </dl>
  @elseif($values->status == 5)
  @if($values->fk_user_id == 0 || $values->fk_user_id == '')
  <dl class="dl-horizontal">
    <dt>Product Never Registered.</dt>
  </dl> 
      <div class="hr-line-dashed"></div>
  @endif
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    @if(!empty($values->country_code) && !empty($values->phone))
    <dt>Phone :</dt>
    <dd> +{{$values->country_code}} {{$values->phone}} </dd>
      <div class="hr-line-dashed"></div>
    @endif
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{$values->created_at}} </dd>
  </dl>
  @elseif($values->status == 6)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Phone :</dt>
    <dd> +{{$values->country_code}} {{$values->phone}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{$values->created_at}} </dd>
  </dl>
  @elseif($values->status == 7)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found Lost </dd>
      <div class="hr-line-dashed"></div>
    <dt>Updated By :</dt>
    <dd> {{getUserdetails($values->updated_by)[0]->first_name}} {{getUserdetails($values->updated_by)[0]->last_name}} 
      @if($values->updated_by == 1)
      (Super Admin)
      @elseif($values->updated_by == 2)
      (Admin)
      @elseif($values->updated_by == 4)
      (CS Agents)
      @else
      (User)
      @endif </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Lastseen :</dt>
    <dd> {{$values->lastseen_location}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Lastseen On :</dt>
    <dd> {{$values->lastseen_on}} {{$values->lastseen_time}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{$values->created_at}}</dd>
  </dl>
  @elseif($values->status == 8)
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> {{$values->order_sequence}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Reactivated </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> {{$values->first_name}} {{$values->last_name}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> {{$values->email}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> {{$values->ip}} &nbsp;&nbsp; Indicated what3words location for the event: <a href="{{$values->location}}" class="external" target="_blank" >{{$values->location}}</a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> {{$values->lastseen_remarks}} </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> {{$values->created_at}} </dd>
  </dl>
  @endif 
  
  </li><br/>
  @endforeach
  </ul>
  @endif  
  
  @if(!isset($tagHistory[0]))
  <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  @endif </div>
  </div>

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag Transfer History:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">
  @if(isset($tagTransferHistory['data'][0])) 


  @foreach($tagTransferHistory['data'] as $key => $values)

  
  <ul class="sortable-list connectList agile-list ui-sortable" id="todo">
    @foreach($tagTransferHistory['tagTransferFrom'] as $transfer)
  @if(!empty($transfer['trans_notes']))
   <li class="warning-element ui-sortable-handle" id="task1">
                              
    

    <dl class="dl-horizontal">
     
      <dt>Tag # :</dt>
    <dd>
    {{ $transfer['tag_id'] }}
    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Tag Transferred FROM :</dt>
    <dd>
    {{ $transfer['from_email'] }}
    </dd>
    <div class="hr-line-dashed"></div>
      <dt>Tag Transferred TO :</dt>
    <dd>
    {{ $transfer['to_email'] }}
    </dd>
    <div class="hr-line-dashed"></div>
      <dt>Tag Status :</dt>
    <dd>
    {{ $transfer['tag_status'] }}
    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Notes on Transaction :</dt>
    <dd>
    @if(!empty($transfer['trans_notes']) && isset($transfer['trans_notes'])) {{$transfer['trans_notes']}} @else {{ '-' }} @endif
    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Tag Transfer Date and Time (UTC) :</dt>
    <dd>
    {{ $transfer['tranfer_date'] }}
    </dd>
    <div class="hr-line-dashed"></div>
      <dt>SA/A/CS Name :</dt>
    <dd>
    {{ $transfer['name'] . ' ( ' . $transfer['role'] .' )' }}
    </dd>
    </li><br/>
      @endif
    @endforeach
    </ul>

  @if(empty($tagTransferHistory['tagTransferFrom'][0]['trans_notes']))
    <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  @endif
  </dl>
@endforeach
@endif
 @if(empty($tagTransferHistory['data'][0]))
    <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  @endif

 </div>
</div>

@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('products/historyDetails/{tagId}') !!}
@endsection