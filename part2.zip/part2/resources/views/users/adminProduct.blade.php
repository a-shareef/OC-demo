@extends('layouts.dashboard')
@section('title', 'Products')
@section('content')
<!-- Form Name -->

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        {{ session('error') }}
    </div>
</div>
@endif

 @if(hasrole() == 2 || hasrole() == 1)
<h2>{{ $getTranslatedLang['product_add_new_product'] }} </h2>
@endif
<!-- Button -->
<div class="form-group">
  <div class="col-md-12 col-sm-12 col-xs-12 input-group btnSubmit">
    <!-- <button type="button" id="add_product" name="add_product" class="btn btn-success">Add new product</button> -->

     @if(hasrole() == 2 || hasrole() == 1)
    <button type="button" id="addProduct" name="addProduct" class="btn btn-primary">{{ $getTranslatedLang['product_add_new_product'] }}</button>
    @endif
    <div class="btnGeneratePin"  id="btnGeneratePin" style="display: none;">
    <button type="button" id="generate_pin" name="generate_pin" class="btn btn-primary">{{ $getTranslatedLang['product_generate_pin'] }}</button>

    <input id="randPin" autocomplete="off"  name="randPin" type="text" onkeypress='return event.charCode >= 48 && event.charCode <= 57' maxlength="6"  placeholder="{{ $getTranslatedLang['product_pin'] }}" class="form-control input-xs" required="" value={{ generatePins() }}>
	</div>
  </div>
</div>
<!-- Select Basic -->
<form class="form-horizontal" method="POST">
{!! csrf_field() !!}
<div class="tableContentBox showProductBox">
            <input type="hidden" id="token" value="{{ csrf_token() }}">
<h2>{{ $getTranslatedLang['product_id_products'] }} - ({{count($retriveProduct)}})</h2>

@if($retriveProduct)
    <div class="tblScroll tblScroll1">
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered" id="productDisplay">
        <thead>
            <tr>
                <th width="30%"><div class="wth1Box">{{ $getTranslatedLang['product_type'] }}</div></th>
                <th width="8%"><div class="wth2Box">{{ $getTranslatedLang['product_pin'] }}</div></th>
                <th width="20%"><div class="wth3Box">{{ $getTranslatedLang['product_status'] }}</div></th>
                <th width="7%"><div class="wth4Box">{{ $getTranslatedLang['product_language'] }}</div></th>
                <th width="20%"><div class="wth5Box"></div></th>
            </tr>
        </thead>
        <tbody>

            @foreach($retriveProduct as $value)
            <tr>
                <td>{{$value->product_name}}</td>
                <td>{{$value->product_pin}}</td>
                <td>{{$value->product_status}}</td>
                <td>{{$value->language_name}}</td>
                <input type="hidden" name="user_email" id="user_email" value="{{ $value->email }}" />
                <input type="hidden" name="user_first_name" id="user_first_name" value="{{ $value->first_name }}" />
                <input type="hidden" name="user_last_name" id="user_last_name" value="{{ $value->last_name }}" />
                <input type="hidden" name="user_product_id" id="user_product_id" value="{{ $value->id }}" />

                <td>
                <div class="whtSpace">

                @if($value->fk_product_status == 1)

                <button type="button" id="reportProductLost" name="reportProductLost" disabled="disabled" class="btn btn-primary reportProductLost">{{ $getTranslatedLang['product_report_lost'] }}</button>

                 @elseif($value->fk_product_status == 2 && $value->fk_product_status != 3)

                <button type="button" id="reportProductLost" name="reportProductLost" class="btn btn-primary reportProductLost">{{ $getTranslatedLang['product_report_lost'] }}</button>

                  @elseif ($value->fk_product_status == 3)

                <button type="button" id="reActivateProduct" name="reActivateProduct"  class="btn btn-primary reActivateProduct">{{ $getTranslatedLang['product_reactivate'] }}</button>

                <a href="{{url('/')}}" id="replaceProduct" target="_blank" name="replaceProduct"  class="btn btn-primary">{{ $getTranslatedLang['product_replace'] }} </a>

                  @endif

                 <input type="hidden" name="productId" id="productId" value="{{ $value->id }}" />
                 <input type="hidden" name="user_product_name" id="user_product_name" value="{{ $value->product_name }}" />
                </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
@endif

</form>

<div class="showProductBox formFiled">
<form class="form-horizontal" method="POST" action="{{ route('saveProduct') }}">
{!! csrf_field() !!}
<input type="hidden" name="user_id" id="user_id" value="{{ $user_id }}" />


<fieldset>

<div id="showProduct" style="display: none;">
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered">
        <thead>
            <tr>
                <td width="15%"><div class="wth1Box"><select id="product_name" name="product_name" class="form-control">
     @foreach($products as $product)
      <option value="{{  $product->product_id }}">{{ $product->product_name }}</option>
      @endforeach
    </select></div></td>
                <td width="15%"><div class="wth2Box"><input id="pin" name="pin" type="text" autocomplete="off" onkeypress='return event.charCode >= 48 && event.charCode <= 57' minlength="6" maxlength="6" placeholder="Enter Pin" class="form-control input-md" required=""></div></td>
                <td width="20%"><div class="wth3Box"><select id="status" name="status" class="form-control">
     @foreach($status as $prodStatus)
      <option value="{{  $prodStatus->id }}">{{ $prodStatus->product_status }}</option>
      @endforeach
    </select></div></td>
                <td width="20%"><div class="wth4Box"><select id="language" name="language" class="form-control">
     @foreach($lang as $language)
      <option value="{{  $language->language_id }}">{{ $language->language_name }}</option>
     @endforeach
    </select></div></td>



                <td width="30%" class="submitBtn"><div class="wth5Box"><input type="submit" id="add_entry" name="add_entry" class="btn btn-primary" value="{{ $getTranslatedLang['product_add'] }}"></input></div></td>
            </tr>
        </thead>
    </table>
  </div>
</div>

   </div>

</fieldset>
</form>
</div>

@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/product/user/{user_id}') !!}
@endsection