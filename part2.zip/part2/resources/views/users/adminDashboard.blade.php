@extends('layouts.dashboard')
@section('title', 'Dashboard')
@section('content')

<div class="alert-ajax alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif

<div class="row">
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-success pull-right">Total</span>
        <h5>Members</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins">{{$totalmembers}}</h1>
        {{-- <div class="stat-percent font-bold text-success">98% <i class="fa fa-bolt"></i></div> --}}
        <small>Total Members</small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-info pull-right">Total</span>
        <h5>Orders</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins">{{$ordercount}}</h1>
        {{-- <div class="stat-percent font-bold text-info">20% <i class="fa fa-level-up"></i></div> --}}
        <small>Orders</small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-primary pull-right">Monthly</span>
        <h5>Product Registered</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins">{{$prodregcount}}</h1>
        {{-- <div class="stat-percent font-bold text-navy">44% <i class="fa fa-level-up"></i></div> --}}
        <small>Product Registered In {{date('M Y')}}</small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-danger pull-right">Today</span>
        <h5>User Login activity</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins">{{$userlogincount}}</h1>
        {{-- <div class="stat-percent font-bold text-danger">38% <i class="fa fa-level-down"></i></div> --}}
        <small>Login activity on  {{date('M-d-Y')}}</small> </div>
    </div>
  </div>
</div>


<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>{{$translatedLang['dashboard_account_users']}}</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="row">
      <div class="form-group col-md-3 col-sm-4 col-xs-6">
        <select required id="client_products" name="client_products" class="form-control" >
          <option value="">Select client products</option>

          @foreach($productArray as $key => $product)

          <option value="{{$key}}"> {{$product}} </option>

          @endforeach

        </select>
      </div>
    </div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="users-table">
        <thead>
          <tr>
            <th data-priority="1">{{$translatedLang['dashboard_name']}}</th>
            <th>{{$translatedLang['dashboard_email']}}</th>
            <th>{{$translatedLang['dashboard_address']}}</th>
            <th>{{$translatedLang['dashboard_phone']}}</th>
            <th>{{$translatedLang['dashboard_dob']}}</th>
            <!-- <th>Member type</th> -->
            <th class="none">{{$translatedLang['dashboard_products']}}</th>
            <th data-priority="3">{{$translatedLang['dashboard_status']}}</th>
            <th data-priority="2">{{$translatedLang['dashboard_action']}}</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>{{$translatedLang['dashboard_admin_cs_agents']}}</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
  	<div class="row"><div class="form-group col-md-12 col-sm-12 col-xs-12 text-right"><a href="{{url('/')}}/user/csa" class='btn btn-primary btn-xs pull-right'><i class="fa fa-plus" aria-hidden="true"></i> {{$translatedLang['dashboard_add_new']}}</a></div></div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="csa-table">
        <thead>
          <tr>
            <th data-priority="1">{{$translatedLang['dashboard_name']}}</th>
            <th>{{$translatedLang['dashboard_email']}}</th>
            <th>{{$translatedLang['dashboard_type']}}</th>
            <th>{{$translatedLang['dashboard_phone']}}</th>
            <th>{{$translatedLang['dashboard_last_activity_on_date']}}</th>
            <th data-priority="2">{{$translatedLang['dashboard_action']}}</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage Order Status</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
  <div class="row"><div class="form-group col-md-12 col-sm-12 col-xs-12 text-right"><a href="{{url('/')}}/admin/order/add" class='btn btn-primary btn-xs pull-right'><i class="fa fa-plus" aria-hidden="true"></i> {{$translatedLang['dashboard_add_new']}} </a></div></div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="mup-table">
        <thead>
          <tr>
            <th data-priority="1">Company</th>
            <th>Order No</th>
            <th>Products</th>
            <th>Qty</th>
            <th>Reg</th>
            <th>Unreg</th>
            <th>Order Date</th>
            <th data-priority="3">Order Status</th>
            <th data-priority="2">{{$translatedLang['dashboard_action']}}</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage Suspended / Lost / Found Products</h5>
    <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="msp-table">
        <thead>
          <tr>
            <th data-priority="1">Name</th>
            <th>Email</th>
            <th>Products</th>
            <th>Tag #</th>
            <th>FoundThem Date</th>
            <th data-priority="3">Status</th>
            <th data-priority="2">Action</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<!-- FT tag tranfer section start -->
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Transfer FT Tag</h5>
    <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="tt-table">
        <thead>
          <tr>
            <th data-priority="1">Name</th>
            <th>Email</th>
            <th>Products</th>
            <th>Tag #</th>
            <th>Registered Date</th>
            <th data-priority="3">Status</th>
            <th data-priority="2">Action</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<!-- FT tag tranfer section end -->
<script src="/assets/js/jquery-1.10.2.min.js"></script>
<script src="{{url('/')}}/assets/js/chartJs/Chart.min.js"></script>
<!-- <script src="{{url('/')}}/assets/js/chartJs/chartjs-demo.js"></script> -->
<input type="hidden" id="search" value="{{$translatedLang['dashboard_search']}}">
<input type="hidden" id="next" value="{{$translatedLang['dashboard_next']}}">
<input type="hidden" id="first" value="{{$translatedLang['dashboard_first']}}">
<input type="hidden" id="last" value="{{$translatedLang['dashboard_last']}}">
<input type="hidden" id="previous" value="{{$translatedLang['dashboard_previous']}}">
<input type="hidden" id="record_per_page" value="{{$translatedLang['dashboard_record_per_page']}}">
<input type="hidden" id="display" value="{{$translatedLang['dashboard_display']}}">
<input type="hidden" id="dashboard_of" value="{{$translatedLang['dashboard_of']}}">
<input type="hidden" id="showing_page" value="{{$translatedLang['dashboard_showing_page']}}">
<input type="hidden" id="token" value="{{ csrf_token() }}">
@endsection
