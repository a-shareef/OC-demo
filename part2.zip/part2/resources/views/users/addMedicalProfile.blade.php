<!-- resources/views/user/assignDelegate.blade.php -->
@extends('layouts.user')
@section('title', 'User Medical Profile')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
        {{ session('status') }}
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
        {{ session('error') }}
</div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span><div></div></div>
<div class="tableContentBox addDele">
<form class="form-horizontal" data-toggle="validator" method="POST" action="/user/medical-surgery">
<fieldset>
{!! csrf_field() !!}
<!-- Form Name -->
<legend>Surgery:</legend>
<input type="hidden" value="{{$user_id}}" name="userId" />
<div class="form-group">
   <div class="col-md-2 col-sm-2 col-xs-2">
            <input type="checkbox" name="chk_surgery_visible"
            value="true">
            <span id="chk_surgery_visible">Visible to First Responder/EMS</span>
          </div>
          </div>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="title">Title:</label>
  <div class="col-md-4">
  <input id="title" name="title" type="text" placeholder="Title" class="form-control input-md" required="">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('title')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="surgery_date">Date:</label>
  <div class="col-md-4">
  <input id="surgery_date" name="surgery_date" type="text"
  placeholder="Date" class="form-control input-md" required="">
 <span class="input-group-addon">
    <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
 </span>
 <div class="alert-message alert-danger">{{$errors->first('surgery_date')}}</div>
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="outcome">Outcome:</label>
  <div class="col-md-4">
    <textarea class="form-control" id="outcome" name="outcome"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="files_linked">Files / Linked:</label>
  <div class="col-md-5">
  <input id="files_linked" name="files_linked" type="text" placeholder="Files / Linked" class="form-control input-md">

  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="doctor">Doctor:</label>
  <div class="col-md-4">
  <input id="doctor" name="doctor" type="text" placeholder="Doctor" class="form-control input-md" required="">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('doctor')}}</div>
  </div>
</div>


        <!-- Button -->
  <div class="form-group">
   <label class="col-md-3 col-sm-4 col-xs-4 control-label" for="cancel"></label>
   <div class="col-md-4 col-sm-6 col-xs-6 input-group submitBtn">
    <button id="profile_submit" name="profile_submit"
    class="btn btn-primary">Submit</button>
    <input class="btn btn-primary" type="reset" value="reset">
</div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group">

  </div>
  </div>

</fieldset>
</form>

@endsection
@section('script')
<script src="/assets/bootstrap/js/validator.js"></script>
<script src="/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="/assets/js/profile.js"></script>
@endsection