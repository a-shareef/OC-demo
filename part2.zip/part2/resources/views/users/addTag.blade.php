<!-- resources/views/user/assignDelegate.blade.php -->
@extends('layouts.user')
@section('title', 'Add New Tag')
@section('content')

<form class="form-horizontal" data-toggle="validator" action="">
  {!! csrf_field() !!}
  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Add New Tag</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>

  <div class="ibox-content">
  <input type="hidden" value="{{$userId}}" name="userId" id="userId" />
  <input type="hidden" id="token" value="{{ csrf_token() }}">
 <div class="form-group">
     <label class="col-sm-3 control-label" for="notes"> Tags: </label>
  <div class="col-sm-7">
   
      <select id="tokenize" multiple="multiple" class="tokenize-sample form-control">
       
      </select>
 
  </div>
  <input type="hidden" id="hdn_tag_value" data-tag="" value="">
   </div>
   
  <div class="hr-line-dashed"></div>

  <div class="form-group">
     <label class="col-sm-3 control-label" for="notes"> Existing Tags: </label>
  <div class="col-sm-7">
   
      <select id="existing-tokenize" multiple="multiple" class="tokenize-sample form-control">
      @php
      		
      		foreach($tag_data as $tag_value){

      		
      @endphp
       <option value="{{ $tag_value->id }}" selected = "selected" >{{ $tag_value->tag_name}}</option>
       @php
      		}
      @endphp
      </select>
 
  </div>
   </div>
<div class="hr-line-dashed"></div>

   <div class="form-group">
   
  <!-- Button -->

     <label class="col-sm-3 control-label" for="notes"> </label>
    <div class="col-sm-7">
      <button id="tag_submit" name="tag_submit"
      class="btn btn-primary">Add</button>
      <!-- <button id="profile_submit" name="profile_submit"
      class="btn btn-primary">Delete</button> -->
      <input class="btn btn-secondary" type="button" onClick='return cancelDonation()' value="Cancel">
    </div>

  </div>

</form>
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('users/tagging/{user_id}') !!}
@endsection 