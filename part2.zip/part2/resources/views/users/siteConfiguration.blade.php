@extends('layouts.plain')
@section('title', 'Site Configuration')

@section('style')
<link href="{{url('/')}}/assets/bootstrap/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />
@endsection
@section('content')
@if (session('success'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('success') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
@php $languageTrans = languageTranslate("Site Configuration ") @endphp
<form enctype="multipart/form-data" method="post" action="{{url('/')}}/site-config-logo" class="form-horizontal">
  {!! csrf_field() !!}
  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>{{$languageTrans['site_config']}}</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
  <div class="form-group">
    <label class="col-sm-3 control-label"> {{$languageTrans['site_config_select_file']}}: </label>
    <div class="col-sm-7 browseFile">
      <input id="input-4" name="file_upload" type="file" class="file-loading">
    </div>
  </div>
      <div class="hr-line-dashed"></div>
</form>
<div class="formFiled">
  <form method="post" action="{{url('/')}}/site-config-slogan" class="form-horizontal">
    {!! csrf_field() !!} 
    <!-- Textarea -->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="slogan"> {{$languageTrans['site_config_update_slogan']}}: </label>
      <div class="col-sm-7">
        <textarea class="form-control" id="slogan" name="slogan"></textarea>
      </div>
    </div>
      <div class="hr-line-dashed"></div>
    
    <!-- Button -->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="btnslogan"></label>
      <div class="col-sm-7">
      @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('Site Config', 'Edit') == true))
        <button id="btnslogan" name="btnslogan" class="btn btn-primary"> {{$languageTrans['site_config_update']}} </button>
      @endif  
        <input class="btn btn-primary" type="reset" value=" {{$languageTrans['site_config_reset']}}">
      </div>
    </div>
  </form>
</div>
</div>
<input type="hidden" id="upload_image" value="{{$languageTrans['site_config_upload_image']}}" />
<input type="hidden" id="browse_image" value="{{$languageTrans['site_config_browse_image']}}" />
<input type="hidden" id="remove_image" value="{{$languageTrans['site_config_remove_image']}}" />
@endsection

@section('script') 
<script src="{{url('/')}}/assets/bootstrap/js/fileinput.min.js"></script> 
<script type="text/javascript" src="/assets/js/siteConfig.js"></script> 
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('/user/site-config') !!}
@endsection 