@extends('layouts.user')
@section('title', 'Language')
@section('content')
<h2>{{ $getTranslatedLang['language_heading_language'] }}</h2>

<form id="lang-form" method="post" class="form-horizontal" data-toggle="validator" role="form">
<fieldset class="formFiled">
 {!! csrf_field() !!}
            <h3>{{ $getTranslatedLang['language_current'] }}</h3>
<input type="hidden" id="userId" value="{{$userId}}">
<input type="hidden" name="user-date-format" id="user-date-format" value="{{$userDateFormat ? "$userDateFormat" : 'MM/DD/YYYY' }} "/>
<div class="tblScrolllang">
  <table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered">
              <tr>
                  <th width="25%"><div class="wth1Box"></div></th>
                  <th width="25%"><div class="wth2Box">{{ $getTranslatedLang['language_from_date'] }}</div></th>
                  <th width="25%"><div class="wth5Box">{{ $getTranslatedLang['language_to_date'] }}</div></th>
                  <th width="25%"><div class="wth5Box"></div></th>
              </tr>

                  <tr>

                   @forelse($getUserCurrentLanguage as $userData)

                      <td>
                              <input type="hidden" name="user-lang" id="user-lang" value="{{$userData->id ? "$userData->id" : '' }} "/>

                                <select id="user-language" name="user-language" class="form-control" disabled>
                                @foreach ($getLanguages as $languages)
                                    <option value="{{ $languages->language_id }}" {{ $userData->fk_language_id ==  $languages->language_id ? 'selected' : '' }} >{{ $languages->language_name }}</option>
                                @endforeach
                                </select>
                      </td>
                      <td>
                        <?php

$currentStartDate = date("$format", strtotime($userData->start_date));
$currentEndDate = date("$format", strtotime($userData->end_date));
?>

                                  <div class='input-group date date-picker' id='start-date'>
                                    <input type='text' class="form-control datepicker" id="current-from-date" name="current-from-date" type="text"placeholder="" class="form-control input-md" disabled value="{{ $userData->start_date ? "$currentStartDate" : '' }}" />
                                    <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
            </span>
                                 </div>
                      </td>
                      <td>
                                  <div class='input-group date date-picker' id='end-date'>
                                      <input type='text' class="form-control datepicker" id="current-to-date" name="current-to-date" type="text"placeholder="" class="form-control input-md" disabled value="{{ $userData->end_date ? "$currentEndDate" : '' }}"/>
                                      <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
            </span>
                                 </div>
                      </td>
                      @empty
                          <td>
                                    <input type="hidden" name="user-lang" id="user-lang" value=""/>
                                    <select id="user-language" name="user-language" class="form-control" disabled>

                                    @foreach ($getLanguages as $languages)
                                        <option value="{{ $languages->language_id }}">{{ $languages->language_name }}</option>
                                    @endforeach
                                    </select>
                          </td>
                          <td>
                                      <div class='input-group date date-picker' id='start-date'>
                                        <input type='text' class="form-control datepicker" id="current-from-date" name="current-from-date" type="text"placeholder="" class="form-control input-md" disabled />
                                        <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
            </span>
                                     </div>
                          </td>
                          <td>
                                      <div class='input-group date date-picker' id='end-date'>
                                          <input type='text' class="form-control datepicker" id="current-to-date" name="current-to-date" type="text"placeholder="" class="form-control input-md" disabled />
                                          <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
            </span>
                                     </div>
                          </td>
                      @endforelse
                      <td>
                               <button type="submit" class="btn btn-primary" id="click-to-change" disabled>{{ $getTranslatedLang['language_click_to_change'] }}</button>
                                <button type="submit" class="btn btn-primary" id="update">{{ $getTranslatedLang['language_update'] }}</button>
                      </td>
                  </tr>



      </table>
</div>

<div class="tblScroll">
<h3>{{ $getTranslatedLang['language_previous'] }}</h3>
    <table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered">
            <tr>
                <th width="25%"><div class="wth1Box"></div></th>
                <th width="25%"><div class="wth2Box">{{ $getTranslatedLang['language_from_date'] }}</div></th>
                <th width="25%"><div class="wth5Box">{{ $getTranslatedLang['language_to_date'] }}</div></th>
            </tr>
            @forelse($getUserPreviousLanguage as $userData)
                <tr>
                    <td>
                              <label class="control-label" for="role">
                               @foreach ($getLanguages as $languages)
                                  @if($userData->fk_language_id == $languages->language_id)
                                    {{ $languages->language_name }}
                                  @endif
                               @endforeach
                              </label>
                    </td>
                    <td>
                                <?php
$startDate = date("$format", strtotime($userData->start_date));
$endDate = date("$format", strtotime($userData->end_date));
?>
                                  <label class="control-label">{{$startDate}}</label>
                    </td>
                    <td >
                                  <label class="control-label">{{$endDate}}</label>
                    </td>
                </tr>
            @empty
            <th colspan="3">
              {{ $getTranslatedLang['language_no_previous_languages'] }}
            </th>
            @endforelse
    </table>
  </div>
</fieldset>
</form>
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('user/language/{user_id?}') !!}
@endsection

