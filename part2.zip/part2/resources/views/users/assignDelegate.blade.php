<!-- resources/views/user/assignDelegate.blade.php -->
@extends('layouts.dashboard')
@section('title', 'Connections')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        {{ session('error') }}
    </div>
</div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span><div></div></div>
<div class="tableContentBox addDele">
<a href="/user/{{userIdEncode($userId)}}/delegate/add"  class='btn btn-md btn-primary'>
    {{$translatedLang['assigned_delegates_add_delegate']}}
</a>
@if($activeDelegateData)
<h2>{{$translatedLang['assigned_delegates_text']}}:</h2>
<div class="tblScroll">
	<table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$translatedLang['assigned_delegates_name']}}</th>
               <th>{{$translatedLang['assigned_delegates_relationship']}}</th>
               <th>{{$translatedLang['assigned_delegates_connections']}}</th>
               <th>{{$translatedLang['assigned_delegates_alert']}}</th>
               <th>{{$translatedLang['assigned_delegates_actions']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($activeDelegateData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
               <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}} {{$value->user_phone}}</td>
               <td><input type="checkbox" @if($value->alert_notification == 0) checked @endif
                  onclick="$(this).val(this.checked ? 0 : 1);alertstatus({{$value->id}},this.value);" /></td>
                <td class="btnDtls">
                  <a title='Edit Delegate' href="/user/{{userIdEncode($userId)}}/delegate/edit/{{userIdEncode($value->conection_user_id)}}"
                    class='btn btnUpdete'>Update details
                  </a>
                    <button title='Delete Delegate' onClick='return confirmDeleteDelegate({{$value->conection_user_id}})'
                        class='btn btnDelete'>
               Delete</button></td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif
</div>
<div class="tableContentBox addDele">
<a href="/user/{{userIdEncode($userId)}}/connection/add"  class='btn btn-md btn-primary'>
    {{$translatedLang['assigned_delegates_add_connection']}}
</a>
@if($activeConnectionData)
<h2>{{$translatedLang['assigned_connection_text']}}:</h2>
<div class="tblScroll">
  <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$translatedLang['assigned_delegates_name']}}</th>
               <th>{{$translatedLang['assigned_delegates_relationship']}}</th>
               <th>{{$translatedLang['assigned_delegates_connections']}}</th>
               <th>{{$translatedLang['assigned_delegates_alert']}}</th>
               <th>{{$translatedLang['assigned_delegates_actions']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($activeConnectionData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
               <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}} {{$value->user_phone}}</td>
                <td><input type="checkbox" @if($value->alert_notification == 0) checked @endif
                  onclick="$(this).val(this.checked ? 0 : 1);alertstatus({{$value->id}},this.value);" /></td>
                <td class="btnDtls">
                  <a title='Edit Connection' href="/user/{{userIdEncode($userId)}}/connection/edit/{{userIdEncode($value->conection_user_id)}}"
                    class='btn btnUpdete'>Update details
                  </a>
                    <button title='Delete Connection' onClick='return confirmDeleteDelegate({{$value->conection_user_id}})'
                        class='btn btnDelete'>
               Delete</button></td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif
</div>
<div class="tableContentBox">
@if($awaitingDelegateData)
<h2>{{$translatedLang['assigned_delegates_awaiting_response']}}:</h2>
<div class="tblScroll">
	<table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
               <th>{{$translatedLang['assigned_delegates_name']}}</th>
               <th>{{$translatedLang['assigned_delegates_relationship']}}</th>
               <th>{{$translatedLang['assigned_delegates_connections']}}</th>
               <th>{{$translatedLang['assigned_delegates_type']}}</th>
               <th>{{$translatedLang['assigned_delegates_actions']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($awaitingDelegateData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
                <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}} {{$value->user_phone}}</td>
                <td>@if($value->fk_role_id == 5) Delegate @else Connection @endif</td>

                <td class="btnDtls">
                  @if($value->fk_role_id == 5)
                   <a title='Edit Delegate' href="/user/{{userIdEncode($userId)}}/delegate/edit/{{userIdEncode($value->conection_user_id)}}"
                    class='btn btnUpdete'>Update details
                  </a>
                  @elseif($value->fk_role_id == 6)
                  <a title='Edit Connection' href="/user/{{userIdEncode($userId)}}/connection/edit/{{userIdEncode($value->conection_user_id)}}"
                    class='btn btnUpdete'>Update details
                  @endif
                   <a title='Resend Email Invitation' href="/resend/{{userIdEncode($value->conection_user_id)}}/user/{{userIdEncode($value->fk_user_id)}}"
                    class='btn btnResend'>Resend Invite</a>
                   <button title='Delete @if($value->fk_role_id == 5) Delegate @else Connection @endif' onClick='return confirmDeleteDelegate({{$value->conection_user_id}})'
                        class='btn btnDelete'>
               Delete</button></td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif
</div>

<div class="tableContentBox">
@if($meDelegateData)
<h2>{{$translatedLang['assigned_delegates_to_whom_delegate']}}:</h2>
<div class="tblScroll">
	<table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
        <thead>
            <tr>
                <th>{{$translatedLang['assigned_delegates_name']}}</th>
               <th>{{$translatedLang['assigned_delegates_relationship']}}</th>
               <th>{{$translatedLang['assigned_delegates_connections']}}</th>
               <th>{{$translatedLang['assigned_delegates_actions']}}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($meDelegateData as $value)
            <tr>
                <td>{{$value->first_name}} {{$value->last_name}}</td>
                <td>{{$value->relation_name}}</td>
                <td>{{$value->country_code}} {{$value->user_phone}}</td>
                <td class="btnDtls">
                   @if($value->fk_role_id == 5)
                   <a title='Edit Data' href="/user/delegate-edit/{{userIdEncode($value->fk_user_id)}}"
                    class='btn btnUpdete'>Update details</a>
                  @elseif($value->fk_role_id == 6)
                  <a target="_blank" title='View Data' href="/user/connection-view/{{$value->public_url}}"
                    class='btn btnUpdete'>Update details
                  @endif

                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif
</div>

<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="userId" value="{{$userId}}">
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('user/connections/{user_id}') !!}
@endsection

