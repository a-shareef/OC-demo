@extends('layouts.user')
@section('title', 'Product Lost')
@section('content')

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> {{ session('status') }} </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> {{ session('error') }} </div>
</div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Add Product Description</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row">
      <label class="col-md-12 imageBox"> <img id="tempProfileImage" src="{{ URL::to('/') }}/uploads/productavatar/{{$currentproductimage}}" class="img-circle">
        <input type="hidden" value="" id="imagewidthval">
        <input type="hidden" value="" id="imageheightval">
      </label>
      @if( $currentproductimage != 'productdefault.png')
      <div id="deleteformdiv" class="col-sm-4 text-center col-sm-offset-4 submitBtn profileBtnBox"> <br>
        <a href="#" class="btn btn-primary imagedelete">Replace</a> 
        <!-- btnimagedelete class for red color button --> 
        <a href="#" id="deleteimg" class="btn btn-primary imagedelete">Delete</a>
        <div class="modal fade" tabindex="-1" role="dialog" id="deletemodal">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-body">
                <h4 class="modal-title text-center">Are you sure you want to delete the FoundThem product image ?</h4>
              </div>
              <div class="modal-footer submitBtn">
                <form enctype="multipart/form-data" method="POST" action="">
                  <input type="hidden" value="@if(isset($currentproductid) && $currentproductid != ''){{$currentproductid}}@endif" name="userid">
                  <a href="/admin/productavatar/@if(isset($currentproductid) && $currentproductid != ''){{$currentproductid}}@else{{-1}}@endif" id="deleteimg" class="btn btn-primary">Yes</a>
                  <button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
                </form>
              </div>
            </div>
            <!-- /.modal-content --> 
          </div>
          <!-- /.modal-dialog --> 
        </div>
        <!-- /.modal --> 
      </div>
      @else
      <div id="updateformdiv" class="col-md-12 text-center">
        <form enctype="multipart/form-data" method="POST" action="{{url('/')}}/admin/product/image" role="form">
          <br>
          <input type="hidden" name="_token" value="{{ csrf_token()}}" id="token"/>
          <label>Upload Product Image</label>
          <br>
          <div class="btn btn-primary btn-file"> <i class="glyphicon glyphicon-folder-open"></i> <span class="hidden-xs">Browse</span>
            <input type="file" name="avatar" id="avatar"/>
          </div>
          <input type="hidden" name="x" id="x"/>
          <input type="hidden" name="y" id="y"/>
          <input type="hidden" name="w" id="w"/>
          <input type="hidden" name="h" id="h"/>
          <div class="modal fade" tabindex="-1" role="dialog" id="profilemodal">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Drag your mouse to select part of the image which you need to crop.</h4>
                </div>
                <div class="modal-body">
                  <div class="loader1"></div>
                  <image id="userimage"/>
                </div>
                <div class="modal-footer submitBtn">
                  <input type="hidden" value="@if(isset($currentproductid) && $currentproductid != ''){{$currentproductid}}@endif" name="productId"  id="productId"/>
                  <!--  <input type="hidden" value="@if(isset($users->fk_role_id) && $users->fk_role_id != ''){{$users->fk_role_id}}@endif" name="userIdroleprofile"  id="userIdroleprofile"/> --> 
                  <!-- <button type="button" id="rotateimage" class="btn btn-primary" >Rotate</button> -->
                  <input type="button" id="usersave" class="btn btn-primary" value="Crop and Upload" disabled>
                  <button type="button" id="closemodal" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
              </div>
              <!-- /.modal-content --> 
            </div>
            <!-- /.modal-dialog --> 
          </div>
        </form>
      </div>
      @endif </div>
      
      <div class="hr-line-dashed"></div>
    <form name="productlost" class="form-horizontal" data-toggle="validator" method="POST" action="{{ route('productdescadd') }}">
      {!! csrf_field() !!} 
      <!-- Form Name --> 
      
      <!-- Form Name -->
      <input type="hidden" value="{{ $loggedinuserid }}" name="loggedinuserid" />
      <input type="hidden" value="{{$currentproductid}} " name="currentproductid" />
      <input type="hidden" value="{{ $ip }}" name="ip" />
      <input type="hidden" name="token" value="{{ csrf_token()}}" id="token"/>
      <input type="hidden" name="userId" value="{{Session::get('userId')}}" id="userId"/>
      <!-- Product Details From -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product"> Product Name: </label>
        <div class="col-sm-7">
          <input id="location" name="location" type="text"  class="form-control input-md" disabled="disabled" value=" {{$current_productname}} ({{$current_productsequence}})">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="description"> User Description: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="description" name="description" required value="" placeholder="Item that the FoundThem tag is attached to. Example: backpack (140 characters)" maxlength="140">{{$user_description}}</textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Button -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="cancel"></label>
        <div class="col-sm-7">
        @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Add') == true))
          <input type="submit"  name="Submit" value="Submit" id="description_submit" name="description_submit" class="btn btn-primary"  />
        @endif  
          <input class="btn  btn-primary" type="reset" value="Reset">
          <a id="cancel-button" name="button2id" class="btn  btn-primary" href="{{route('displayUsersProduct',session('userId'))}}">Cancel</a> </div>
        <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
      </div>
    </form>
  </div>
</div>
@endsection
@section('script')
    <script src="/assets/bootstrap/js/validator.js"></script> 
    <script src="/assets/js/piexif.js"></script> 
   @endsection
 @section('breadcrumbs')
    {!! Breadcrumbs::render('admin/product/usersAddDescription/{user_id}') !!}
@endsection