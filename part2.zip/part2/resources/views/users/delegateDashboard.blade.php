@extends('layouts.dashboard')
@section('title', 'Dashboard')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
<div class="tableContentBox">
    <h2>{{$translatedLang['delegate_dashboard_users']}}</h2>
    <div class="tblScroll">
    <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="users-table">
        <thead>
            <tr>
               <th>{{$translatedLang['dashboard_name']}}</th>
                <th>{{$translatedLang['dashboard_email']}}</th>
                <th>{{$translatedLang['dashboard_address']}}</th>
                <th>{{$translatedLang['dashboard_phone']}}</th>
                <th>{{$translatedLang['dashboard_dob']}}</th>
                <th>{{$translatedLang['dashboard_products']}}</th>
                <th>{{$translatedLang['dashboard_action']}}</th>
            </tr>
        </thead>
    </table>
</div>
</div>
 <input type="hidden" id="search" value="{{$translatedLang['dashboard_search']}}">
    <input type="hidden" id="next" value="{{$translatedLang['dashboard_next']}}">
    <input type="hidden" id="first" value="{{$translatedLang['dashboard_first']}}">
    <input type="hidden" id="last" value="{{$translatedLang['dashboard_last']}}">
    <input type="hidden" id="previous" value="{{$translatedLang['dashboard_previous']}}">
    <input type="hidden" id="record_per_page" value="{{$translatedLang['dashboard_record_per_page']}}">
    <input type="hidden" id="display" value="{{$translatedLang['dashboard_display']}}">
    <input type="hidden" id="dashboard_of" value="{{$translatedLang['dashboard_of']}}">
    <input type="hidden" id="showing_page" value="{{$translatedLang['dashboard_showing_page']}}">
    <input type="hidden" id="token" value="{{ csrf_token() }}">
@endsection