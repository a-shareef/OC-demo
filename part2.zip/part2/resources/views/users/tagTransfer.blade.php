@extends('layouts.user')
@section('title', 'Tag Transfer')
@section('content')
@section('style')

<link href="{{url('/')}}/assets/bootstrap/css/select2.min.css" rel="stylesheet" />
<link href="{{url('/')}}/assets/bootstrap/css/typeahead.css" rel="stylesheet">

@endsection
@foreach($data as $product)
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FT Tag Transfer</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
  <form id="form-tag-transfer"  class="form-horizontal" data-toggle="validator" method="POST" action= "{{ route('post_tag')}}" role="form">
    <!-- Form Name -->
    {!! csrf_field() !!}
    <!-- Text input-->
    <div class="ibox-content">
    <input type="hidden" name="userID" id="userID" value="{{ $product->fk_user_id }}">
    <input type="hidden" name="from_user_email" id="from_user_email" value="{{ $product->email }}">
    <input type="hidden" id="token" name= "token" value="{{ csrf_token() }}">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textinput">Selected Tag # to transfer :</label>
        <div class="col-sm-7">
          <input id="ft_tag" name="ft_tag" type="text" placeholder="" class="form-control input-md" value="{{ $product->order_sequence }}" readonly>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
    
    <div class="form-group">
        <label class="col-sm-3 control-label" for="textinput">Transfer Tag to :</label>
        <div class="col-sm-7">
          <select id="search_box" name="search_box" class="form-control" required>
            <option value="">please select</option>
            @foreach($user_data as $value)
                @if($product->fk_user_id != $value->id)
            <option value="{{ $value->id }}"> {{ $value->full_name ."(". $value->email .")" }} </option>
            @endif
            @endforeach
        }
        }
        </select>
          </div>
      </div>
      <div class="hr-line-dashed"></div>

      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea">Notes for transaction :</label>
        <div class="col-sm-7">
          <textarea class="form-control" id="transfer_notes" name="transfer_notes" required></textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>

      <!-- Button (Double) -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="button1id"></label>
        <div class="col-sm-7">
        @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('Tag Transfer', 'Add') == true))
          <input type="submit" class="btn btn-primary" value="Submit" id= "tag_transfer_submit"/>
        @endif
          <a id="edit-cancel-button" name="button2id" class="btn btn-primary" href="{{route('admin_dashboard')}}">Cancel</a> </div>
      </div>
      @endforeach </div>
  </form>
</div>

<script src="{{url('/')}}/assets/js/jquery-1.10.2.min.js"></script>
<script src="{{url('/')}}/assets/js/tag_transfer.js"></script>
@endsection
@section('breadcrumbs')
{!! Breadcrumbs::render('products/tagTransfer/{tagId}') !!}
@endsection
