@extends('layouts.user')
@section('title', 'Product Lost')
@section('content')

@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> {{ session('status') }} </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> {{ session('error') }} </div>
</div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<form name="productlost" class="form-horizontal" data-toggle="validator" method="POST" action="{{ route('productlostadd') }}">
  {!! csrf_field() !!} 
  <!-- Form Name --> 
  
  <!-- Form Name -->
  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Product Lost Information</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <input type="hidden" value="{{ $loggedinuserid }}" name="loggedinuserid" />
  <input type="hidden" value="{{ $loggedinuserid }}" id="userId" />
  <input type="hidden" value="{{$currentproductid}} " name="currentproductid" />
  <input type="hidden" value="{{ $ip }}" name="ip" />
  <div class="ibox-content">
  <!-- Product Details From -->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="product">Product Name:</label>
    <div class="col-sm-7">
      <input id="location" name="location" type="text"  class="form-control input-md" disabled="disabled" value=" {{$current_productname}} ({{$current_productsequence}})">
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="location"> Product Last Seen : </label>
    <div class="col-sm-7">
      <textarea class="form-control" id="location" name="location" type="text" required value=""></textarea>
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger">{{$errors->first('location')}}</div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label"  for="lastseendate"> Date Last Seen: </label>
    <div class="col-sm-7">
      <div id="lastseendate" class="input-group date">
        <input name="lastseendate" type="text"
  placeholder="Enter Date" class="form-control input-md" required="" value="" pattern="(0[1-9]|1[0-12])[/](0[1-9]|[12][0-9]|3[01])[/](19|20)\d\d">
        <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span>
        <div class="alert-message alert-danger">{{$errors->first('lastseendate')}}</div>
      </div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label"  for="lastseendate"> Last Seen Time: </label>
    <div class="col-sm-7">
      <div id="datetimepicker" class="input-group date">
        <input name="lastseentime" type="text"  
  placeholder="Enter Time" class="form-control input-md" required="" value="" pattern="(0?[1-9]|1[012])(:[0-5]\d){0,2}(\x20[AP]M)">
        <span class="input-group-addon"> <span class="glyphicon glyphicon-time"></span> </span> </div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Textarea -->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="remarks"> Remarks: </label>
    <div class="col-sm-7">
      <textarea class="form-control" id="remarks" name="remarks" required value=""></textarea>
    </div>
  </div>
  <div class="hr-line-dashed"></div>

<!-- Button -->
  <div class="form-group">
  <label class="col-sm-3 control-label" for="cancel"></label>
  <div class="col-sm-7">
    @if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Report Lost') == true))
    <input type="submit"  name="Submit" value="Submit" id="productlost_submit" name="productlost_submit" class="btn btn-primary tagSubmit"/>
    @endif
    <input class="btn  btn-primary" type="reset" value="Reset">
  </div>
</form>
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/product/productlost/{product_id}') !!}
@endsection 