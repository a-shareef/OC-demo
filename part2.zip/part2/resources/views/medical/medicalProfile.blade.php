<!-- resources/views/user/assignDelegate.blade.php -->

@extends('layouts.dashboard')
@section('title', 'User Medical Profile')
@section('style')
<link href="/assets/bootstrap/css/bootstrap-tagsinput.css" rel="stylesheet">
@endsection
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<h2>{{$translatedLang['medical_profile']}}</h2>
<div class="tableContentBox addDele">
  <!-- Select Basic -->

  <form class="form-horizontal">
    <div class="row medicalProf bloodType foodAllBtn">
      <h3 class="col-md-2 col-sm-2 col-xs-2"> {{$translatedLang['edit_blood']}}: </h3>
      <div class="form-group col-md-3 col-sm-4 col-xs-4">
        <select id="blood" name="blood" class="form-control">

      @if(!$users->fk_blood_id)

          <option value="0">Select {{$translatedLang['edit_blood']}}</option>

      @endif
        @foreach($userBlood as $blood)

          <option value="{{$blood->blood_id}}"
            @if($users->fk_blood_id == $blood->blood_id)
          selected="selected"
          @endif >
          {{$blood->blood_group}} </option>

       @endforeach

        </select>
        <div id="alert-blood" class="alert-success hide alertBox"></div>
      </div>
      <div class="col-md-7 col-sm-6 col-xs-6 submitBtn">
        <label class="control-label">
          <input type="checkbox" onclick="$(this).val(this.checked ? 0 : 1);"
      id="chk_blood" value="1">
          <span id="chk_food_allergy">{{$translatedLang['medical_visible']}}</span> </label>
        <button id="blood_submit" name="profile_submit"
      class="btn btn-primary">{{$translatedLang['medical_add_allergy']}}</button>
      </div>
    </div>
  </form>
  <div class="row">
    <h3 class="col-md-6 col-sm-6 col-xs-6">{{$translatedLang['medical_prior_surgery']}} - ({{$countsurgeryData}})</h3>
    <div class="mngBox col-md-6 col-sm-6 col-xs-6"> <a href="/user/medical-surgery/add/{{$userId}}"  class='btn btn-primary'> {{$translatedLang['medical_add']}} </a> </div>
  </div>
  <div class="tblScroll">
    <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
      <thead>
        <tr>
          <th>{{$translatedLang['medical_date']}} <span>({{getDateFormat(userIdDecode($userId))}})</span></th>
          <th>{{$translatedLang['medical_title']}}</th>
          <th>{{$translatedLang['medical_outcome']}}</th>
          <th>{{$translatedLang['medical_doctor']}}</th>
          <th>{{$translatedLang['medical_file_linked']}}</th>
          <th>{{$translatedLang['medical_fr_visible']}}</th>
          <th>{{$translatedLang['medical_action']}}</th>
        </tr>
      </thead>
      @if($surgeryData)
      <tbody>

      @foreach($surgeryData as $value)
      <tr>
        <td><span class="dateBox">{{date(dateFormatReplace(getDateFormat(userIdDecode($userId))),
          strtotime($value->surgery_date))}}</span></td>
        <td class="titleWidth"><span>{{$value->surgery_title}}</span></td>
        <td><span>{{$value->surgery_outcome}}</span></td>
        <td><span class="docName">{{$value->doctor_name}}</span></td>
        <td><span  title="{{$value->file_link}}"> @if(preg_match("/http/i", $value->file_link))
          <a target="_blank" href="{{$value->file_link}}">click here</a>
           @else
              @if(strlen($value->file_link) >= 40)
              {{substr($value->file_link,0,40)}}....
              @else
                {{$value->file_link}}
              @endif
          @endif </span></td>
        <td><span>@if($value->available_status == 0) Yes @else No @endif</span></td>
        <td class="btnDtls"><span> <a title="Edit Surgery" href="/user/medical-surgery/edit/{{userIdEncode($value->id)}}"
                    class='btn btnUpdete'>Update details </a>
          <button title="Delete Surgery" onClick='return confirmDeleteSurgery({{$value->id}})'
                        class='btn btnDelete'> Delete</button>
          </span></td>
      </tr>
      @endforeach
        </tbody>

      @endif
    </table>
  </div>
  <div class="row">
    <h3 class="col-md-6 col-sm-6 col-xs-6">{{$translatedLang['medical_current_medication']}} - ({{count($medicationData)}})</h3>
    <div class="mngBox col-md-6 col-sm-6 col-xs-6"> <a href="/user/medical-medication/add/{{$userId}}"  class='btn btn-primary'> {{$translatedLang['medical_add']}} </a> </div>
  </div>
  <div class="tblScroll">
    <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="delegateData">
      <thead>
        <tr>
          <th>{{$translatedLang['medical_drug_name']}}</th>
          <th>{{$translatedLang['medical_drug_dose']}}</th>
          <th>{{$translatedLang['medical_drug_freq']}}</th>
          <th>{{$translatedLang['medical_doctor']}}</th>
          <th>{{$translatedLang['medical_notes']}}</th>
          <th>{{$translatedLang['medical_start_date']}} <span>({{getDateFormat(userIdDecode($userId))}})</span></th>
          <th>{{$translatedLang['medical_end_date']}} <span>({{getDateFormat(userIdDecode($userId))}})</span></th>
          <th>{{$translatedLang['medical_fr_visible']}}</th>
          <th>{{$translatedLang['medical_action']}}</th>
        </tr>
      </thead>
      @if($medicationData)
      <tbody>

      @foreach($medicationData as $value)
      <tr>
        <td><span>{{$value->drug_name}}</span></td>
        <td><span>{{$value->drug_dose}}</span></td>
        <td><span>{{$value->drug_frequency}}</span></td>
        <td><span class="docName">{{$value->doctor_name}}</span></td>
        <td><span>{{$value->user_notes}}</span></td>
        <td><span class="dateBox">{{date(dateFormatReplace(getDateFormat(userIdDecode($userId))), strtotime($value->start_date))}}</span></td>
        <td><span class="dateBox">{{date(dateFormatReplace(getDateFormat(userIdDecode($userId))), strtotime($value->end_date))}}</span></td>
        <td><span>@if($value->available_status == 0) Yes @else No @endif</span></td>
        <td class="btnDtls"><span><a title="Delete Medication" href="/user/medical-medication/edit/{{userIdEncode($value->id)}}"
                    class='btn btnUpdete'>Update details </a>
          <button title="Delete Medication" onClick='return confirmDeleteMedication({{$value->id}})'
                        class='btn btnDelete'> Delete</button>
          </span></td>
      </tr>
      @endforeach
        </tbody>

      @endif
    </table>
  </div>
</div>
<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <h3 class="pull-left">{{$translatedLang['medical_allegry_profile']}} - (<a id="allergy_count">0</a>) </h3>
    <div class="alert-allergy alert-success hide form-group alertBox pull-left"></div>
  </div>
</div>
<form class="form-horizontal" data-toggle="validator">
  <!-- Text input-->
  <fieldset class="formFiled">
    <div class="row foodAllBtn">
      <label class="col-md-2 col-sm-2 col-xs-2 control-label" for="allergy_food"> {{$translatedLang['medical_food']}}: </label>
      <div class="form-group col-md-3 col-sm-4 col-xs-4">
        <select required id="allergy_food" name="allergy_food" class="form-control" >
          <option value="">Select {{$translatedLang['medical_food']}}</option>

         @foreach($allergyFood as $food)

          <option  value="{{$food->id}}">{{$food->text}}</option>

        @endforeach
        <!-- <option value="other">other</option> -->
        </select>
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      <div class="col-md-7 col-sm-6 col-xs-6 submitBtn">
        <label class="control-label">
          <input type="checkbox" onclick="$(this).val(this.checked ? 0 : 1);"
        id="chk_food" value="1">
          <span id="chk_food_allergy">{{$translatedLang['medical_visible']}}</span> </label>
        <button id="food_submit" name="profile_submit"
    class="btn btn-primary">{{$translatedLang['medical_add_allergy']}}</button>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="food_other_input"></label>
      <div class="tag form-group col-md-3 col-sm-4 col-xs-4">
        <input type="text" class="hide form-control" id="food_other_input" value="" />
      </div>
    </div>
    <div class="row">
      <label class="col-md-2 col-sm-2 col-xs-2 control-label" for="taginput"></label>
      <div class="tag col-md-10 col-sm-10 col-xs-10 form-group">
        <input type="text" class="taginput" id="taginput" value="" />
      </div>
    </div>
  </fieldset>
</form>
<form class="form-horizontal" data-toggle="validator" id="form_non_food">
  <!-- Text input-->
  <fieldset class="formFiled">
    <div class="row foodAllBtn">
      <label class="col-md-2 col-sm-2 col-xs-2 control-label" for="allergy_non_food"> {{$translatedLang['medical_non_food']}}: </label>
      <div class="form-group col-md-3 col-sm-4 col-xs-4">
        <select required id="allergy_non_food" name="allergy_non_food" class="form-control" >
          <option value="">Select {{$translatedLang['medical_non_food']}}</option>

         @foreach($allergyNonFood as $food)

          <option  value="{{$food->id}}">{{$food->text}}</option>

        @endforeach
        <!-- <option value="other">other</option> -->
        </select>
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      <div class="col-md-7 col-sm-6 col-xs-6 submitBtn">
        <label class="control-label">
          <input type="checkbox" onclick="$(this).val(this.checked ? 0 : 1);"
        id="chk_non" value="1">
          <span id="chk_non_food_allergy">{{$translatedLang['medical_visible']}}</span> </label>
        <button  id="non_food_submit" name="profile_submit"
    class="btn btn-primary">{{$translatedLang['medical_add_allergy']}}</button>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="non_food_other_input"></label>
      <div class="tag form-group col-md-3 col-sm-4 col-xs-4">
        <input type="text" class="hide form-control" id="non_food_other_input" value="" />
      </div>
    </div>
    <div class="row">
      <label class="col-md-2 col-sm-2 col-xs-2 control-label" for="allergy_food"></label>
      <div class="tag col-md-10 col-sm-10 col-xs-10 form-group">
        <input type="text" class="taginput" id="taginputNon" value="" />
      </div>
    </div>
  </fieldset>
</form>
<input type="hidden" id="hdd_chk_non" value="false">
<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="userId" value="{{$userId}}">
@endsection
@section('script')
<script src="/assets/bootstrap/js/validator.js"></script>
<script src="/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="/assets/bootstrap/js/bootstrap-tagsinput.js"></script>
<script src="/assets/js/medical.js"></script>
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('user/medical-profile/list/{user_id}') !!}
@endsection