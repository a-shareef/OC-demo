<!-- resources/views/user/assignDelegate.blade.php -->
@extends('layouts.user')
@section('title', 'User Medication Information')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        {{ session('error') }}
    </div>
</div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span><div></div></div>
<form class="form-horizontal" data-toggle="validator" method="POST" action="/user/update/medical-medication">
{!! csrf_field() !!}
<!-- Form Name -->
<h2>{{$translatedLang['medication_information']}}:</h2>
<div class="addDele">
<fieldset class="formFiled">
<input type="hidden" value="{{$medicationId}}" name="medicationId" />
<input type="hidden" value="{{userIdEncode($medicationData[0]->fk_user_id)}}" name="userId" />
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" ></label>
   <div class="form-group col-md-5 col-sm-6 col-xs-6">
        <input type="checkbox" name="chk_medication_visible"
        @if($medicationData[0]->available_status == 0) checked="checked" @endif
        value="true">
        <span id="chk_medication_visible">{{$translatedLang['medication_visible']}}</span>
  </div>
</div>
<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="drug_name">
    {{$translatedLang['medication_drug_name']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="drug_name" name="drug_name" type="text" placeholder="{{$translatedLang['medication_drug_name']}}"
  class="form-control input-md" required="" value="{{$medicationData[0]->drug_name}}">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('drug_name')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="drug_dose">
    {{$translatedLang['medication_drug_dose']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="drug_dose" name="drug_dose" type="text" placeholder="{{$translatedLang['medication_drug_dose']}}"
  class="form-control input-md" required="" value="{{$medicationData[0]->drug_dose}}">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('drug_dose')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="drug_frequency">
    {{$translatedLang['medication_drug_freq']}}:</label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
   <select required id="drug_frequency" name="drug_frequency" class="form-control" >
     <option value="">Select {{$translatedLang['medication_drug_freq']}}</option>
         @foreach($drugFreqArray as $freq)
            <option  value="{{$freq}}"
              @if($medicationData[0]->drug_frequency) == $freq) selected="selected" @endif>
              {{$freq}}
            </option>
        @endforeach
   </select>
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('drug_frequency')}}</div>
  </div>
</div>

<!-- Textarea -->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="user_notes">
    {{$translatedLang['medication_notes']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
    <textarea class="form-control" id="user_notes" name="user_notes">{{$medicationData[0]->user_notes}}</textarea>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="start_date">
    {{$translatedLang['medication_start_date']}}:
  </label>

  <div id="start_date" class="form-group col-md-5 col-sm-6 col-xs-6 input-group date">
  <input name="start_date" type="text"
  placeholder="{{$translatedLang['medication_start_date']}}" class="form-control input-md"
  required="" value="{{$medicationData[0]->start_date}}">
 <span class="input-group-addon">
    <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
 </span>
 <div class="alert-message alert-danger">{{$errors->first('start_date')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="end_date">
    {{$translatedLang['medication_end_date']}}:
  </label>

  <div id="end_date" class="form-group col-md-5 col-sm-6 col-xs-6 input-group date">
  <input  name="end_date" type="text"
  placeholder="{{$translatedLang['medication_end_date']}}" class="form-control input-md"
  required="" value="{{$medicationData[0]->end_date}}">
 <span class="input-group-addon">
    <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
 </span>
 <div class="alert-message alert-danger">{{$errors->first('end_date')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="doctor_name">
    {{$translatedLang['medication_doctor']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="doctor_name" name="doctor_name" type="text" placeholder="{{$translatedLang['medication_doctor']}}"
  class="form-control input-md" required="" value="{{$medicationData[0]->doctor_name}}">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('doctor_name')}}</div>
  </div>
</div>

        <!-- Button -->
  <div class="row">
   <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="cancel"></label>
   <div class="col-md-4 col-sm-6 col-xs-6 form-group submitBtn">
    <button id="profile_submit" name="profile_submit"
    class="btn btn-primary">{{$translatedLang['medication_update']}}</button>
    <input class="btn btn-primary" type="button" onclick="window.history.go(-1)"
    value="{{$translatedLang['medication_cancel']}}">
</div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group">

  </div>
  </div>

</fieldset>
</div>
</form>
<input type="hidden" id="date_format" value="{{getDateFormat($medicationData[0]->fk_user_id)}}"/>
@endsection
@section('script')
<script src="/assets/bootstrap/js/validator.js"></script>
<script src="/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="/assets/js/medical.js"></script>
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('user/medical-medication/edit/{user_id}') !!}
@endsection