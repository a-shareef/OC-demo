<!-- resources/views/user/assignDelegate.blade.php -->
@extends('layouts.user')
@section('title', 'Edit User Surgery')
@section('content')
<form class="form-horizontal" data-toggle="validator" method="POST" action="/user/update/medical-surgery">
{!! csrf_field() !!}
<!-- Form Name -->
<h3>{{$translatedLang['surgery']}}</h3>
<div class="addDele">
<fieldset class="formFiled">
<input type="hidden" value="{{$surgeryId}}" name="surgery_id" />
<input type="hidden" value="{{userIdEncode($surgeryData[0]->fk_user_id)}}" name="userId" />
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" ></label>
   <div class="form-group col-md-5 col-sm-6 col-xs-6">
            <input type="checkbox" name="chk_surgery_visible"
            @if($surgeryData[0]->available_status == 0) checked="checked" @endif
            value="true">
            <span id="chk_surgery_visible">{{$translatedLang['surgery_visible']}}</span>
          </div>
          </div>
<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="title">
    {{$translatedLang['surgery_title']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="title" name="title" type="text" placeholder="{{$translatedLang['surgery_title']}}"
  class="form-control input-md" required="" value="{{$surgeryData[0]->surgery_title}}">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('title')}}</div>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="surgery_date">
    {{$translatedLang['surgery_date']}}:
  </label>

  <div id="surgery_date" class="form-group col-md-5 col-sm-6 col-xs-6 input-group date">
  <input name="surgery_date" type="text"
  placeholder="{{$translatedLang['surgery_date']}}" class="form-control input-md"
  required="" value="{{$surgeryData[0]->surgery_date}}">
 <span class="input-group-addon">
    <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
 </span>
 <div class="alert-message alert-danger">{{$errors->first('surgery_date')}}</div>
  </div>
</div>

<!-- Textarea -->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="outcome">
    {{$translatedLang['surgery_outcome']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
    <textarea class="form-control" id="outcome" name="outcome">{{$surgeryData[0]->surgery_outcome}}</textarea>
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="files_linked">
    {{$translatedLang['surgery_file_linked']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="files_linked" name="files_linked" type="text"
  placeholder="{{$translatedLang['surgery_file_linked']}}" class="form-control input-md"
  value="{{$surgeryData[0]->file_link}}">
  </div>
</div>

<!-- Text input-->
<div class="row">
  <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="doctor">
   {{$translatedLang['surgery_doctor']}}:
  </label>
  <div class="form-group col-md-5 col-sm-6 col-xs-6">
  <input id="doctor" name="doctor" type="text" placeholder="{{$translatedLang['surgery_doctor']}}"
  class="form-control input-md" required="" value="{{$surgeryData[0]->doctor_name}}">
<span class="glyphicon form-control-feedback" aria-hidden="true"></span>
           <div class="alert-message alert-danger">{{$errors->first('doctor')}}</div>
  </div>
</div>


        <!-- Button -->
  <div class="row">
   <label class="col-md-3 col-sm-3 col-xs-3 control-label" for="cancel"></label>
   <div class="col-md-4 col-sm-6 col-xs-6 form-group submitBtn">
    <button id="profile_submit" name="profile_submit"
    class="btn btn-primary">{{$translatedLang['surgery_update']}}</button>
    <input class="btn btn-primary" type="button" onclick="return window.history.back();"
    value="{{$translatedLang['surgery_cancel']}}">
</div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group">

  </div>
  </div>

</fieldset>
</div>
</form>
<input type="hidden" id="date_format" value="{{getDateFormat($surgeryData[0]->fk_user_id)}}"/>
@endsection
@section('script')
<script src="/assets/bootstrap/js/validator.js"></script>
<script src="/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="/assets/js/medical.js"></script>
@endsection
@section('breadcrumbs')
    {!! Breadcrumbs::render('user/medical-surgery/edit/{user_id}') !!}
@endsection
