@extends('layouts.chartlayout')
@section('title', 'FoundThem Tag Products by Customer/Order Number')

@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif


<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FoundThem Tag Products by Customer/Order Number</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
<div class="tableContentBox">
  
      <div class="row">
          <div class="col-md-1 col-sm-5 col-xs-5 wth100per">
             <label class="control-label pull-left wth100per">Customer:</label>
          </div> 
          <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
                    @if (hasrole() == 1)
                      <div class="form-group">
                        <select required id="ft_customer" name="ft_customer" class="form-control" >
                            <option value="">Select Customer</option>
                            @foreach($customerArray as $key => $customer)
                            <option value="{{$customer->id}}"> 
                                {{$customer->name}} 
                            </option>
                            @endforeach
                        </select>
                       </div>
                    @endif  
          </div>
          <div class="col-md-1 col-sm-5 col-xs-5 wth100per">
             <label class="control-label pull-left wth100per">Order #:</label>
          </div> 
          <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
                    @if (hasrole() == 1)
                        <div class="form-group">
                            <select required id="ft_orders" name="ft_orders" class="form-control" >
                            <option value="">Select Order</option>
                            @foreach($ordersArray as $key => $order)
                            <option value="{{$order->id}}"> 
                            {{$order->order_no}} 
                            </option>
                            @endforeach
                            </select>
                        </div>
                    @endif             
          </div>
            <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <span style="font-size:14px;"><b>Report Date:</b> {{date('m-d-Y')}}</span>
          </div>
      </div>
    <div id="searchdates" class="form-horizontal">
        <div class="form-group">
        <div class="col-md-1 col-sm-5 col-xs-5 wth100per">
             <label class="control-label pull-left wth100per labeldt">From:</label>
          </div> 
          
            <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
            <div class="input-group date" id="fini">
            <input id="fdate" name="fini" type="text" placeholder="From Date"
            class="form-control input-md blurclass" title="From Access Date"  required="required"  value="{{ old('fini') ? old('fini') : $fdate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
            <div class="col-md-1 col-sm-5 col-xs-5 wth100per">
            <label class="control-label pull-left wth100per">To:</label>
            </div>
                <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="ffin">
            <input id="tdate" name="ffin" type="text" placeholder="To Date"
  class="form-control input-md blurclass" title="To Access Date"  required="required" value="{{ old('ffin') ? old('ffin') : $todate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
            <div id="ft" class="{{$ft}}">
            <div class="col-md-3 col-sm-12 col-xs-12 search-result-btn">
                <button type="button" id="ftdateSearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" id="dateclear" class="btn btn-primary"><i class="fa fa-times"></i> Clear</button>
                
            </div>
        </div>
    </div>

    <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
    <div id="containerFN" class="ftordercount"></div>
    <div id="containerTN" class="FoundThem Tag Products by Customer/Order Number"></div>
    <div id="containersTN" class="This report shows the Customer, Order or Customer/Order status of FT Tags."></div>
    <div id="containerPlotd" class="all"></div>
</div>
</div>
@endsection

@section('breadcrumbs')
{!! Breadcrumbs::render('admin/reports/'.$report) !!}
@endsection 
