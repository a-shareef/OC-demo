@extends('layouts.chartlayout')
@section('title', 'FoundThem Tag Products by Customer/Order Number
')

@section('content')
    @if (session('status'))
    <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
        <div>
            {{ session('status') }}
        </div>
    </div>
    @endif
    <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FoundThem Tag Products by Customer/Order Number</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="tableContentBox">
        <div id="searchdates" class="form-horizontal">
           <div class="form-group">
        
             <label class="control-label pull-left wth100per labeldt">From:</label>
          
            <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
            <div class="input-group date" id="fini">
            <input id="fdate" name="fini" type="text" placeholder="From Date"
            class="form-control input-md blurclass" title="From Access Date"  required="required"  value="{{ old('fini') ? old('fini') : $fdate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
            <label class="control-label pull-left wth100per">To:</label>
                <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="ffin">
            <input id="tdate" name="ffin" type="text" placeholder="To Date"
  class="form-control input-md blurclass" title="To Access Date"  required="required" value="{{ old('ffin') ? old('ffin') : $todate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
            <div id="ft" class="{{$ft}}"></div>
            <div class="col-md-5 col-sm-12 col-xs-12 search-result-btn">
                <button type="button" id="ftdateSearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" id="dateclear" class="btn btn-primary"><i class="fa fa-times"></i> Clear</button> <span style="font-size:14px;float: right; margin-right: -15px"><b>Report Date:</b> {{date('m-d-Y')}}</span>
                
            </div>
        </div>
    </div>
        </div>
        <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
        <div id="containerFN" class="registrationcomp"></div>
        <div id="containerTN" class="Customer Service Agent Attempted Registrations Report"></div>
        <div id="containersTN" class="This report allows the customer service agent to see the attempted registrations by people from the public page."></div>
        <div id="containerPlotd" class="all"></div> 
    </div>
    </div>
@endsection

@section('breadcrumbs')
{!! Breadcrumbs::render('admin/reports/'.$report) !!}
@endsection 
