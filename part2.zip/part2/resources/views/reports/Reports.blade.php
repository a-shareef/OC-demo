@extends('layouts.reports')
@section('title', 'Reports')
@section('style')
<link href="/assets/bootstrap/css/bootstrap-tagsinput.css" rel="stylesheet">
@endsection
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> {{ session('status') }} </div>
@endif
@if (session('error'))
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> {{ session('error') }} </div>
@endif
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Reports</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="panel-group report-accordion" id="accordion">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">Audit Reports<i class="fa fa-plus pull-right"></i></a> </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
          <div class="panel-body">
            <ul class="report-list no-margins metismenu videoList">
              <li><a href="{{url('/')}}/admin/reports/loginhistory/{{userIdEncode(3)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Login History</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/membersaudit/{{userIdEncode(2)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FT Users Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/productregistrations/{{userIdEncode(4)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Product Registration Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/userregistrations/{{userIdEncode(5)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>User Registration Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/usregisteredproducts/{{userIdEncode(9)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Incomplete Registrations Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/pendingproductsactivation/{{userIdEncode(10)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Pending Product Activation Report</span></a></li>
               <li><a href="{{url('/')}}/admin/reports/productstatusreport/{{userIdEncode(19)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Product Status Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/foundproductsreport/{{userIdEncode(20)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Found Products Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/lostproductsreport/{{userIdEncode(21)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Lost Products Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/suspendedproductsreport/{{userIdEncode(22)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Suspended Products Report</span></a></li>
               <li><a href="{{url('/')}}/admin/reports/lostfoundproductsreport/{{userIdEncode(23)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Lost Found Products Report</span></a></li>
                <li><a href="{{url('/')}}/admin/reports/orderedproductsreport/{{userIdEncode(24)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Order Status Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/orderedproductsreport/{{userIdEncode(25)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Unregistered Products Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/reactivatedproductsreport/{{userIdEncode(26)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Reactivated Products Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/registrationattemptsreport/{{userIdEncode(27)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Registration Attempts Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/tagtransferreport/{{userIdEncode(28)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>  All Tag Transfers Report</span></a></li>


            </ul>
          </div>
        </div>
      </div>
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed">Graphical Reports<i class="fa fa-plus pull-right"></i></a> </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
          <div class="panel-body">
            <ul class="report-list no-margins metismenu videoList">
              <li><a href="{{url('/')}}/admin/reports/countrywiseusersmap/{{userIdEncode(8)}}" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FT Users by Country</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/ftunits/{{userIdEncode(11)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FoundThem All Products Over Time</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/ftordercount/{{userIdEncode(12)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FoundThem Tag Products by Customer/Order Number</span></a></li>
<!--              <li><a href="{{url('/')}}/admin/reports/ftordernouid/{{userIdEncode(13)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Attempted Registrations Report</span></a></li>-->
              <li><a href="{{url('/')}}/admin/reports/csmainchart/{{userIdEncode(14)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Current FT Status Report</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/registrationcomp/{{userIdEncode(15)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Attempted Registrations Report</span></a></li>
<!--              <li><a href="{{url('/')}}/admin/reports/today/{{userIdEncode(16)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Today</span></a></li>
              <li><a href="{{url('/')}}/admin/reports/registrationhistoryc/{{userIdEncode(17)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Registration History</span></a></li>-->
              <li><a href="{{url('/')}}/admin/reports/registrationhistoryl/{{userIdEncode(18)}}"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Registrations vs Order Report</span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<input type="hidden" id="hdd_chk_non" value="false">
<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="userId">
@endsection
@section('script') 
<script src="{{url('/')}}/assets/bootstrap/js/validator.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="{{url('/')}}/assets/bootstrap/js/bootstrap-tagsinput.js"></script> 
<script src="{{url('/')}}/assets/js/reports.js"></script> 
@endsection

@section('breadcrumbs')
    {!! Breadcrumbs::render('admin/reports') !!}
@endsection