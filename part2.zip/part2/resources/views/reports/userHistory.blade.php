@extends('layouts.reportfront')
@section('title', 'User History')

@section('content')
 {{-- User Details Fetch Starts Here --}}
    <div class="row"><div class="col-xs-12"><button class="btn btn-primary pull-right mb-10" onclick="window.history.go(-1); return false;"><i class="fa fa-chevron-left"></i> Back</button></div></div>
  @if($userData)
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>User Profile:</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      
        <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer userhistorydata responsive" cellspacing="0" width="100%" id="delegateData">
          <thead>
            <tr>
              <th data-priority="1">Name</th>
              <th data-priority="2">Email</th>
              <th>Address</th>
              <th >Status</th>
              <th>Role Type</th>
              <th>Relationship</th>
              <th data-priority="3">FREMS Alert Status</th>
            </tr>
          </thead>
          <tbody>
          
          @foreach($userData as $value)
          <tr>
            <td>{{$value->first_name}} {{$value->last_name}}</td>
            <td>{{$value->email}}</td>
            <td> @if($value->street_address1) {{$value->street_address1}}  ,@endif
              @if($value->street_address2){{$value->street_address2}} ,@endif
              @if($value->street_address3){{$value->street_address3 }} ,@endif
              @if($value->user_city){{$value->user_city}} ,@endif
              @if($value->user_zip){{$value->user_zip}} ,@endif
              @if($value->user_country){{$value->user_country}}@endif</td>
            <td> @if($value->password != '')
              Active
              @else
              Inactive
              @endif </td>
            <td> @if($value->fk_role_id == 3) Member @endif
              @if($value->fk_role_id == 5) Delegate @endif
              @if($value->fk_role_id == 6) Connection @endif </td>
            <td></td>
            <td></td>
          </tr>
          @endforeach
            </tbody>
          
        </table>
      
    </div>
  </div>
  @endif
  {{-- User Details Fetch Ends Here --}}
  
  
  
  {{-- Members Delegate Details Fetch Starts Here --}}
  
  @if($userDelegateData)
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>@if(count($userDelegateData) > 1) Delegates @else Delegate @endif </h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      
        <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer userhistorydata responsive" cellspacing="0" width="100%" id="delegateData">
          <thead>
            <tr>
              <th data-priority="1">Name</th>
              <th data-priority="2">Email</th>
              <th>Address</th>
              <th>Status</th>
              <th>Role Type</th>
              <th>Relationship</th>
              <th data-priority="3">FREMS Alert Status</th>
            </tr>
          </thead>
          <tbody>
          
          @foreach($userDelegateData as $value)
          <tr>
            <td>{{$value->first_name}} {{$value->last_name}}</td>
            <td>{{$value->email}}</td>
            <td> @if($value->street_address1) {{$value->street_address1}}  ,@endif
              @if($value->street_address2){{$value->street_address2}} ,@endif
              @if($value->street_address3){{$value->street_address3 }} ,@endif
              @if($value->user_city){{$value->user_city}} ,@endif
              @if($value->user_zip){{$value->user_zip}} ,@endif
              @if($value->user_country){{$value->user_country}}@endif</td>
            <td> @if($value->alerts_status == 0)
              Active
              @else
              Inactive
              @endif </td>
            <td> @if($value->fk_role_id == 5) Delegate @endif </td>
            <td> {{$value->relation_name}} </td>
            <td>@if($value->alert_notification == 0)
              Yes
              @else
              No 
              @endif </td>
          </tr>
          @endforeach
            </tbody>
          
        </table>
      
    </div>
  </div>
  @endif
  {{-- Members Delegate Details Fetch Starts Here --}}
  
  
  {{-- Member Connection Details Fetch Starts Here --}}
  
  @if($userConnectionData)
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>@if(count($userConnectionData) > 1) Connections @else Connection @endif </h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      
        <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer userhistorydata responsive" cellspacing="0" width="100%" id="delegateData">
          <thead>
            <tr>
              <th data-priority="1">Name</th>
              <th data-priority="2">Email</th>
              <th>Address</th>
              <th data-priority="3">Status</th>
              <th>Role Type</th>
              <th>Relationship</th>
              <th>FREMS Alert Status</th>
            </tr>
          </thead>
          <tbody>
          
          @foreach($userConnectionData as $value)
          <tr>
            <td>{{$value->first_name}} {{$value->last_name}}</td>
            <td>{{$value->email}}</td>
            <td> @if($value->street_address1) {{$value->street_address1}}  ,@endif
              @if($value->street_address2){{$value->street_address2}} ,@endif
              @if($value->street_address3){{$value->street_address3 }} ,@endif
              @if($value->user_city){{$value->user_city}} ,@endif
              @if($value->user_zip){{$value->user_zip}} ,@endif
              @if($value->user_country){{$value->user_country}}@endif</td>
            <td> @if($value->alerts_status == 0)
              Active
              @else
              Inactive
              @endif </td>
            <td> @if($value->fk_role_id == 6) Connection @endif </td>
            <td> {{$value->relation_name}} </td>
            <td>@if($value->alert_notification == 0)
              Yes
              @else
              No 
              @endif </td>
          </tr>
          @endforeach
            </tbody>
          
        </table>
      
    </div>
  </div>
  @endif
  {{-- Member Connection Details Fetch Ends Here --}}
  
  
  {{-- User Delegate Details Fetch Starts Here --}}
  
  @if($delegateData)
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>Is a Delegate to</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      
        <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer userhistorydata responsive" cellspacing="0" width="100%" id="delegateData">
          <thead>
            <tr>
              <th data-priority="1">Name</th>
              <th data-priority="2">Email</th>
              <th>Address</th>
              <th>Status</th>
              <th>Role Type</th>
              <th>Relationship</th>
              <th data-priority="3">FREMS Alert Status</th>
            </tr>
          </thead>
          <tbody>
          
          @foreach($delegateData as $value)
          <tr>
            <td>{{$value->first_name}} {{$value->last_name}}</td>
            <td>{{$value->email}}</td>
            <td> @if($value->street_address1) {{$value->street_address1}}  ,@endif
              @if($value->street_address2){{$value->street_address2}} ,@endif
              @if($value->street_address3){{$value->street_address3 }} ,@endif
              @if($value->user_city){{$value->user_city}} ,@endif
              @if($value->user_zip){{$value->user_zip}} ,@endif
              @if($value->user_country){{$value->user_country}}@endif</td>
            <td> @if($value->alerts_status == 0)
              Active
              @else
              Inactive
              @endif </td>
            <td> @if($value->fk_role_id == 5) Delegate @endif </td>
            <td> {{$value->relation_name}} </td>
            <td>@if($value->alert_notification == 0)
              Yes
              @else
              No 
              @endif </td>
          </tr>
          @endforeach
            </tbody>
          
        </table>
      
    </div>
  </div>
  @endif
  {{-- User Delegate Details Fetch Starts Here --}}
  
  
  {{-- User Connection Details Fetch Starts Here --}}
  
  @if($connectionData)
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>Is a Connection to</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      
        <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer userhistorydata responsive" cellspacing="0" width="100%" id="delegateData">
          <thead>
            <tr>
              <th data-priority="1">Name</th>
              <th data-priority="2">Email</th>
              <th>Address</th>
              <th>Status</th>
              <th>Role Type</th>
              <th>Relationship</th>
              <th data-priority="3">FREMS Alert Status</th>
            </tr>
          </thead>
          <tbody>
          
          @foreach($connectionData as $value)
          <tr>
            <td>{{$value->first_name}} {{$value->last_name}}</td>
            <td>{{$value->email}}</td>
            <td> @if($value->street_address1) {{$value->street_address1}}  ,@endif
              @if($value->street_address2){{$value->street_address2}} ,@endif
              @if($value->street_address3){{$value->street_address3 }} ,@endif
              @if($value->user_city){{$value->user_city}} ,@endif
              @if($value->user_zip){{$value->user_zip}} ,@endif
              @if($value->user_country){{$value->user_country}}@endif</td>
            <td> @if($value->alerts_status == 0)
              Active
              @else
              Inactive
              @endif </td>
            <td> @if($value->fk_role_id == 6) Connection @endif </td>
            <td> {{$value->relation_name}} </td>
            <td>@if($value->alert_notification == 0)
              Yes
              @else
              No 
              @endif </td>
          </tr>
          @endforeach
            </tbody>
          
        </table>
     
    </div>
  </div>
  @endif
  {{-- User Connection Details Fetch Ends Here --}} 
@endsection 





