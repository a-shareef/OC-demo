@extends('layouts.membersreport')
@section('title', 'Registrations Attempts Report')
@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> {{ session('status') }} </div>
</div>
@endif
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Registrations Attempts Report</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div id="searchdates" class="form-horizontal">
     <div class="form-group">
        <label class="control-label pull-left wth100per labeldt"></label>
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="fini">
            <input id="fdate" name="fini" type="text" placeholder="From Date"
  class="form-control input-md blurclass" title="From Access Date"  required="required"  value="{{ old('fini') ? old('fini') : $fdate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
           </div>
        </div>
        <label class="control-label pull-left wth100per">To</label>
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="ffin">
            <input id="tdate" name="ffin" type="text" placeholder="To Date"
  class="form-control input-md blurclass" title="To Access Date"  required="required" value="{{ old('ffin') ? old('ffin') : $todate }}"> <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
             <div id="ft" class="{{$ft}}"></div>
             <div id="cid" class="{{userIdDecode($cid)}}"></div>
             <div id="oid" class="{{userIdDecode($oid)}}"></div>
             
        <div class="col-md-5 col-sm-12 col-xs-12 search-result-btn">
            <button type="button" id="ftdateSearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
            <button type="button" id="dateclear" class="btn btn-primary"><i class="fa fa-times"></i> Clear</button><span style="font-size:14px;float: right; margin-right: -15px"><b>Report Date:</b> {{date('m-d-Y')}}</span>
            
          </div>

         
        </div>
      </div>
      
     
    
      <table class="table table-striped table-bordered responsive" cellspacing="0" width="100%" id="registrationattempts">
        <thead>
          <tr>
            <th data-priority="1">Tag #</th>
            <th data-priority="3">Member Email</th>
            <th>Member Status</th>
            <th>Security Questions (DOB / Mobile / Zip)</th>
            <th>IP Address</th>
            <th data-priority="2">Activation Status</th>
            <th>Is a Member in PIP</th>
            <th>Date of Registration (UTC)</th>
          </tr>
        </thead>
      </table>
    
  </div>
</div>
<input type="hidden" id="search" value="{{$translatedLang['dashboard_search']}}">
<input type="hidden" id="next" value="{{$translatedLang['dashboard_next']}}">
<input type="hidden" id="first" value="{{$translatedLang['dashboard_first']}}">
<input type="hidden" id="last" value="{{$translatedLang['dashboard_last']}}">
<input type="hidden" id="previous" value="{{$translatedLang['dashboard_previous']}}">
<input type="hidden" id="record_per_page" value="{{$translatedLang['dashboard_record_per_page']}}">
<input type="hidden" id="display" value="{{$translatedLang['dashboard_display']}}">
<input type="hidden" id="dashboard_of" value="{{$translatedLang['dashboard_of']}}">
<input type="hidden" id="showing_page" value="{{$translatedLang['dashboard_showing_page']}}">
<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="filtercolumnvalue" value="7">
<input type="hidden" id="datatableidvalue" value="registrationattempts">
@endsection 