@extends('layouts.maplayout')
@section('title', 'FT Users by Country')

@section('content')
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FT Users by Country</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <input type="hidden" name="reportid" id="reportid" value="{{userIdEncode(2)}}">
    <div id="regions_div"></div>
    <div class="tableContentBox">
        <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
    </div>
  </div>
</div>
<input type="hidden" id="search" value="{{$translatedLang['dashboard_search']}}">
<input type="hidden" id="next" value="{{$translatedLang['dashboard_next']}}">
<input type="hidden" id="first" value="{{$translatedLang['dashboard_first']}}">
<input type="hidden" id="last" value="{{$translatedLang['dashboard_last']}}">
<input type="hidden" id="previous" value="{{$translatedLang['dashboard_previous']}}">
<input type="hidden" id="record_per_page" value="{{$translatedLang['dashboard_record_per_page']}}">
<input type="hidden" id="display" value="{{$translatedLang['dashboard_display']}}">
<input type="hidden" id="dashboard_of" value="{{$translatedLang['dashboard_of']}}">
<input type="hidden" id="showing_page" value="{{$translatedLang['dashboard_showing_page']}}">
<input type="hidden" id="token" value="{{ csrf_token() }}">
<input type="hidden" id="filtercolumnvalue" value="4">
<input type="hidden" id="datatableidvalue" value="users-table">
@endsection
@section('breadcrumbs')
{!! Breadcrumbs::render('admin/reports/'.$report) !!}
@endsection 