@extends('layouts.chartlayout')
@section('title', 'FT Order Number UID')

@section('content')
@if (session('status'))
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        {{ session('status') }}
    </div>
</div>
@endif
<div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>FT Order Number UID</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">  
        <div class="tableContentBox">
            <div class="row"> 
                @if (hasrole() == 1)
                <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
                  <select required id="ft_orders" name="ft_orders" class="form-control" >
                    <option value="">Select Order</option>
                    @foreach($ordersArray as $key => $order)
                        <option value="{{$order->id}}"> 
                            {{$order->order_no}} 
                        </option>
                    @endforeach
                  </select>
                </div>
                @endif
            </div>
            <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
            <div id="containerFN" class="ftordernouid"></div>
            <div id="containerTN" class="FT Order Number UID"></div>
        </div>
    </div>
</div>
@endsection

@section('breadcrumbs')
{!! Breadcrumbs::render('admin/reports/'.$report) !!}
@endsection 
