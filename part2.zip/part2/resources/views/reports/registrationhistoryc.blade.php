@extends('layouts.chartlayout')
@section('title', 'Registration History Column Graph')

@section('content')
    @if (session('status'))
    <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
        <div>
            {{ session('status') }}
        </div>
    </div>
    @endif

    <div class="tableContentBox">
        <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
        <div id="containerFN" class="registrationhistoryc"></div>
        <div id="containerTN" class="Registration History Column Graph"></div>
    </div>
@endsection

@section('breadcrumbs')
{!! Breadcrumbs::render('admin/reports/'.$report) !!}
@endsection 
