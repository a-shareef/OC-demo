@extends('layouts.membersreport')
@section('title', 'Users Products Report')
@section('content')
 
{{-- <div class="tableContentBox" id="countrycontainer">
   
</div> --}}
 

<div class="tableContentBox" id="countrycontainer"></div>
 
 
 

<input type="hidden" id="search" value="{{$translatedLang['dashboard_search']}}">
<input type="hidden" id="next" value="{{$translatedLang['dashboard_next']}}">
<input type="hidden" id="first" value="{{$translatedLang['dashboard_first']}}">
<input type="hidden" id="last" value="{{$translatedLang['dashboard_last']}}">
<input type="hidden" id="previous" value="{{$translatedLang['dashboard_previous']}}">
<input type="hidden" id="record_per_page" value="{{$translatedLang['dashboard_record_per_page']}}">
<input type="hidden" id="display" value="{{$translatedLang['dashboard_display']}}">
<input type="hidden" id="dashboard_of" value="{{$translatedLang['dashboard_of']}}">
<input type="hidden" id="showing_page" value="{{$translatedLang['dashboard_showing_page']}}">
<input type="hidden" id="token" value="{{ csrf_token() }}">
@endsection


