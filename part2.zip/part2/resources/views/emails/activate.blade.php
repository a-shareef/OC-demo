UberId Activation link

<a href="{{ url('activate/'.$user['url']) }}">Please click in order to validate your email.</a>