        <center>
        <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable">
        <tr>
        <td align="center" valign="top" id="bodyCell">
        <!-- BEGIN TEMPLATE // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateContainer">
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN HEADER // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateHeader">
        <tr>
        <td valign="top" class="headerContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnImageBlock">
        <tbody class="mcnImageBlockOuter">
        <tr>
        <td valign="top" style="padding:9px" class="mcnImageBlockInner">
        <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="mcnImageContentContainer">
        <tbody><tr>
        <td class="mcnImageContent" valign="top" style="padding-right: 9px; padding-left: 9px; padding-top: 0; padding-bottom: 0; text-align:center;">


        <img align="left" alt="" src="{{ url('/')}}/assets/images/{{siteLogo()}}" width="300" style="max-width:300px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">


        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END HEADER -->
        </td>
        </tr>
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN BODY // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateBody">
        <tr>
        <td valign="top" class="bodyContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock">
        <tbody class="mcnTextBlockOuter">
        <tr>
        <td valign="top" class="mcnTextBlockInner">

        <table align="left" border="0" cellpadding="0" cellspacing="0" width="600" class="mcnTextContentContainer">
        <tbody><tr>

        <td valign="top" class="mcnTextContent" style="padding-top:9px; padding-right: 18px; padding-bottom: 9px; padding-left: 18px;"><p id='templateContentStarts'><h2>Tag # Activation Acknowledgement</h2>

<p> </p>

<p>Dear {{$data['user']['user_name']}},<br />
<br />
Congratulations! You have successfully registered a FoundThem Tag #.</p>

<p><br />
@if(!empty($data['user']['tag_no']))Tag # : {{$data['user']['tag_no']}} @endif</p>

<h2>Next Steps:</h2>

<ol>
	<li><strong>Attach the tag</strong> to an item you want to keep track of. Either connect the tag to an item, or in the case of a security label, or glasses tag, attach it to a clean surface.</li>
	<li><strong>Add a description</strong> of the product in your FoundThem™ account. Locate the item in your account and click on the Add Description action icon. </li>
	<li><strong>Add a picture</strong> of the product in your FoundThem™ account. Locate the item in your account and click on the Add Description action icon. This is great way to help Customer Service staff verify the item with the person finding your lost property. </li>
</ol>

<p>​Need more tags? Purchase new tags at <a href="http://UberID.com/foundthem" target="_blank">UberID.com/foundthem</a></p>

<p> </p>

<p>(FT-ID11)</p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p></p><p id='templateContentEnds'></p>        Sincerely,<br>
        UberID® Customer Service Team</p>

        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END BODY -->
        </td>
        </tr>
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN FOOTER // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateFooter">
        <tr>
        <td valign="top" class="footerContainer" style="padding-bottom:9px;"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock">
        <tbody class="mcnTextBlockOuter">
        <tr>
        <td valign="top" class="mcnTextBlockInner">

        <table align="left" border="0" cellpadding="0" cellspacing="0" width="600" class="mcnTextContentContainer">
        <tbody><tr>

        <td valign="top" class="mcnTextContent" style="padding: 9px 18px;color: #000000;">

        <em>&#169; {{ date('Y')}} UberID, LLC. All Rights Reserved. </em>
        <em style="float: right;"> Powered by UberID. (Build 1.1.5.7)‎</em><br><br>

        &nbsp;
        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowBlock">
        <tbody class="mcnFollowBlockOuter">
        <tr>
        <td align="center" valign="top" style="padding:9px" class="mcnFollowBlockInner">
        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowContentContainer">
        <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowContent">
        <tbody><tr>
        <td align="center" valign="top" style="text-align:left;">
        <table border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
        <td valign="top">

        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END FOOTER -->
        </td>

        </tr>
        </table>
        <!-- // END TEMPLATE -->
        </td>
        </tr>
        </table>
        </center>
