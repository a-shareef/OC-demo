
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <!-- NAME: 1 COLUMN -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="/assets/css/emailStyle.css" rel="stylesheet">
    <title>*|MC:SUBJECT|*</title>

    @yield('emailStyle')

    </head>
    <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">

    <!-- // header include -->
    @include('layouts.emailHeader')
    <h1>User Reported Lost Product<br></h1>
    @if(!empty($data['userFirstName']) && !empty($data['userFirstName'])) 
    <p>
    <span style="line-height:1.6em">{{$data['userFirstName']}} {{$data['userLastName']}} reported lost product</span>
    <br>
    @endif
    @if(!empty($data['id'])) 
    <span style="line-height:1.6em"> User ID: {{$data['id']}}</span>
    <br>
    @endif
    @if(!empty($data['userproductName']))
    <span style="line-height:1.6em"> Product Type: {{$data['userproductName']}}</span>
    <br>
    @endif
    @if(!empty($data['userEmail']))
    <span style="line-height:1.6em"> Email: {{$data['userEmail']}}</span>
    </p>
    @endif
    <br>
    <br>
    <br>
    @include('layouts.emailFooter')
    <!-- // footer include -->

    </body>
    </html>