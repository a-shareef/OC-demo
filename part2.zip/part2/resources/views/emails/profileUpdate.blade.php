Dear {{$user['firstname']}} {{$user['lastname']}},

Your Profile is updated by {{\Auth::user()->first_name}} {{\Auth::user()->last_name}}.