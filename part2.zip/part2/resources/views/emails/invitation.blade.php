

<a href="{{ url('user/delegate/accept/'.$token) }}">Click here</a>
 if you accept to be delgate for {{$user['firstname']}} {{$user['lastname']}}.
