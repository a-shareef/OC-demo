<!-- resources/views/auth/password.blade.php -->

@extends('layouts.auth')
  @section('title', 'Reset Password')
  @section('content')
  <div class="loginColumns">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row text-center"><a  href="{{url('/')}}" ><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
          <div class="col-lg-12">
            <form id="passwordreset" class="loginform form-horizontal" data-toggle="validator" method="POST" action="{{url('/')}}/password/email" method="post" role="form" style="display: block;">
            {!! csrf_field() !!}
            @if (session('status'))
            <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
              <div> {{ session('status') }} </div>
            </div>
            @endif
            @if (session('error'))
            <div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
              <div> {{ session('error') }} </div>
            </div>
            @endif
            @if(count($errors))
              @foreach ($errors->all() as $error)
                
                  <div class="alert alert-danger">
                  <div>
                    <span class="glyphicon glyphicon-remove-sign"></span>{{ $error }}
                  </div>
                  </div>
              @endforeach
            @endif
            <div class="alert alert-danger" id="showerror" style="display: none"><span class="glyphicon glyphicon-remove-sign"></span>
              <div> Error! Captcha verification failed </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-sx-12 input-group">
                <h2>Forgot Password</h2>
              </div>
            </div>
            <input type="hidden" value="0" name="soft_delete" />
            <input type="hidden" id="token" value="{{ csrf_token() }}">
            <!-- Text input-->
            <div id="emaildiv" @if($errors->has('email')) class="form-group has-error" @else class="form-group" @endif>
              <div class="col-md-12 col-sm-12 col-sx-12">
                <input id="email" name="email" type="email" placeholder="Email" class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"  value="{{ old('email')}}">
                <!-- <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger" style="display:block !important;">{{$errors->first('email')}}</div> -->
              </div>
            </div>
            <div @if($errors->has('captcha')) class="form-group captcha_img has-error" @else class="form-group captcha_img" @endif>
              <div class="col-md-12 col-sm-12 col-sx-12"> 
              {!! LaravelCaptcha\Facades\Captcha::html() !!} <br /><br />
              <input type="text" id="captcha" name="captcha" placeholder="Captcha" class="form-control input-md">
              <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <!-- <div class="alert-message alert-danger" style="display:block !important; margin-top:15px;">{{$errors->first('captcha')}}</div> -->
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-sx-12 text-center">
                <button class="btn btn-primary" type="submit" id="subbutton">Send Password Reset Link</button>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
@section('script')
  @parent 
<script type="text/javascript" src="/assets/js/auth.js"></script> 
@endsection
  @endsection