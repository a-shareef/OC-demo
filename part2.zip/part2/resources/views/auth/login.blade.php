<!-- resources/views/auth/login.blade.php -->

@extends('layouts.auth')
@section('title', 'Login')
@section('content')
  <div class="loginColumns">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row text-center"> <a  href="{{url('/')}}" ><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
        @if (session('success'))
                <div class="flash-message">
                <div class="alert alert-danger">
                     {!! session('success') !!}
                </div>
                </div>
            @endif
          <div class="col-lg-12">
            <form data-toggle="validator" method="POST" action="{{url('/')}}/auth/login" 
               method="post" role="form" style="display: block;" class="form-horizontal">
            {!! csrf_field() !!}
            <div class="form-group">
              <div class="col-xs-12">
                <input type="email" name="email" id="email" tabindex="1" 
                     class="form-control" placeholder="Email" value="{{ old('email') }}">
                <div class="alert-message alert-danger"> {{ $errors->first('email') }} </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-xs-12">
                <input type="password" name="password" id="password" tabindex="2" 
                    class="form-control" placeholder="Password">
                <div class="alert-message alert-danger"> {{ $errors->first('password') }} </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-xs-6 rememberPassword">
                <input type="checkbox" class="switch js-switch_1" tabindex="3" class="" name="remember" id="remember">
                <label for="remember"> Remember Me</label>
              </div>
              <div class="col-sm-6">
                <input type="submit" name="login-submit" id="login-submit"
                             tabindex="4" class="btn btn-primary pull-right" value="Log In">
              </div>
            </div>
            <div class="form-group">
              <div class="row">
                <div class="col-lg-12">
                  <div class="text-center"> <a href="{{url('/')}}/password/email" tabindex="5" 
                                class="text-primary">Forgot Password?</a> </div>
                </div>
                <div class="col-lg-12">
                  <div class="text-center"> <a href="{{url('/')}}/register/products" tabindex="5"
                                 class="text-primary">Register Products</a> </div>
                </div>
                <div class="col-lg-12">
                  <div class="text-center"> <a href="{{url('/')}}/finder/finderfront" tabindex="5" 
                                class="text-primary">Report Found Product</a> </div>
                </div>
                <div class="col-lg-12">
                  <div class="text-center"> <br><a href="http://www.uberid.com/foundthemshop" tabindex="5" 
                                class="text-primary" target="_BLANK">Purchase FoundThem™ enabled products</a> 
                                </div>
                </div>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection 