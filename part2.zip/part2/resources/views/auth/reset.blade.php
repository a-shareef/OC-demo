@extends('layouts.auth')
@section('title', 'Reset Password')
@section('content')
<div class="loginColumns">
  <div class="panel panel-login">
    <div class="panel-heading">
      <div class="row text-center"> <a  href="/" ><img src="{{url('/')}}/assets/images/{{siteLogo()}}"></a></div>
    </div>
    <div class="panel-body loginBox">
      <div class="row">
        <div class="col-lg-12">
          <form data-toggle="validator" method="POST" action="{{url('/')}}/password/reset" method="post"
             role="form" style="display: block;" class="form-horizontal">
          {!! csrf_field() !!}
          <input type="hidden" value="0" name="soft_delete" />
          @if (session('status'))
          <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
            <div> {{ session('status') }} </div>
          </div>
          @endif
          <input type="hidden" name="token" value="{{ $token }}">
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12">
              <h2>Reset Password</h2>
            </div>
          </div>
            <div class="hr-line-dashed"></div>          
          <!-- Text input-->
          <div class="form-group" id="validemail">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class=" input-group">
                <input id="email" name="email" tabindex="1" type="email" placeholder="Email"
                  class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
                  required value="{{ old('email')}}">
                <span class="glyphicon form-control-feedback" aria-hidden="true" id="cnfmglyphicon"></span>
                <div class="alert-message alert-danger" id="showerror">{{$errors->first('email')}}</div>
              </div>
            </div>
          </div>
            <div class="hr-line-dashed"></div>          
          <!-- Password input-->
          <div class="form-group" id="inppassword">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <p class="help-block"> Password must be <b>contain at least 8 characters</b>, including at least <b>1 number</b> and includes both <b>lower and uppercase</b> letters and <b> at least 1 special characters.</b></p>
              <div class=" input-group">
                <input id="password" data-minlength="6"           
                  name="password" tabindex="2" type="password" placeholder="Password" class="form-control input-md" required="" maxlength="16" minlength="8">
                <span class="glyphicon form-control-feedback" aria-hidden="true" id="validationerror"></span>
                <div class="alert alert-danger">{{$errors->first('password')}}</div>
                <div id="pwd_strength_wrap">
                  <div id="passwordDescription">Password not entered</div>
                  <div id="passwordStrength" class="strength0"></div>
                  <div id="pswd_info"> <strong>Matched Password Criteria:</strong>
                    <ul>
                      <li class="invalid" id="length">Minimum 8 and Maximum 16 characters</li>
                      <li class="invalid" id="pnum">At least one number</li>
                      <li class="invalid" id="capital">At least one lowercase &amp; one uppercase letter</li>
                      <li class="invalid" id="spchar">At least one special character</li>
                    </ul>
                  </div>
                  <!-- END pswd_info --> 
                </div>
                <!-- END pwd_strength_wrap --> 
                
              </div>
            </div>
          </div>
            <div class="hr-line-dashed"></div>
          <!-- Password input-->
          <div class="form-group" id="pwdcnfmformgrp">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class=" input-group">
                <input id="password_confirmation" name="password_confirmation" tabindex="3" type="password"
                  placeholder="Confirm Password" class="form-control input-md" data-match="#password"
                  data-match-error="Password don't match." required="">
                <span class="glyphicon form-control-feedback" aria-hidden="true" id="cnfmglyphicon2"></span>
                <div class="alert alert-danger" id="showerror2">{{$errors->first('password_confirmation')}}</div>
                {{--
                <div class="help-block with-errors"></div>
                --}} </div>
            </div>
          </div>
            <div class="hr-line-dashed"></div>
          <div class="form-group" id="resetbtn">
            <div>
              <div class="col-md-12 col-sm-12 col-xs-12 submitBtn">
                <div class="text-center">
                  <input type="hidden" id="scoreval">
                  <button class="btn btn-primary"  tabindex="4" type="submit" id="profile_submit" tabindex="4" name="profile_submit">
                  Reset Password
                  </button>
                </div>
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>