<!-- resources/views/auth/password.blade.php -->


  <?php $__env->startSection('title', 'Reset Password'); ?>
  <?php $__env->startSection('content'); ?>
  <div class="loginColumns">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row text-center"><a  href="<?php echo e(url('/')); ?>" ><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
          <div class="col-lg-12">
            <form id="passwordreset" class="loginform form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(url('/')); ?>/password/email" method="post" role="form" style="display: block;">
            <?php echo csrf_field(); ?>

            <?php if(session('status')): ?>
            <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
              <div> <?php echo e(session('status')); ?> </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
              <div> <?php echo e(session('error')); ?> </div>
            </div>
            <?php endif; ?>
            <?php if(count($errors)): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <div class="alert alert-danger">
                  <div>
                    <span class="glyphicon glyphicon-remove-sign"></span><?php echo e($error); ?>

                  </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="alert alert-danger" id="showerror" style="display: none"><span class="glyphicon glyphicon-remove-sign"></span>
              <div> Error! Captcha verification failed </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-sx-12 input-group">
                <h2>Forgot Password</h2>
              </div>
            </div>
            <input type="hidden" value="0" name="soft_delete" />
            <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
            <!-- Text input-->
            <div id="emaildiv" <?php if($errors->has('email')): ?> class="form-group has-error" <?php else: ?> class="form-group" <?php endif; ?>>
              <div class="col-md-12 col-sm-12 col-sx-12">
                <input id="email" name="email" type="email" placeholder="Email" class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"  value="<?php echo e(old('email')); ?>">
                <!-- <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger" style="display:block !important;"><?php echo e($errors->first('email')); ?></div> -->
              </div>
            </div>
            <div <?php if($errors->has('captcha')): ?> class="form-group captcha_img has-error" <?php else: ?> class="form-group captcha_img" <?php endif; ?>>
              <div class="col-md-12 col-sm-12 col-sx-12"> 
              <?php echo LaravelCaptcha\Facades\Captcha::html(); ?> <br /><br />
              <input type="text" id="captcha" name="captcha" placeholder="Captcha" class="form-control input-md">
              <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <!-- <div class="alert-message alert-danger" style="display:block !important; margin-top:15px;"><?php echo e($errors->first('captcha')); ?></div> -->
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-sx-12 text-center">
                <button class="btn btn-primary" type="submit" id="subbutton">Send Password Reset Link</button>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->startSection('script'); ?>
  ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 
<script type="text/javascript" src="/assets/js/auth.js"></script> 
<?php $__env->stopSection(); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>