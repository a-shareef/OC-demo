<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($translatedLang['dashboard_account_users']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row">
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="cs_client_products" name="cs_client_products" class="form-control" >
          <option value="">Select client products</option>
          
              <?php $__currentLoopData = $productArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
          <option  value="<?php echo e($key); ?>"> <?php echo e($product); ?> </option>
          
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </select>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="cs-users-table">
        <thead>
          <tr>
            <th><?php echo e($translatedLang['dashboard_name']); ?></th>
            <th><?php echo e($translatedLang['dashboard_email']); ?></th>
            <th><?php echo e($translatedLang['dashboard_address']); ?></th>
            <th><?php echo e($translatedLang['dashboard_phone']); ?></th>
            <th><?php echo e($translatedLang['dashboard_dob']); ?></th>
            <th><?php echo e($translatedLang['dashboard_products']); ?></th>
            <th><?php echo e($translatedLang['dashboard_action']); ?></th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage Suspended / Lost / Found Products</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="table-responsive">
      <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="msp-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Products</th>
            <th>Tag #</th>
            <th>FoundThem Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<input type="hidden" id="search" value="<?php echo e($translatedLang['dashboard_search']); ?>">
<input type="hidden" id="next" value="<?php echo e($translatedLang['dashboard_next']); ?>">
<input type="hidden" id="first" value="<?php echo e($translatedLang['dashboard_first']); ?>">
<input type="hidden" id="last" value="<?php echo e($translatedLang['dashboard_last']); ?>">
<input type="hidden" id="previous" value="<?php echo e($translatedLang['dashboard_previous']); ?>">
<input type="hidden" id="record_per_page" value="<?php echo e($translatedLang['dashboard_record_per_page']); ?>">
<input type="hidden" id="display" value="<?php echo e($translatedLang['dashboard_display']); ?>">
<input type="hidden" id="dashboard_of" value="<?php echo e($translatedLang['dashboard_of']); ?>">
<input type="hidden" id="showing_page" value="<?php echo e($translatedLang['dashboard_showing_page']); ?>">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>