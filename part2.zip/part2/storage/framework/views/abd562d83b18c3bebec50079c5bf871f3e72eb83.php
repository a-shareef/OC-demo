   <?php $__env->startSection('style'); ?>

     <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
      <link rel="stylesheet" href="//cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css">

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('home'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

 <!-- Included to make vible export button -->
<script src="//cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>

<script src="<?php echo e(url('/')); ?>/assets/js/dashboard.js"></script>
<!-- <script src="<?php echo e(url('/')); ?>/assets/js/manage_product.js"></script> -->
<script src="<?php echo e(url('/')); ?>/assets/js/manage_template.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/manage_tagno.js"></script>
<script type="text/javascript">


  $('form').submit(function() {
  $(":submit").attr("disabled", true);
});
  $( ":input" ).focus(function() {
      $(":submit").attr("disabled", false);
  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>