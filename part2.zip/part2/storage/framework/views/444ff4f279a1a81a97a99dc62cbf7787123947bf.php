<!-- resources/views/auth/password.blade.php -->

<?php $__env->startSection('title', 'Product Registration'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->startSection('content'); ?>
  <div class="loginColumns loginColumnsNew">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row text-center"><a href="<?php echo e(url('/')); ?>" ><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a> </a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
          <div class="col-lg-12">
            <h2>FT Product Registration</h2>
            <input type="hidden" value="0" name="soft_delete" />
            <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" id="ipaddress" value="<?php echo e(Request::ip()); ?>">
            
            <!-- Tabs Start-->
            <div class="tabs-container">
              <ul class="nav nav-tabs" id="registrationTabs" role="tablist">
                <li id="producttagid" role="presentation" class="active"><a href="#producttag" aria-controls="producttag" role="tab"><span class="glyphicon glyphicon-tags"></span> <span class="tabName"> Product Tag #</span></a></li>
                <li id="emailaddressid" role="presentation" class="disabled"><a href="#emailaddress" aria-controls="emailaddress" role="tab" ><span class="glyphicon glyphicon-envelope"></span> <span class="tabName"> Email Address</span></a></li>
                <li id="registrationid" role="presentation" class="disabled"><a href="#registration" aria-controls="registration" role="tab" ><span class="glyphicon glyphicon-user
"></span> <span class="tabName"> Registration</span></a></li>
                <!-- <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Registration</a></li> -->
              </ul>
              
              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="producttag">
                  <div class="panel-body">
                    <div class="alert alert-danger" id="error" style="display:none"></div>
                    <div class="alert alert-danger" id="capTerror" style="display:none"></div>
                    <div id="tagMsgBanner" class="col-md-12 col-sm-12 col-sx-12 text-center"  style="display:none">
                      <h4 class="msgBannerTxt" id="msgtext">The FoundThem™ tag# you entered has already been registered.</h4>
                      <h4 class="msgBannerTxt" id="msgtext">If you have found the product the tag is attached to, please report it by clicking the button below.</h4>
                      <div class="hr-line-dashed"></div>
                      <a href="/finder/finderfront" id="reporttag" class="btn btn-primary">Report Found Tag#</a>
                      <button type="button" id="backTag" class="btn btn-primary">Back</button>
                    </div>
                    <div id="tagContent">
                      <form class="loginform form-horizontal" data-toggle="validator" id="productRegister1" role="form" style="display: block;">
                        <?php echo csrf_field(); ?>

                        <div id="tagnoerror" class="form-group">
                          <div class="col-md-12 col-sm-12 col-sx-12">
                            <input  id="tagno" name="tagno" type="product" placeholder="Enter Product Tag #."
                class="form-control input-md" required value="">
                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                            <div class="alert-message alert-danger"><?php echo e($errors->first('product')); ?></div>
                          </div>
                        </div>
                        <div class="hr-line-dashed"></div>
                        <div class="form-group" id="captVerror">
                          <div class="col-md-12 col-sm-12 col-sx-12">
                            <?php echo LaravelCaptcha\Facades\Captcha::html(); ?> <br /><br />
                            <input type="text" id="captcha" name="captcha" class="form-control input-md" placeholder="Captcha"> 
                           <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                            <div class="alert-message alert-danger" id="cap_error"></div>
                          </div>
                        </div>
                        <div class="hr-line-dashed"></div>
                        <div class="col-md-12 col-sm-12 col-sx-12 text-center">
                          <input type="hidden" id="captchSdata" value="0">
                          <input  id="lasttInsertId" name="lasttInsertId" type="hidden" value="">
                          <button class="btn btn-primary" id="producttagBtn" type="submit">Next </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="emailaddress">
                  <div class="panel-body">
                    <div class="alert alert-danger" id="emailtxterror" ></div>
                    <div class="loader1"></div>
                    <div id="emailMsgBanner" class="text-center submitBtn">
                      <h4 class="msgBannerTxt" id="emailmsgtext">Do you wish to create a new FoundThem™ account?</h4>
                      <div class="hr-line-dashed"></div>
                      <div class="col-md-12 col-sm-12 col-sx-12">
                        <button id="emailreturnbtn" class="btn btn-primary" type="button">Return to enter email address</button>
                        <button id="emailcontinuebtn" class="btn btn-primary" type="button">Continue</button>
                      </div>
                    </div>
                    <div id="producttagMsgBanner" class="text-center">
                      <h4 class="msgBannerTxt" id="producttagmsgtext">The FoundThem™ tag# you input is in the process of being registered at this time. </h4>
                      <div class="row">
                        <div class="col-md-12 col-sm-12 col-sx-12">
                          <div class="hr-line-dashed"></div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-sx-12">
                        <button id="emailreturnbtn1" class="btn btn-primary" type="button">Return to enter email address</button>
                      </div>
                    </div>
                    <div id="producttagMsgBannerAct" class="text-center submitBtn">
                      <h4 class="msgBannerTxt" id="actproducttagmsgtext">It seems that you may have already registered the tag# but you have not activated your account. If you have not received an account activation email, click on the button below and the email will be resent to the email entered previously. Be sure to check any Spam folders.</h4>
                      <div class="row">
                        <div class="col-md-12 col-sm-12 col-sx-12">
                          <div class="hr-line-dashed"></div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-sx-12" id="actBtns">
                        <button id="emailreturnbtn2" class="btn btn-primary" type="button">Return to enter email address</button>
                        <button id="emailReactivation" class="btn btn-primary" type="button">Resend Activation Email</button>
                      </div>
                      <div class="col-md-12 col-sm-12 col-sx-12"> <a href="<?php echo e(env('FOUNDTHEM_URL')); ?>" target="_blank" class="btn btn-primary" id="foundtbtn1" >FoundThem™</a> </div>
                    </div>
                    <div id="emailContent">
                      <form class="loginform" onsubmit="return false;" data-toggle="validator" id="productRegister2" role="form" style="display: block;">
                        <?php echo csrf_field(); ?>

                        <div id="emailerror" class="form-group">
                          <div class="alert alert-danger" id="emailbtnnxt"></div>
                          <div id="emaildiv" class="col-md-12 col-sm-12 col-sx-12 input-group">
                            <input id="emailreg" name="emailreg" type="email" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
          placeholder="Enter your email address"
          class="form-control input-md"
          required value="<?php echo e(old('email')); ?>">
                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
                        </div>
                        <div class="hr-line-dashed"></div>
                        <div class="col-md-12 col-sm-12 col-sx-12 text-center">
                          <button class="btn btn-primary" id="productemailBack" type="button"> Back</button>
                          <button class="btn btn-primary" id="productemailBtn" type="button">Next </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="registration">
                  <div class="panel-body">
                    <div class="loader1"></div>
                    <div id="securityQtn">
                    <form class="loginform" onsubmit="return false;" data-toggle="validator" id="productRegister" method="POST" action="<?php echo e(route('register_products')); ?>" role="form" style="display: block;">
                      <?php echo csrf_field(); ?>

                      <div id="secQtnP" class="text-center">
                        <h4 class="msgBannerTxt" id="securityMsgText">To validate your account, please answer the security question below.</h4>
                        <div class="alert alert-danger alert-dismissible text-left" id="dob_error" style="display:none;"></div>
                        <div class="form-group" id="doberror">
                          <div class="form-group input-group col-md-12 col-sm-12 col-sx-12 date" id="date_of_birth_sec">
                            <input id="dob_sec" name="dob_sec" type="text" placeholder="Date of birth (MM/DD/YYYY)"
          class="form-control input-md" required
          value="" >
                            <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span>
                            <div class="alert-message alert-danger"><?php echo e($errors->first('dob')); ?></div>
                          </div>
                        </div>
                        <div id="phonenoerror" class="form-group">
                          <div id="phonediv" class="col-md-12 col-sm-12 col-sx-12 input-group">
                            <input id="phone" name="phone" pattern="^\D*(?:\d\D*){10}" type="tel"
            placeholder="Enter mobile no"
            class="form-control input-md" required=""
            value="<?php echo e(old('phone')); ?>">
                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                            <div class="alert-message alert-danger"><?php echo e($errors->first('phone')); ?></div>
                          </div>
                        </div>
                        <div id="ziperror" class="form-group">
                          <div id="zipdiv" class="col-md-12 col-sm-12 col-sx-12 input-group">
                            <input id="zip" name="zip" type="text" pattern="^(0|[1-9][0-9]*)$" placeholder="Enter zip code"
          class="form-control input-md" required="" 
          value="<?php echo e(old('zip')); ?>">
                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                            <div class="alert-message alert-danger"><?php echo e($errors->first('zip')); ?></div>
                          </div>
                        </div>
                        <div id="supportDiv" class="form-group col-md-12 col-sm-12 col-xs-12 col-lg-12 submitBtn">
                          <h4 class="msgBannerTxt">It appears that we are having trouble verifying your account details based on the answers you provided. Please press the button below and a member of the customer support team will contact you. Thank you.</h4>
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-sx-12">
                              <div class="hr-line-dashed"></div>
                            </div>
                          </div>
                          <button class="btn btn-primary" id="nextQuestion" type="button">Contact Support Team</button>
                        </div>
                        <div id="supportEmailDiv" class="form-group col-md-12 col-sm-12 col-xs-12 col-lg-12 submitBtn">
                          <h4 class="msgBannerTxt">Thank you. We have received your message and a member of our Customer Service team will be in contact with you to resolve the issue.</h4>
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-sx-12">
                              <div class="hr-line-dashed"></div>
                            </div>
                          </div>
                          <a href="<?php echo e(env('FOUNDTHEM_URL')); ?>" target="_blank" class="btn btn-primary" id="foundtbtn" >FoundThem™</a> </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                          <button class="btn btn-primary" id="submit_register_back" type="button"> Back</button>
                          <button class="btn btn-primary" id="submit_register" type="button" >Register </button>
                          <!-- <input class="btn-primary" id="submit_register" type="button" value="Register" /> -->
                          
                          <input type="hidden"  id="register_success" value="" name="register_success" />
                          <input type="hidden"  id="secQuestionsValid" value="" name="secQuestionsValid" />
                          <input type="hidden"  id="reg_tag_no" value="" name="tagno" />
                          <input type="hidden"  id="reg_email" value="" name="email" />
                        </div>
                      </div>
                      </div>
                    </form>
                    <div id="regFormContent"></div>
                    <!--  <div role="tabpanel" class="tab-pane" id="settings">...</div> --> 
                  </div>
                </div>
                <!-- Tabs End--> 
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" tabindex="-1" role="dialog" id="registrationmodal" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <h4 class="modal-title text-center"></h4>
            </div>
            <div class="modal-footer submitBtn">
              <form enctype="multipart/form-data" method="POST" action="">
                <a href="/finder/finderfront" id="reporttag" class="btn btn-primary">Report Tag</a>
                <button type="button" id="backTag" class="btn  btn-primary" data-dismiss="modal"> Back</button>
                <button type="button" id="emailcontinuebtn" class="btn  btn-primary">Continue </button>
                <button type="button" id="emailreturnbtn" class="btn btn-primary" data-dismiss="modal">Return to enter email address</button>
              </form>
            </div>
          </div>
          <!-- /.modal-content --> 
        </div>
        <!-- /.modal-dialog --> 
      </div>
    </div>
  </div>
<!-- /.modal --> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 
<script src="<?php echo e(url('/')); ?>/assets/js/profile.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/manage_tagno.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>