<?php $__env->startSection('title', 'Login History Report'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Login History Report</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row">
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="client_products" name="client_products" class="form-control" >
          <option value="">Select Member Type</option>
          
   
          <option  value="1">Super Admin</option>
          <option  value="2">Admin</option>
          <option  value="3">Member</option>
          <option  value="4">CS Agent</option>
        </select>
      </div>
    </div>
    <div id="searchdates" class="form-horizontal">
      <div class="form-group">
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="fini">
            <input id="fini" name="fini" type="text" placeholder="From Date"
  class="form-control input-md blurclass" title="From Access Date"  required="required">
            <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span> </div>
        </div>
        <label class="control-label pull-left wth100per">to</label>
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="ffin">
            <input id="ffin" name="ffin" type="text" placeholder="To Date"
  class="form-control input-md blurclass" title="To Access Date"  required="required">
            <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="ffincal"></span> </span> </div>
            </div>
        <div class="col-md-5 col-sm-12 col-xs-12 search-result-btn">
            <button type="button" id="dateSearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
            <button type="button" id="dateclear" class="btn btn-primary"><i class="fa fa-times"></i> Clear</button><span style="font-size:14px;float: right; margin-right: -15px"><b>Report Date:</b> <?php echo e(date('m-d-Y')); ?></span>
          </div>
        </div>
      </div>
   
      <table class="table table-striped table-bordered responsive" cellspacing="0" width="100%" id="loginhistorytable">
        <thead>
          <tr>
            <th data-priority="1">Name</th>
            <th data-priority="2">Email</th>
            <th data-priority="3">IP</th>
            <th>Location</th>
            <th>Member Type</th>
            <th>Login Date(UTC)</th>
          </tr>
        </thead>
      </table>
    
  </div>
</div>
<input type="hidden" id="search" value="<?php echo e($translatedLang['dashboard_search']); ?>">
<input type="hidden" id="next" value="<?php echo e($translatedLang['dashboard_next']); ?>">
<input type="hidden" id="first" value="<?php echo e($translatedLang['dashboard_first']); ?>">
<input type="hidden" id="last" value="<?php echo e($translatedLang['dashboard_last']); ?>">
<input type="hidden" id="previous" value="<?php echo e($translatedLang['dashboard_previous']); ?>">
<input type="hidden" id="record_per_page" value="<?php echo e($translatedLang['dashboard_record_per_page']); ?>">
<input type="hidden" id="display" value="<?php echo e($translatedLang['dashboard_display']); ?>">
<input type="hidden" id="dashboard_of" value="<?php echo e($translatedLang['dashboard_of']); ?>">
<input type="hidden" id="showing_page" value="<?php echo e($translatedLang['dashboard_showing_page']); ?>">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<input type="hidden" id="filtercolumnvalue" value="5">
<input type="hidden" id="datatableidvalue" value="loginhistorytable">
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.membersreport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>