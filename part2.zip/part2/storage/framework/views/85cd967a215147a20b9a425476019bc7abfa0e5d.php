<?php $__env->startSection('title', 'Product Lost'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> <?php echo e(session('error')); ?> </div>
</div>
<?php endif; ?>
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Add Product Description</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row">
      <label class="col-md-12 imageBox"> <img id="tempProfileImage" src="<?php echo e(URL::to('/')); ?>/uploads/productavatar/<?php echo e($currentproductimage); ?>" class="img-circle">
        <input type="hidden" value="" id="imagewidthval">
        <input type="hidden" value="" id="imageheightval">
      </label>
      <?php if( $currentproductimage != 'productdefault.png'): ?>
      <div id="deleteformdiv" class="col-sm-4 text-center col-sm-offset-4 submitBtn profileBtnBox"> <br>
        <a href="#" class="btn btn-primary imagedelete">Replace</a> 
        <!-- btnimagedelete class for red color button --> 
        <a href="#" id="deleteimg" class="btn btn-primary imagedelete">Delete</a>
        <div class="modal fade" tabindex="-1" role="dialog" id="deletemodal">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-body">
                <h4 class="modal-title text-center">Are you sure you want to delete the FoundThem product image ?</h4>
              </div>
              <div class="modal-footer submitBtn">
                <form enctype="multipart/form-data" method="POST" action="">
                  <input type="hidden" value="<?php if(isset($currentproductid) && $currentproductid != ''): ?><?php echo e($currentproductid); ?><?php endif; ?>" name="userid">
                  <a href="/admin/productavatar/<?php if(isset($currentproductid) && $currentproductid != ''): ?><?php echo e($currentproductid); ?><?php else: ?><?php echo e(-1); ?><?php endif; ?>" id="deleteimg" class="btn btn-primary">Yes</a>
                  <button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
                </form>
              </div>
            </div>
            <!-- /.modal-content --> 
          </div>
          <!-- /.modal-dialog --> 
        </div>
        <!-- /.modal --> 
      </div>
      <?php else: ?>
      <div id="updateformdiv" class="col-md-12 text-center">
        <form enctype="multipart/form-data" method="POST" action="<?php echo e(url('/')); ?>/admin/product/image" role="form">
          <br>
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token"/>
          <label>Upload Product Image</label>
          <br>
          <div class="btn btn-primary btn-file"> <i class="glyphicon glyphicon-folder-open"></i> <span class="hidden-xs">Browse</span>
            <input type="file" name="avatar" id="avatar"/>
          </div>
          <input type="hidden" name="x" id="x"/>
          <input type="hidden" name="y" id="y"/>
          <input type="hidden" name="w" id="w"/>
          <input type="hidden" name="h" id="h"/>
          <div class="modal fade" tabindex="-1" role="dialog" id="profilemodal">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Drag your mouse to select part of the image which you need to crop.</h4>
                </div>
                <div class="modal-body">
                  <div class="loader1"></div>
                  <image id="userimage"/>
                </div>
                <div class="modal-footer submitBtn">
                  <input type="hidden" value="<?php if(isset($currentproductid) && $currentproductid != ''): ?><?php echo e($currentproductid); ?><?php endif; ?>" name="productId"  id="productId"/>
                  <!--  <input type="hidden" value="<?php if(isset($users->fk_role_id) && $users->fk_role_id != ''): ?><?php echo e($users->fk_role_id); ?><?php endif; ?>" name="userIdroleprofile"  id="userIdroleprofile"/> --> 
                  <!-- <button type="button" id="rotateimage" class="btn btn-primary" >Rotate</button> -->
                  <input type="button" id="usersave" class="btn btn-primary" value="Crop and Upload" disabled>
                  <button type="button" id="closemodal" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
              </div>
              <!-- /.modal-content --> 
            </div>
            <!-- /.modal-dialog --> 
          </div>
        </form>
      </div>
      <?php endif; ?> </div>
      
      <div class="hr-line-dashed"></div>
    <form name="productlost" class="form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(route('productdescadd')); ?>">
      <?php echo csrf_field(); ?> 
      <!-- Form Name --> 
      
      <!-- Form Name -->
      <input type="hidden" value="<?php echo e($loggedinuserid); ?>" name="loggedinuserid" />
      <input type="hidden" value="<?php echo e($currentproductid); ?> " name="currentproductid" />
      <input type="hidden" value="<?php echo e($ip); ?>" name="ip" />
      <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>" id="token"/>
      <input type="hidden" name="userId" value="<?php echo e(Session::get('userId')); ?>" id="userId"/>
      <!-- Product Details From -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product"> Product Name: </label>
        <div class="col-sm-7">
          <input id="location" name="location" type="text"  class="form-control input-md" disabled="disabled" value=" <?php echo e($current_productname); ?> (<?php echo e($current_productsequence); ?>)">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="description"> User Description: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="description" name="description" required value="" placeholder="Item that the FoundThem tag is attached to. Example: backpack (140 characters)" maxlength="140"><?php echo e($user_description); ?></textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Button -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="cancel"></label>
        <div class="col-sm-7">
          <input type="submit"  name="Submit" value="Submit" id="description_submit" name="description_submit"
    class="btn btn-primary"  />
          <input class="btn  btn-primary" type="reset" value="Reset">
          <a id="cancel-button" name="button2id" class="btn  btn-primary" href="<?php echo e(route('displayUsersProduct',session('userId'))); ?>">Cancel</a> </div>
        <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/assets/bootstrap/js/validator.js"></script> 
    <script src="/assets/js/piexif.js"></script> 
   <?php $__env->stopSection(); ?>
 <?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/product/usersAddDescription/{user_id}'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>