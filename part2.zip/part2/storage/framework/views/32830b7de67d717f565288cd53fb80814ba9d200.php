<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="alert-ajax alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('status')); ?> </div>
<?php endif; ?>

<div class="row">
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-success pull-right">Total</span>
        <h5>Members</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins"><?php echo e($totalmembers); ?></h1>
        
        <small>Total Members</small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-info pull-right">Total</span>
        <h5>Orders</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins"><?php echo e($ordercount); ?></h1>
        
        <small>Orders</small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-primary pull-right">Monthly</span>
        <h5>Product Registered</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins"><?php echo e($prodregcount); ?></h1>
        
        <small>Product Registered In <?php echo e(date('M Y')); ?></small> </div>
    </div>
  </div>
  <div class="col-lg-3 col-xs-6">
    <div class="ibox float-e-margins">
      <div class="ibox-title"> <span class="label label-danger pull-right">Today</span>
        <h5>User Login activity</h5>
      </div>
      <div class="ibox-content">
        <h1 class="no-margins"><?php echo e($userlogincount); ?></h1>
        
        <small>Login activity on  <?php echo e(date('M-d-Y')); ?></small> </div>
    </div>
  </div>
</div>


<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($translatedLang['dashboard_account_users']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="row">
      <div class="form-group col-md-3 col-sm-4 col-xs-6">
        <select required id="client_products" name="client_products" class="form-control" >
          <option value="">Select client products</option>

          <?php $__currentLoopData = $productArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <option value="<?php echo e($key); ?>"> <?php echo e($product); ?> </option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
      </div>
    </div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="users-table">
        <thead>
          <tr>
            <th data-priority="1"><?php echo e($translatedLang['dashboard_name']); ?></th>
            <th><?php echo e($translatedLang['dashboard_email']); ?></th>
            <th><?php echo e($translatedLang['dashboard_address']); ?></th>
            <th><?php echo e($translatedLang['dashboard_phone']); ?></th>
            <th><?php echo e($translatedLang['dashboard_dob']); ?></th>
            <!-- <th>Member type</th> -->
            <th class="none"><?php echo e($translatedLang['dashboard_products']); ?></th>
            <th data-priority="3"><?php echo e($translatedLang['dashboard_status']); ?></th>
            <th data-priority="2"><?php echo e($translatedLang['dashboard_action']); ?></th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($translatedLang['dashboard_admin_cs_agents']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
  	<div class="row"><div class="form-group col-md-12 col-sm-12 col-xs-12 text-right"><a href="<?php echo e(url('/')); ?>/user/csa" class='btn btn-primary btn-xs pull-right'><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e($translatedLang['dashboard_add_new']); ?></a></div></div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="csa-table">
        <thead>
          <tr>
            <th data-priority="1"><?php echo e($translatedLang['dashboard_name']); ?></th>
            <th><?php echo e($translatedLang['dashboard_email']); ?></th>
            <th><?php echo e($translatedLang['dashboard_type']); ?></th>
            <th><?php echo e($translatedLang['dashboard_phone']); ?></th>
            <th><?php echo e($translatedLang['dashboard_last_activity_on_date']); ?></th>
            <th data-priority="2"><?php echo e($translatedLang['dashboard_action']); ?></th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage Order Status</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
  <div class="row"><div class="form-group col-md-12 col-sm-12 col-xs-12 text-right"><a href="<?php echo e(url('/')); ?>/admin/order/add" class='btn btn-primary btn-xs pull-right'><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e($translatedLang['dashboard_add_new']); ?> </a></div></div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="mup-table">
        <thead>
          <tr>
            <th data-priority="1">Company</th>
            <th>Order No</th>
            <th>Products</th>
            <th>Qty</th>
            <th>Reg</th>
            <th>Unreg</th>
            <th>Order Date</th>
            <th data-priority="3">Order Status</th>
            <th data-priority="2"><?php echo e($translatedLang['dashboard_action']); ?></th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage Suspended / Lost / Found Products</h5>
    <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="msp-table">
        <thead>
          <tr>
            <th data-priority="1">Name</th>
            <th>Email</th>
            <th>Products</th>
            <th>Tag #</th>
            <th>FoundThem Date</th>
            <th data-priority="3">Status</th>
            <th data-priority="2">Action</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<!-- FT tag tranfer section start -->
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Transfer FT Tag</h5>
    <div class="ibox-tools"><a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content dashboard-ibox-content">
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="tt-table">
        <thead>
          <tr>
            <th data-priority="1">Name</th>
            <th>Email</th>
            <th>Products</th>
            <th>Tag #</th>
            <th>Registered Date</th>
            <th data-priority="3">Status</th>
            <th data-priority="2">Action</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<!-- FT tag tranfer section end -->
<script src="/assets/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/chartJs/Chart.min.js"></script>
<!-- <script src="<?php echo e(url('/')); ?>/assets/js/chartJs/chartjs-demo.js"></script> -->
<input type="hidden" id="search" value="<?php echo e($translatedLang['dashboard_search']); ?>">
<input type="hidden" id="next" value="<?php echo e($translatedLang['dashboard_next']); ?>">
<input type="hidden" id="first" value="<?php echo e($translatedLang['dashboard_first']); ?>">
<input type="hidden" id="last" value="<?php echo e($translatedLang['dashboard_last']); ?>">
<input type="hidden" id="previous" value="<?php echo e($translatedLang['dashboard_previous']); ?>">
<input type="hidden" id="record_per_page" value="<?php echo e($translatedLang['dashboard_record_per_page']); ?>">
<input type="hidden" id="display" value="<?php echo e($translatedLang['dashboard_display']); ?>">
<input type="hidden" id="dashboard_of" value="<?php echo e($translatedLang['dashboard_of']); ?>">
<input type="hidden" id="showing_page" value="<?php echo e($translatedLang['dashboard_showing_page']); ?>">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>