<?php $__env->startSection('title', 'Manage Email Templates'); ?>
<?php $__env->startSection('content'); ?> 
<!-- Form Name --> 

<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> <?php echo e(session('error')); ?> </div>
</div>
<?php endif; ?>
<form name="assignTemplate" id="assignTemplate" class="form-horizontal" method="POST" action="<?php echo e(route('assignTemplate')); ?>">
  <?php echo csrf_field(); ?>

  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5><?php echo e($getTranslatedLang['manage_email_template_assign_email_template']); ?></h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content"> <a href="<?php echo e(route('manage_email')); ?>"  class="btn btn-primary"><i class="fa fa-envelope"></i> <?php echo e($getTranslatedLang['manage_email_template_message']); ?></a> <a href="<?php echo e(route('assign_template')); ?>"  class="btn btn-primary"><i class="fa fa-check"></i> <?php echo e($getTranslatedLang['manage_email_template_assign']); ?></a> </div>
  </div>
  <!-- Select Basic -->
  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($getTranslatedLang['manage_email_template_email_template']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="table-responsive">
      <table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer">
        <tr>
          <th><?php echo e($getTranslatedLang['manage_email_template_template_name']); ?></th>
          <th><?php echo e($getTranslatedLang['manage_email_template_assign_to']); ?></th>
          <th><?php echo e($getTranslatedLang['manage_email_template_assign']); ?></th>
          <th><?php echo e($getTranslatedLang['manage_email_template_close']); ?></th>
        </tr>
        <tr>
          <td><select id="templateName" name="templateName" class="form-control">
              <option value="0" selected="selected">Select template</option>
              
              <?php $__currentLoopData = $retriveTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retriveTemplate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
              <option value="<?php echo e($retriveTemplate->id); ?>"><?php echo e($retriveTemplate->template_name); ?></option>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </select></td>
          <td><select id="checkpointName" name="checkpointName" class="form-control">
              
                  <?php $__currentLoopData = $retriveCheckPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retriveCheckPoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
              <option value="<?php echo e($retriveCheckPoint->id); ?>"><?php echo e($retriveCheckPoint->operation); ?></option>
              
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </select></td>
          <td><button id="assignTemplate" name="assignTemplate" class='btn btn-primary'><i class="fa fa-check"></i><!--<?php echo e($getTranslatedLang['manage_email_template_assign']); ?>--></button></td>
          <td><a href="<?php echo e(route('manage_email')); ?>" class='btn btn-primary'><i class="fa fa-times"></i><!--<?php echo e($getTranslatedLang['manage_email_template_close']); ?>--></a></td>
        </tr>
      </table>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/manage-email/assign-template'); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>