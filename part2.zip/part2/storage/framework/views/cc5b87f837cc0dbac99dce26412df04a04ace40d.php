<?php $__env->startSection('title', 'Customer Service Agent Current FT Status Report'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        <?php echo e(session('status')); ?>

    </div>
</div>
<?php endif; ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Customer Service Agent Current FT Status Report</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
<div class="tableContentBox">
    <div id="searchdates" class="form-horizontal">
          <div class="form-group">
        <label class="control-label pull-left wth100per labeldt">From:</label>
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="fini">
            <input id="fdate" name="fini" type="text" placeholder="From Date"
  class="form-control input-md blurclass" title="From Access Date"  required="required"><span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
           </div>
        </div>
        <label class="control-label pull-left wth100per">To:</label>
        <div class="col-md-3 col-sm-5 col-xs-5 wth100per">
          <div class="input-group date" id="ffin">
            <input id="tdate" name="ffin" type="text" placeholder="To Date"
  class="form-control input-md blurclass" title="To Access Date"  required="required"><span class="input-group-addon"> <span class="glyphicon glyphicon-calendar" id="finical"></span> </span>
            </div>
            </div>
        <div class="col-md-5 col-sm-12 col-xs-12 search-result-btn">
            <button type="button" id="ftdateSearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
            <button type="button" id="dateclear" class="btn btn-primary"><i class="fa fa-times"></i> Clear</button>
             <span style="font-size:14px;float: right; margin-right: -15px"><b>Report Date:</b> <?php echo e(date('m-d-Y')); ?></span>
          </div>

         
        </div>
        </div>
    <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
    <div id="containerFN" class="csmainchart"></div>
    <div id="containerTN" class="Customer Service Agent Current FT Status Report"></div>
    <div id="containersTN" class="This report allows the customer service agent to see all registered FT Tags by status."></div>
    <div id="containerPlotd" class="all"></div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('admin/reports/'.$report); ?>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.chartlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>