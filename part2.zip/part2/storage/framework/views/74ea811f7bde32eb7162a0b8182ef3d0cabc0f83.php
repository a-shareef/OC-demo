<!-- resources/views/user/activate.blade.php -->


<?php $__env->startSection('title', 'Activation'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<div class="row">
  <div class="loginColumns">
    <div class="panel panel-login">
      <div class="panel-heading">
        <div class="row text-center"><a><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a> </div>
      </div>
      <div class="panel-body loginBox">
        <div class="row">
          <div class="col-lg-12">
            <form class="form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(url('/')); ?>/activate" method="post" role="form" style="display: block;">
            <?php echo csrf_field(); ?>

            <fieldset>
              <!-- Form Name -->
              <h2>Set up your password for the first time</h2>
              <!-- Password input-->
              <div class="form-group" id="inppassword">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <p class="help-block"> Password must be <b>contain at least 8 characters</b>, including at least <b>1 number</b> and includes both <b>lower and uppercase</b> letters and <b> at least 1 special characters.</b></p>
                  <div class="hr-line-dashed"></div>
                  <div class=" input-group">
                    <input id="password" tabindex="1" data-minlength="8" maxlength="16" minlength="8"  
                   name="password" type="password" placeholder="Password" class="form-control input-md" required="">
                    <span class="glyphicon form-control-feedback" aria-hidden="true" id="validationerror"></span>
                    <div class="alert alert-danger"><?php echo e($errors->first('password')); ?></div>
                    <div id="pwd_strength_wrap">
                      <div id="passwordDescription">Password not entered</div>
                      <div id="passwordStrength" class="strength0"></div>
                      <div id="pswd_info"> <strong>Matched Password Criteria:</strong>
                        <ul>
                          <li class="invalid" id="length">Minimum 8 and Maximum 16 characters</li>
                          <li class="invalid" id="pnum">At least one number</li>
                          <li class="invalid" id="capital">At least one lowercase &amp; one uppercase letter</li>
                          <li class="invalid" id="spchar">At least one special character</li>
                        </ul>
                      </div>
                      <!-- END pswd_info --> 
                    </div>
                    <!-- END pwd_strength_wrap --> 
                    
                  </div>
                </div>
              </div>
              <!-- Password input-->
              <div class="hr-line-dashed"></div>
              <div class="form-group" id="pwdcnfmformgrp">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class=" input-group">
                    <input id="password_confirmation" name="password_confirmation"
                    type="password" tabindex="2" placeholder="Confirm Password" class="form-control input-md"
                    data-match="#password" data-match-error="Password don't match" required="required">
                    <span class="glyphicon form-control-feedback" aria-hidden="true" id="cnfmglyphicon"></span>
                    <div class="alert alert-danger" id="showerror"><?php echo e($errors->first('password_confirmation')); ?></div>
                    <div class="help-block with-errors"></div>
                  </div>
                </div>
              </div>
              <div class="hr-line-dashed"></div>
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div id="privacypolicy">
                    <p class="help-block">
                      <input required type="checkbox" id="activatecheckbtn" class="switch js-switch_1" tabindex="3" name="agree" value="agree" />
                      I have read and agree to the <a target="_blank" class="external" href="https://www.uberid.com/terms-of-service">Terms of Service</a> and <a target="_blank" class="external" href="https://www.uberid.com/privacy-policy">Privacy Policy</a>.</p>
                  </div>
                </div>
              </div>
              <input type="hidden" name="to_user" value="<?php echo e($to_user); ?>">
              <input type="hidden" name="from_user" value="<?php echo e($from_user); ?>">
              <input type="hidden" name="tag_no" value="<?php echo e($tag_no); ?>">
              <input type="hidden" name="trans_notes" value="<?php echo e($trans_notes); ?>">
              <div class="form-group" id="activatebtn">
                <div class="row">
                  <div class="col-sm-12 text-center">
                    <input type="hidden" id="scoreval">
                    <button id="profile_submit" tabindex="4" name="profile_submit" class="disabled btn btn-primary">Submit</button>
                  </div>
                  <input type="hidden" value="<?php echo e($email); ?>" name="email" />
                </div>
              </div>
            </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 
<script type="text/javascript">
   $('#activatecheckbtn').change(function(){
            if($(this).prop("checked") == true){
                $("#profile_submit").removeClass('disabled');
            }
            else if($(this).prop("checked") == false){
                $("#profile_submit").addClass('disabled');
            }
        });
</script> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>