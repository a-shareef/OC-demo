<?php $__env->startSection('title', 'Site Configuration'); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('success')); ?> </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<?php  $languageTrans = languageTranslate("Site Configuration ")  ?>
<form enctype="multipart/form-data" method="post" action="<?php echo e(url('/')); ?>/site-config-logo" class="form-horizontal">
  <?php echo csrf_field(); ?>

  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($languageTrans['site_config']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
  <div class="form-group">
    <label class="col-sm-3 control-label"> <?php echo e($languageTrans['site_config_select_file']); ?>: </label>
    <div class="col-sm-7 browseFile">
      <input id="input-4" name="file_upload" type="file" class="file-loading">
    </div>
  </div>
      <div class="hr-line-dashed"></div>
</form>
<div class="formFiled">
  <form method="post" action="<?php echo e(url('/')); ?>/site-config-slogan" class="form-horizontal">
    <?php echo csrf_field(); ?> 
    <!-- Textarea -->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="slogan"> <?php echo e($languageTrans['site_config_update_slogan']); ?>: </label>
      <div class="col-sm-7">
        <textarea class="form-control" id="slogan" name="slogan"></textarea>
      </div>
    </div>
      <div class="hr-line-dashed"></div>
    
    <!-- Button -->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="btnslogan"></label>
      <div class="col-sm-7">
      <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('Site Config', 'Edit') == true)): ?>
        <button id="btnslogan" name="btnslogan" class="btn btn-primary"> <?php echo e($languageTrans['site_config_update']); ?> </button>
      <?php endif; ?>  
        <input class="btn btn-primary" type="reset" value=" <?php echo e($languageTrans['site_config_reset']); ?>">
      </div>
    </div>
  </form>
</div>
</div>
<input type="hidden" id="upload_image" value="<?php echo e($languageTrans['site_config_upload_image']); ?>" />
<input type="hidden" id="browse_image" value="<?php echo e($languageTrans['site_config_browse_image']); ?>" />
<input type="hidden" id="remove_image" value="<?php echo e($languageTrans['site_config_remove_image']); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/fileinput.min.js"></script> 
<script type="text/javascript" src="/assets/js/siteConfig.js"></script> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('/user/site-config'); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>