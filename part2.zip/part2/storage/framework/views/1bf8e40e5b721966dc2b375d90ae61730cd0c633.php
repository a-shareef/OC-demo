<!-- resources/views/user/profile.blade.php -->


<?php $__env->startSection('title', 'User Profile'); ?>
<?php $__env->startSection('style'); ?>
##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac##
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
<link href="<?php echo e(url('/')); ?>/assets/css/common.css" rel="stylesheet">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('status')); ?> </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<form id="userRegisterForm"  class="regTabsForm form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(route('register_users')); ?>" role="form" style="display: block;">
  <?php echo csrf_field(); ?>

  <h2>Register User</h2>
  <div class="form-group">
    <div class="col-sm-12 text-center asterisk_notice_text"><span class="asterisk_notice text-center">(* Fields marked as mandatory)</span></div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="user_title"> <?php echo e($transLanguage['edit_title']); ?>: </label>
    <div class=" col-sm-7">
      <select required id="user_title" name="user_title" class="form-control" >
        <option value="">Select  <?php echo e($transLanguage['edit_title']); ?></option>
        
          
          
      <?php $__currentLoopData = $titleArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
          
          
        <option  value="<?php echo e($title); ?>"
      <?php if(old('user_title') == $title): ?>
      selected="selected" <?php endif; ?>> <?php echo e($title); ?> </option>
        
          
          
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        
        
      </select>
      <div class="alert-message alert-warning"><?php echo e($errors->first('user_title')); ?></div>
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="firstname"> <?php echo e($transLanguage['edit_first_name']); ?>: </label>
    <div class=" col-sm-7">
      <input id="firstname" name="firstname" type="text" placeholder="<?php echo e($transLanguage['edit_first_name']); ?>"
    class="form-control input-md" pattern="[^0-9]*"  required=""
    value="<?php echo e(old('firstname')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('firstname')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="lastname"> <?php echo e($transLanguage['edit_last_name']); ?>: </label>
    <div class=" col-sm-7">
      <input id="lastname" name="lastname" type="text" placeholder="<?php echo e($transLanguage['edit_last_name']); ?>"
    class="form-control input-md" pattern="[^0-9]*" required=""
    value="<?php echo e(old('lastname')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('lastname')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="email"> <?php echo e($transLanguage['edit_email']); ?>: </label>
    <div class=" col-sm-7">
      <input id="email" readonly name="email"  type="email" placeholder="<?php echo e($transLanguage['edit_email']); ?>"
  class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
  required value="<?php echo e($email); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('email')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
    <div class="form-group">
      <label class="col-sm-3 control-label" for="country_code"> <?php echo e($transLanguage['edit_country_code']); ?>: </label>
    <div class="col-sm-7">
      <div class="input-group">          
        <input id="countrys_code" type="hidden" value="<?php echo e(old('country_code')); ?>"> 
        <span class="input-group-addon" id="ccPlus">+</span>
        <span class="input-group-addon" id="ccdid" type="text" style="display:none"></span>
        <select required id="country_code" name="country_code" class="form-control country_code_common" required>
            <option value="">Country Code</option>            
            <?php if(isset($countryArray)): ?>
                <?php $__currentLoopData = $countryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryArrays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                    <option data-ccdid="<?php echo e($countryArrays->id); ?>" value="<?php echo e($countryArrays->countryId); ?>" 
                <?php if(old('country_code') == $countryArrays->countryId): ?> selected="selected" <?php endif; ?> >
                       <?php echo e($countryArrays->text); ?> - +<?php echo e($countryArrays->id); ?> 
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        <div class="alert-message alert-danger"><?php echo e($errors->first('country_code')); ?></div>
         </div>
        <?php if(isset($countryArray)): ?>
            <div id="countryCo"  data-field-id="<?php echo e(json_encode($countryArray)); ?>"></div>
        <?php endif; ?>
        <span class="profile_asterik">*</span></div>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="form-group">
      <label class="col-sm-3 control-label" for="phone"> <?php echo e($transLanguage['edit_phone']); ?>: </label>
    <div class="col-sm-7">
      <input id="phone" name="phone" pattern="^\D*(?:\d\D*){10}" type="tel"
    placeholder="<?php echo e($transLanguage['edit_phone']); ?>"
    class="form-control input-md" required=""
    value="<?php echo e(old('phone')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('phone')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div id="optional_data">
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address1"> <?php echo e($transLanguage['edit_address_1']); ?>: </label>
    <div class=" col-sm-7">
      <input id="address1" name="address1" type="text" placeholder="<?php echo e($transLanguage['edit_address_1']); ?>"
      class="form-control input-md"
      value="<?php echo e(old('address1')); ?>">
      <div class="alert-message alert-danger"><?php echo e($errors->first('address1')); ?></div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address2"> <?php echo e($transLanguage['edit_address_2']); ?>: </label>
    <div class=" col-sm-7">
      <input id="address2" name="address2" type="text" placeholder="<?php echo e($transLanguage['edit_address_2']); ?>"
      class="form-control input-md"
      value="<?php echo e(old('address2')); ?>">
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="address3"> <?php echo e($transLanguage['edit_address_3']); ?>: </label>
    <div class=" col-sm-7">
      <input id="address3" name="address3" type="text" placeholder="<?php echo e($transLanguage['edit_address_3']); ?>"
      class="form-control input-md"
      value="<?php echo e(old('address3')); ?>">
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="city"> <?php echo e($transLanguage['edit_city']); ?>: </label>
    <div class=" col-sm-7">
      <input id="city" name="city" type="text" placeholder="<?php echo e($transLanguage['edit_city']); ?>"
        class="form-control input-md" required="" pattern="[A-z ]+$"
        value="<?php echo e(old('city')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('city')); ?></div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="state"> <?php echo e($transLanguage['edit_state_province']); ?>: </label>
    <div class="col-sm-7">
      <input id="state" name="state" type="text" placeholder="<?php echo e($transLanguage['edit_state_province']); ?>"
        class="form-control input-md" required="" pattern="[A-z ]+$"
        value="<?php echo e(old('state')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('state')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="country"> <?php echo e($transLanguage['edit_country']); ?>: </label>
    <div class="col-sm-7">
      <select required id="country" name="country" class="form-control">
        <option value="">Select <?php echo e($transLanguage['edit_country']); ?></option>
        
            
            
          <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
            
            
        <option value="<?php echo e($country->country_code); ?>"
            <?php if((old('country')) == $country->country_code): ?>
        selected="selected"
        <?php endif; ?> >
        <?php echo e($country->country_name); ?> </option>
        
            
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          
          
      </select>
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('country')); ?></div>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="zip"> <?php echo e($transLanguage['edit_zip_postcode']); ?>: </label>
    <div class="col-sm-7">
      <input id="zip" name="zip" type="text" placeholder="<?php echo e($transLanguage['edit_zip_postcode']); ?>"
        class="form-control input-md" required="" style="text-transform:uppercase"
        value="<?php echo e(old('zip')); ?>">
      <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
      <div class="alert-message alert-danger"><?php echo e($errors->first('zip')); ?></div>
      <span class="profile_asterik">*</span> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Select Basic -->
  
  <div class="form-group">
    <label class="col-sm-3 control-label" for="user_title"> <?php echo e($transLanguage['edit_date_format']); ?>: </label>
    <div class=" col-sm-7">
      <select id="date_format" name="date_format" class="form-control" >
        
          
          
              <?php $__currentLoopData = $dateArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
          
          
        <option  value="<?php echo e($key); ?>"
              <?php if((old('date_format')) == $key): ?>
              selected="selected" <?php endif; ?>> <?php echo e($date); ?> </option>
        
          
          
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        
        
      </select>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Text input-->
  <div class="form-group">
    <label class="col-sm-3 control-label" for="dob"> <?php echo e($transLanguage['edit_date_of_birth']); ?>: </label>
    <div class=" col-sm-7">
      <div class="input-group date" id="date_of_birth">
        <input id="dob" name="dob" type="text" placeholder=" <?php echo e($transLanguage['edit_date_of_birth']); ?>"
          class="form-control input-md" required
          value="">
        <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span>
        <div class="alert-message alert-danger"><?php echo e($errors->first('dob')); ?></div>
         </div><span class="profile_asterik">*</span>
    </div>
  </div>
  <div class="hr-line-dashed"></div>
  <div class="form-group">
    <label class="col-sm-3 control-label" for="agree"></label>
    <div class=" col-sm-7 terms_policy">
      <input required type="checkbox" name="agree" id="agreecheckbox" value="agree" class="switch js-switch_1" />
      I have read and agree to the <a target="_blank" href="https://www.uberid.com/terms-of-service">Terms of Service</a> and <a target="_blank" href="https://www.uberid.com/privacy-policy">Privacy Policy</a> </div>
  </div>
  <div class="hr-line-dashed"></div>
  <!-- Button -->
  <div class="form-group">
    <div class=" col-xs-12 text-center">
  <div class="loader2"></div>
  </div></div>
  <div class="form-group">
    <div class=" col-xs-12 text-center">
      <input class="btn btn-primary" type="button" id="regFormBack" value="Back">
      <button id="profile_submit" name="profile_submit"
          class="btn btn-primary"> <?php echo e($transLanguage['edit_submit']); ?> </button>
      <input class="btn btn-primary" type="reset" id="reset" value="<?php echo e($transLanguage['edit_reset']); ?>">
    </div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
  </div>
  <!--   -->
  <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
  <input type="hidden" id="tagno" name="tagno" value="<?php echo e($tagno); ?>">
  <input type="hidden" id="lastTInsertIdT" name="lastTInsertIdT" value="<?php echo e($lastTInsertIdT); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>  
    ##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac## 
    <link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 

<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap-datetimepicker.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/profile.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/select2/select2.full.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/countryCode.js"></script> 
<script type="text/javascript">
   $("#profile_submit").prop('disabled',false);
  $('#agreecheckbox').change(function(){

    if($(this).prop("checked") == true){
      
      $("#profile_submit").removeClass('disabled');
      $("#profile_submit").prop('disabled',false);
    }
    else if($(this).prop("checked") == false){

      // $("#profile_submit").addClass('disabled');
      $("#profile_submit").prop('disabled',true);

    }
  });
  $("#reset").click(function(){

    var haserrclass = $( ".form-group" ).hasClass( "has-error" );
    var hassucclass = $( ".form-group" ).hasClass( "has-success" );
    
    if(haserrclass){
      $( ".form-group" ).removeClass( "has-error" );   
    }
    if(hassucclass){
      $( ".form-group" ).removeClass( "has-success" );   
    }

    var spanerr = $( ".glyphicon" ).hasClass( "glyphicon-remove" );
    var spanscc = $( ".glyphicon" ).hasClass( "glyphicon-ok" );

    if(spanerr){
     $( ".glyphicon" ).removeClass( "glyphicon-remove" );  
   }
   if(spanscc){
     $( ".glyphicon" ).removeClass( "glyphicon-ok" );  
   }
   
    $("#profile_submit").addClass('disabled');
  });
</script> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>