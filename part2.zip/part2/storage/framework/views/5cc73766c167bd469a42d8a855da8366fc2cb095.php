        <center>
        <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable">
        <tr>
        <td align="center" valign="top" id="bodyCell">
        <!-- BEGIN TEMPLATE // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateContainer">                            
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN HEADER // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateHeader">
        <tr>
        <td valign="top" class="headerContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnImageBlock">
        <tbody class="mcnImageBlockOuter">
        <tr>
        <td valign="top" style="padding:9px" class="mcnImageBlockInner">
        <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="mcnImageContentContainer">
        <tbody><tr>
        <td class="mcnImageContent" valign="top" style="padding-right: 9px; padding-left: 9px; padding-top: 0; padding-bottom: 0; text-align:center;">


        <img align="left" alt="" src="<?php echo e(url('/') .'/assets/images/logo.png'); ?>" width="300" style="max-width:300px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage">


        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END HEADER -->
        </td>
        </tr>
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN BODY // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateBody">
        <tr>
        <td valign="top" class="bodyContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock">
        <tbody class="mcnTextBlockOuter">
        <tr>
        <td valign="top" class="mcnTextBlockInner">

        <table align="left" border="0" cellpadding="0" cellspacing="0" width="600" class="mcnTextContentContainer">
        <tbody><tr>

        <td valign="top" class="mcnTextContent" style="padding-top:9px; padding-right: 18px; padding-bottom: 9px; padding-left: 18px;"><p id='templateContentStarts'><p>   </p>

<h1>User Reported Product Lost</h1>

<p><br />
    <?php if(!empty($data['userFirstName']) && !empty($data['userFirstName'])): ?>
   </p>

<p><br />
    <?php echo e($data['userFirstName']); ?> <?php echo e($data['userLastName']); ?> reported lost product<br />
   <br /><br />

    <?php endif; ?>
    <?php if(!empty($data['id'])): ?>
    User ID: <?php echo e($data['id']); ?>

   <br /><br />

    <?php endif; ?>
    <?php if(!empty($data['userproductName'])): ?>
    Product Type: <?php echo e($data['userproductName']); ?>

   <br /><br />

    <?php endif; ?>
    <?php if(!empty($data['userEmail'])): ?>
    Email: <?php echo e($data['userEmail']); ?>

   </p>

<p><br /><br />
    <?php endif; ?></p>

</p><p id='templateContentEnds'></p>        Sincerely,<br>
        The UBERID Support Team</p>

        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END BODY -->
        </td>
        </tr>
        <tr>
        <td align="center" valign="top">
        <!-- BEGIN FOOTER // -->
        <table border="0" cellpadding="0" cellspacing="0" width="600" id="templateFooter">
        <tr>
        <td valign="top" class="footerContainer" style="padding-bottom:9px;"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock">
        <tbody class="mcnTextBlockOuter">
        <tr>
        <td valign="top" class="mcnTextBlockInner">

        <table align="left" border="0" cellpadding="0" cellspacing="0" width="600" class="mcnTextContentContainer">
        <tbody><tr>

        <td valign="top" class="mcnTextContent" style="padding: 9px 18px;color: #000000;">

        <em>&#169; 2015-2016 UberID, LLC All Rights Reserved. </em>
        <em style="float: right;"> Powered by UberID Build [1.0]</em><br><br>

        &nbsp;
        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowBlock">
        <tbody class="mcnFollowBlockOuter">
        <tr>
        <td align="center" valign="top" style="padding:9px" class="mcnFollowBlockInner">
        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowContentContainer">
        <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnFollowContent">
        <tbody><tr>
        <td align="center" valign="top" style="text-align:left;">
        <table border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
        <td valign="top">

        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>

        </td>
        </tr>
        </tbody>
        </table></td>
        </tr>
        </table>
        <!-- // END FOOTER -->
        </td>

        </tr>
        </table>
        <!-- // END TEMPLATE -->
        </td>
        </tr>
        </table>
        </center>