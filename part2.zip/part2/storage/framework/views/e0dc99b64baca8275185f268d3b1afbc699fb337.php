<?php $__env->startSection('title', 'FT Users by Country'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FT Users by Country</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <input type="hidden" name="reportid" id="reportid" value="<?php echo e(userIdEncode(2)); ?>">
    <div id="regions_div"></div>
    <div class="tableContentBox">
        <div id="containerFT" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
    </div>
  </div>
</div>
<input type="hidden" id="search" value="<?php echo e($translatedLang['dashboard_search']); ?>">
<input type="hidden" id="next" value="<?php echo e($translatedLang['dashboard_next']); ?>">
<input type="hidden" id="first" value="<?php echo e($translatedLang['dashboard_first']); ?>">
<input type="hidden" id="last" value="<?php echo e($translatedLang['dashboard_last']); ?>">
<input type="hidden" id="previous" value="<?php echo e($translatedLang['dashboard_previous']); ?>">
<input type="hidden" id="record_per_page" value="<?php echo e($translatedLang['dashboard_record_per_page']); ?>">
<input type="hidden" id="display" value="<?php echo e($translatedLang['dashboard_display']); ?>">
<input type="hidden" id="dashboard_of" value="<?php echo e($translatedLang['dashboard_of']); ?>">
<input type="hidden" id="showing_page" value="<?php echo e($translatedLang['dashboard_showing_page']); ?>">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<input type="hidden" id="filtercolumnvalue" value="4">
<input type="hidden" id="datatableidvalue" value="users-table">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('admin/reports/'.$report); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.maplayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>