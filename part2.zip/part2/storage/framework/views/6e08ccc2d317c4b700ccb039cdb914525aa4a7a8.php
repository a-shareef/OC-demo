<?php $__env->startSection('title', 'List of Roles'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<?php if(session('error')): ?>
	<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
		<div>
			<?php echo e(session('error')); ?>

		</div>
	</div>
	<?php endif; ?>
	<?php if(session('success')): ?>
	<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
		<div>
			<?php echo e(session('success')); ?>

		</div>
	</div>
	<?php endif; ?>
</div>
<div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5>List of Videos</h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
<div class="list_of_videos">

<?php $__currentLoopData = $listOfVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<ul class="metismenu videoList" id="side-menu">
                <li><a href="/videoplayer?page=<?php echo e($key+1); ?>"><i class="fa fa-video-camera" aria-hidden="true"></i> <span><?php echo e($value->title); ?></span></a></li>
                </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/listofvideos/'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>