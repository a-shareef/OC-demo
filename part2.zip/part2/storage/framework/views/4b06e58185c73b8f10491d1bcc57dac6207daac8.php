<?php $__env->startSection('title', 'List of Roles'); ?>
<?php $__env->startSection('content'); ?>
<div class="container"> <?php if(session('error')): ?>
  <div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div> <?php echo e(session('error')); ?> </div>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div> <?php echo e(session('success')); ?> </div>
  </div>
  <?php endif; ?> </div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="list_of_videos_inner">
      <div class="row">
        <div class="col-xl-6 col-xl-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1">
          <div class="embed-responsive embed-responsive-16by9"> <?php echo $videoPlayer[0]->vimeo_code; ?> </div>
        </div>
      </div>
    </div>
    <div class="list_of_videos_inner links">
      <div class="row">
        <div class="col-xl-6 col-xl-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1">
          <div class="btn-group btn-group-input"> <?php if($videoPlayer->previousPageUrl()): ?> <a href="<?php echo e($videoPlayer->previousPageUrl()); ?>" class="btn btn-primary btn-next"><i class="fa fa-chevron-left"></i>Previous Video</a> <?php endif; ?> <a class="btn btn-white"  href="/trainingvideos">Main Menu</a> <?php if($videoPlayer->nextPageUrl()): ?> <a href="<?php echo e($videoPlayer->nextPageUrl()); ?>" class="btn btn-primary btn-pre">Next Video <i class="fa fa-chevron-right"></i></a> <?php endif; ?> </div>
        </div>
      </div>
      <div class="list_of_videos_inner in_this_video">
        <div class="row">
          <div class="col-xl-6 col-xl-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1">
            <h2><strong>In this video</strong></h2>
            <ul class="todo-list m-t ui-sortable">
              <li> <img src="assets/images/checkbox-check.jpg"> <?php echo e($videoPlayer[0]->in_this_video_1); ?> </li>
              <li> <img src="assets/images/checkbox-check.jpg"> <?php echo e($videoPlayer[0]->in_this_video_2); ?> </li>
              <li> <img src="assets/images/checkbox-check.jpg"> <?php echo e($videoPlayer[0]->in_this_video_3); ?> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('videoplayer/',$videoPlayer[0]->title); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>