<?php $__env->startSection('title', 'Manage FT Products'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> <?php echo e(session('error')); ?> </div>
</div>
<?php endif; ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Manage FT Products</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="row"> <?php if(hasrole() == 1): ?>
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="ft_orders" name="ft_orders" class="form-control" >
          <option value="">Select Order</option>
            <?php $__currentLoopData = $ordersArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($order->id); ?>" <?php if($orderId == $order->order_no): ?> selected="selected" <?php endif; ?>> 
          <?php echo e($order->order_no); ?> </option>
                       
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        </select>
      </div>
      <?php endif; ?>
      <div class="form-group col-md-3 col-sm-5 col-xs-5 wth100per">
        <select required id="ft_company" name="ft_company" class="form-control" >
          <option value="">Select Company</option>

            <?php $__currentLoopData = $companyArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
          <option value="<?php echo e($company->id); ?>"> <?php echo e($company->company_name); ?></option>
     
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        </select>
      </div>
    </div>
    <div class="form-inline dt-bootstrap">
      <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer responsive productDataTable" cellspacing="0" width="100%" id="mftprod-table">
        <thead>
          <tr>
            <th data-priority="1">Tag #</th>
            <th>Product</th>
            <th>Description</th>
            <?php if(hasrole() == 1): ?>
            <th>Product Status</th>
            <?php endif; ?>
            <?php if(hasrole() == 4): ?>
            <th>Registration Status</th>
            <?php endif; ?>
            <th>Last Updated On</th>
            <th data-priority="2">Action</th>
            <?php if(hasrole() == 1): ?>
            <th >Order No</th>
            <th> Company</th>
            <?php endif; ?> </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<input type="hidden" id="orderId" value="<?php echo e($orderId); ?>">
<input type="hidden" id="search" value="Search">
<input type="hidden" id="next" value="Next">
<input type="hidden" id="first" value="First">
<input type="hidden" id="last" value="Last">
<input type="hidden" id="previous" value="Previous">
<input type="hidden" id="record_per_page" value="Records Per Page">
<input type="hidden" id="display" value="Display">
<input type="hidden" id="dashboard_of" value="of">
<input type="hidden" id="showing_page" value="Showing page">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<input type="hidden" id="hasrole" value="<?php echo e(hasrole()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/manageproduct'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>