   
   <?php $__env->startSection('style'); ?>
   ##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac##
    <link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
    <link href="<?php echo e(url('/')); ?>/assets/css/common.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/bootstrap/css/Jcrop.css">
    <link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min.css" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/manage_language.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/admin_product.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/user_language.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/admin_language.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/manage_product.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/select2.min.js"></script> 

<script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/bootstrap/js/Jcrop.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/js/piexif.js"></script>
<script type="text/javascript">


  $('form').submit(function() {
  $(":submit").attr("disabled", true);
});
  $( ":input" ).focus(function() {
      $(":submit").attr("disabled", false);
  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>