<?php $__env->startSection('body'); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/')); ?>/assets/js/map/jquery-3.1.1.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/map/highmaps.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/map/data.js"></script>    
<script src="<?php echo e(url('/')); ?>/assets/js/map/world.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/map/mapchart.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/metisMenu/jquery.metisMenu.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>