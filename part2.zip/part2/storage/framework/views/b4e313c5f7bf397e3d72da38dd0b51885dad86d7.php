<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('style'); ?>
<link href="/assets/bootstrap/css/bootstrap-tagsinput.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('status')); ?> </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span>
  <div></div>
</div>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Reports</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <div class="ibox-content">
    <div class="panel-group report-accordion" id="accordion">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">Audit Reports<i class="fa fa-plus pull-right"></i></a> </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
          <div class="panel-body">
            <ul class="report-list no-margins metismenu videoList">
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/loginhistory/<?php echo e(userIdEncode(3)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Login History</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/membersaudit/<?php echo e(userIdEncode(2)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FT Users Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/productregistrations/<?php echo e(userIdEncode(4)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Product Registration Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/userregistrations/<?php echo e(userIdEncode(5)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>User Registration Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/usregisteredproducts/<?php echo e(userIdEncode(9)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Incomplete Registrations Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/pendingproductsactivation/<?php echo e(userIdEncode(10)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Pending Product Activation Report</span></a></li>
               <li><a href="<?php echo e(url('/')); ?>/admin/reports/productstatusreport/<?php echo e(userIdEncode(19)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Product Status Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/foundproductsreport/<?php echo e(userIdEncode(20)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Found Products Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/lostproductsreport/<?php echo e(userIdEncode(21)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Lost Products Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/suspendedproductsreport/<?php echo e(userIdEncode(22)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Suspended Products Report</span></a></li>
               <li><a href="<?php echo e(url('/')); ?>/admin/reports/lostfoundproductsreport/<?php echo e(userIdEncode(23)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>All Lost Found Products Report</span></a></li>
                <li><a href="<?php echo e(url('/')); ?>/admin/reports/orderedproductsreport/<?php echo e(userIdEncode(24)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Order Status Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/orderedproductsreport/<?php echo e(userIdEncode(25)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Unregistered Products Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/reactivatedproductsreport/<?php echo e(userIdEncode(26)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Reactivated Products Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/registrationattemptsreport/<?php echo e(userIdEncode(27)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Registration Attempts Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/tagtransferreport/<?php echo e(userIdEncode(28)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>  All Tag Transfers Report</span></a></li>


            </ul>
          </div>
        </div>
      </div>
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed">Graphical Reports<i class="fa fa-plus pull-right"></i></a> </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
          <div class="panel-body">
            <ul class="report-list no-margins metismenu videoList">
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/countrywiseusersmap/<?php echo e(userIdEncode(8)); ?>" ><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FT Users by Country</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/ftunits/<?php echo e(userIdEncode(11)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FoundThem All Products Over Time</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/ftordercount/<?php echo e(userIdEncode(12)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>FoundThem Tag Products by Customer/Order Number</span></a></li>
<!--              <li><a href="<?php echo e(url('/')); ?>/admin/reports/ftordernouid/<?php echo e(userIdEncode(13)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Attempted Registrations Report</span></a></li>-->
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/csmainchart/<?php echo e(userIdEncode(14)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Current FT Status Report</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/registrationcomp/<?php echo e(userIdEncode(15)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Attempted Registrations Report</span></a></li>
<!--              <li><a href="<?php echo e(url('/')); ?>/admin/reports/today/<?php echo e(userIdEncode(16)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Today</span></a></li>
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/registrationhistoryc/<?php echo e(userIdEncode(17)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Registration History</span></a></li>-->
              <li><a href="<?php echo e(url('/')); ?>/admin/reports/registrationhistoryl/<?php echo e(userIdEncode(18)); ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Customer Service Agent Registrations vs Order Report</span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<input type="hidden" id="hdd_chk_non" value="false">
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
<input type="hidden" id="userId">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap-tagsinput.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/reports.js"></script> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/reports'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.reports', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>