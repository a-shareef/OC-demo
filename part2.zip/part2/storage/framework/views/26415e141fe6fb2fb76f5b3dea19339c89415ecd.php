<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8"/>
<title>UberID FT - <?php echo $__env->yieldContent('title'); ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<meta content="" name="description"/>
<meta content="" name="author"/>
<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">
<link rel="shortcut icon" type="image/png" href="/assets/images/UberID-Favicon.png"/>
<?php if(getLtrRtl() == 1): ?>
<link rel="shortcut icon" type="image/png" href="<?php echo e(url('/')); ?>/assets/images/UberID-Favicon.png"/>
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/style.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/footable.core.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/style.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/responsive.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
<?php else: ?>
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap_rtl.min.css" rel="stylesheet" id="bootstrap-css">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/style_rtl.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/footable.core.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min_rtl.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/style_rtl.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/responsive_rtl.css" rel="stylesheet">
<?php endif; ?>
      <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="fixed-nav fixed-sidebar pace-done login">
<div id="wrapper" class="">
  <div id="page-wrapper" class="page-wrapper2">
    <div class="row">
      <nav class="navbar white-bg navbar-fixed-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header"> <a class="logo" href="<?php echo e(url('/')); ?>" ><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a>
          <div class="slogan"><?php echo e(siteSlogan()); ?></div>
        </div>
        <?php $currentRoutes = Route::currentRouteName();?>
        <?php if($currentRoutes == 'finderfront'): ?>
        <ul class="nav navbar-top-links navbar-right">
          <li>
            <form id="languageForm" method=<?php if(getAuthData()): ?> "POST" <?php else: ?> "GET" <?php endif; ?>
              action=<?php if(getAuthData()): ?> "/user/language-change" <?php else: ?> "/frontUser/language-change" <?php endif; ?>>
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 input-group">
                <select onchange="langChange()" id="language" name="language" class="select2_demo_1 form-control" required >
                  
                  
                
                    <?php $__currentLoopData = getLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                
                  
                  <option value="<?php echo e($lang->language_id); ?>"
                        <?php if(getAuthenticateUserLanguage() == $lang->language_id): ?>
                  selected="selected" <?php endif; ?> >
                  <?php echo e($lang->language_name); ?> </option>
                  
                  
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              
                
                </select>
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('language')); ?></div>
              </div>
            </div>
            </form>                        
          </li>
        </ul>
        <?php endif; ?> </nav>
    </div>
      <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight"><?php echo $__env->yieldContent('content'); ?></div>
      <div class="footer">
        <p class="col-xs-7 text-left"> &#169; <?php echo e(date('Y')); ?> UberID, LLC. All Rights Reserved. </p>
        <p class="col-xs-5 text-right"> Powered by UberID. (Build 1.1.5.7)‎&#x200E; </p>
      </div>
    </div>
  </div>
</body>
<footer>
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery-1.10.2.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/GoogleAnalytics.js"></script>
  <script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/bootstrap/js/Jcrop.min.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/metisMenu/jquery.metisMenu.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/slimscroll/jquery.slimscroll.min.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/iCheck/icheck.min.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/switchery/switchery.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/dataTables/datatables.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/select2/select2.full.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/inspinia.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/pace/pace.min.js"></script> 
  <?php if(empty(session('locationData'))): ?>
  <script src="<?php echo e(url('/')); ?>/assets/js/geolocation.js"></script>
  <?php endif; ?>
  <script type="text/javascript">
function langChange(){
   $( "#languageForm" ).submit();
}

</script>

<script>
            $(document).ready(function () {
            $(".select2_demo_1").select2();
            });
			
        </script>
  <?php echo $__env->yieldContent('script'); ?></footer>
</html>
