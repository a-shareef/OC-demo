   
   <?php $__env->startSection('style'); ?>
    <link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
    
    <link href="<?php echo e(url('/')); ?>/assets/css/common_rtl.css" rel="stylesheet">
 
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
  <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/manage_tagno.js"></script>
 
 <script type="text/javascript">
 $(".alert").delay(10000).fadeOut();
 $(".alert-message").delay(10000).fadeOut();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>