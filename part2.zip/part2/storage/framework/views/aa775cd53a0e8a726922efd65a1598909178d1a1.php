<!-- resources/views/auth/login.blade.php -->


<?php $__env->startSection('title', 'FT-Finder'); ?>
<?php $__env->startSection('style'); ?>  
    ##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac## 
    <link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('alert-success')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('alert-success')); ?> </div>
<?php endif; ?> 
<?php if(session('alert-error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('alert-error')); ?> </div>
<?php endif; ?>
<div class="row">
  <div class="col-md-6 col-sm-8 col-sm-offset-2 col-md-offset-3">
    <div class="">
      <div class="ibox float-e-margins">        
        <div class="ibox-content">
          <div class="panel-body">
            <div class="row text-justify">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12"><span><?php echo e($getTranslatedLang['finder_found_them']); ?></span></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <form data-toggle="validator" method="POST" action="<?php echo e(url('/')); ?>/finder/add" method="post" id="form" role="form" style="display: block;" class="form-horizontal">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12"><b><?php echo e($getTranslatedLang['finder_enter_tagid']); ?> :</b></div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12" id="tagnoerror">
                <input id="tagno" name="tagno" type="text" class="form-control input-md" pattern="^([A-Za-z]{1,2}[0-9]{6,7})"  required="" value="<?php echo e(old('tagno')); ?>" placeholder="<?php echo e($getTranslatedLang['finder_tag_no']); ?>" onblur="return check_availability()">
                <span class="glyphicon form-control-feedback" id="glyphicon" aria-hidden="true"></span>
                <div class="alert-message alert-danger" id="tagno_availability_result"><?php echo e($errors->first('tagno')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                <input id="firstname" name="firstname" type="text" class="form-control input-md"  pattern="[^0-9]*"  required="" value="<?php echo e(old('firstname')); ?>" placeholder="<?php echo e($getTranslatedLang['finder_first_name']); ?>">
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('firstname')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                <input id="lastname" name="lastname" type="text" class="form-control input-md"  pattern="[^0-9]*"  required="" value="<?php echo e(old('lastname')); ?>" placeholder="<?php echo e($getTranslatedLang['finder_last_name']); ?>">
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('lastname')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
                <div class="input-group">
                   <input id="countrysf_code" type="hidden" value="<?php echo e(old('countrycode')); ?>"> 
                   <span class="input-group-addon" id="ccPlus">+</span>
                   <span class="input-group-addon" id="ccdid" type="text" style="display:none"></span>
                  <select required id="countrycode" name="countrycode" class="form-control country_code_common" required>
                    <option value=""><?php echo e($getTranslatedLang['finder_cc']); ?></option>            
                    <?php if(isset($countryArray)): ?>
                        <?php $__currentLoopData = $countryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryArrays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <option data-ccdid="<?php echo e($countryArrays->id); ?>" value="<?php echo e($countryArrays->countryId); ?>" 
                        <?php if(old('countrycode') == $countryArrays->countryId): ?> selected="selected" <?php endif; ?> >
                               <?php echo e($countryArrays->text); ?> - +<?php echo e($countryArrays->id); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                </div>
                <?php if(isset($countryArray)): ?>
                    <div id="countryCof"  data-field-id="<?php echo e(json_encode($countryArray)); ?>"></div>
                <?php endif; ?>
              </div>
            <div class="row hidden-lg hidden-md"><div class="col-xs-12"><div class="hr-line-dashed"></div></div></div>
              <div class="col-md-8 col-sm-12 col-xs-12 col-lg-8">
                <input id="phone" name="phone" type="text" class="form-control input-md" pattern="^\D*(?:\d\D*){10}"  value="<?php echo e(old('phone')); ?>" placeholder="<?php echo e($getTranslatedLang['finder_mobile']); ?>">
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                <input id="email" name="email" type="email" placeholder="<?php echo e($getTranslatedLang['finder_email']); ?>"
          class="form-control input-md" pattern="^[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
          required value="<?php echo e(old('email')); ?>">
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('email')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group ">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                <textarea id="remarks" name="remarks" placeholder="<?php echo e($getTranslatedLang['finder_remarks']); ?>"
          class="form-control input-md" required value=""><?php echo e(old('remarks')); ?></textarea>
                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('remarks')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
              <?php echo LaravelCaptcha\Facades\Captcha::html(); ?> <br /><br />
              <input type="text" id="captcha" name="captcha" placeholder="Captcha" class="form-control input-md">
               <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                <div class="alert-message alert-danger"><?php echo e($errors->first('captcha')); ?></div>
              </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 col-sx-12 text-center">
                <button id="finder_submit" name="finder_submit" class="btn btn-primary" type="submit"><?php echo e($getTranslatedLang['finder_submit']); ?></button>
              </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/')); ?>/assets/js/countryCode.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/manage_tagno.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/select2/select2.full.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.finder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>