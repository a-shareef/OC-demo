<?php $__env->startSection('title', 'Product Suspend'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
    <div>
        <?php echo e(session('status')); ?>

    </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
    <div>
        <?php echo e(session('error')); ?>

    </div>
</div>
<?php endif; ?>

<div class="alert alert-success hide"><span class="glyphicon glyphicon-ok-sign"></span><div></div></div>
<form name="productsuspend" class="form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(route('productsuspendadd')); ?>">
<?php echo csrf_field(); ?>

<!-- Form Name -->
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Product Suspend Information</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div><div class="ibox-content">
<fieldset class="formFiled">
<input type="hidden" value="<?php echo e($loggedinuserid); ?>" name="loggedinuserid" />
<input type="hidden" value="<?php echo e($currentproductid); ?> " name="currentproductid" />
<input type="hidden" value="<?php echo e($ip); ?>" name="ip" />


<!-- Product Details From -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="product">
   Product Name:
  </label>
  <div class="col-sm-7">
  <input id="productname" name="productname" type="text"  class="form-control input-md" disabled="disabled" value=" <?php echo e($current_productname); ?> (<?php echo e($current_productsequence); ?>)">
 
  </div>
</div>
 <div class="hr-line-dashed"></div>
<!-- Textarea -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="remarks">
   Reason:
  </label>
  <div class="col-sm-7">
    <textarea class="form-control" id="remarks" name="remarks" required value=""></textarea>
  </div>
</div>

        <!-- Button -->
<div class="form-group">
  <label class="col-sm-3 control-label" for="cancel"></label>
  <div class="col-sm-7">
  <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Report Suspend') == true)): ?>
    <input type="submit"  name="Submit" value="Submit" id="productsuspend_submit" name="productsuspend_submit" class="btn btn-primary"/>
  <?php endif; ?>  
    <input class="btn btn-secondary" type="reset" value="Reset">
</div>
    <div class="col-md-4 col-sm-4 col-xs-4 input-group">

  </div>
  </div>

</fieldset>
</form>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/product/productsuspend/{product_id}'); ?>

<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>