<!DOCTYPE html>
<html>
<head>
<title>Page Not Found.</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<link rel="shortcut icon" type="image/png" href="/assets/images/UberID-Favicon.png">
<link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="/assets/bootstrap/css/style.css" rel="stylesheet">
<link href="/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="/assets/css/footable.core.css" rel="stylesheet">
<link href="/assets/css/select2/select2.min.css" rel="stylesheet">
<link href="/assets/css/style.css" rel="stylesheet">
<link href="/assets/css/responsive.css" rel="stylesheet">
</head>
<body class="errorPage">
<div class="mainBox">
  <?php
$getTranslatedLang = languageTranslate("Page Not Found");
?>
  <div id="page-wrapper" class="gray-bg page-wrapper2 page-wrapper3">
    <div class="row">
      <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header"> <a class="logo"><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a></div>
        <ul class="nav navbar-top-links navbar-right">
          <li></li>
        </ul>
      </nav>
    </div>
    <div id="wrapper">
      <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight wrapper2-content">
        <div class="container">
          <div class="jumbotron float-e-margins text-center page404">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <h1><?php echo e($getTranslatedLang['page_not_found_sorry']); ?></h1>
                <p><?php echo e($getTranslatedLang['page_not_found_hate']); ?></p>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="http://www.uberid.com/" class="pull-right btn btn-primary"><?php echo e($getTranslatedLang['page_not_found_public_site']); ?></a> </div>
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="<?php echo e(url('/')); ?>" class="pull-left btn btn-primary"><?php echo e($getTranslatedLang['page_not_found_uberid_pip']); ?></a> </div>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <p class="text-align-center"><?php echo e($getTranslatedLang['page_not_found_appreciate']); ?>&nbsp;&nbsp;</p>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12"><a target="_blank" href="http://www.uberid.com/pages/customerservice" class="btn btn-primary"> <?php echo e($getTranslatedLang['page_not_found_tell_us_more']); ?></a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<script src="/assets/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/bootstrap/js/Jcrop.min.js"></script>
<script src="/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/metisMenu/jquery.metisMenu.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/slimscroll/jquery.slimscroll.min.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/iCheck/icheck.min.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/switchery/switchery.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/select2/select2.full.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/inspinia.js"></script> 
  <script src="<?php echo e(url('/')); ?>/assets/js/pace/pace.min.js"></script> 
<script type="text/javascript">
function langChange(){
   $( "#languageForm" ).submit();
}

            $(document).ready(function () {
            $(".select2_demo_1").select2();
            });
</script>
</html>
