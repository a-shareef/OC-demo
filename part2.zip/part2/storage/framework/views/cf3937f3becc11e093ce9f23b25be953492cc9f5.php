<!-- resources/views/user/profile.blade.php -->


<?php $__env->startSection('style'); ?>
##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac##
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/css/select2.min.css" rel="stylesheet" />
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/typeahead.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Add Order'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('status')); ?> </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<form  id="profileForm"  class="form-horizontal formFiled" data-toggle="validator" method="POST" action="<?php if(isset($orderData[0]->product_initials)): ?><?php echo e(route('order_update')); ?><?php else: ?><?php echo e(route('orders')); ?><?php endif; ?>" role="form" style="display: block;">
  <div class="ibox float-e-margins">
    <div class="ibox-title"> <?php echo csrf_field(); ?>

      <?php if(isset($orderData[0])): ?>
      <h5>Edit Order </h5>
      <?php else: ?>
      <h5>Add Order </h5>
      <?php endif; ?>
      
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
    <?php if(isset($orderData[0]->product_initials)): ?><fieldset disabled><?php endif; ?>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product"> Product: </label>
        <div class="col-sm-7">
          <select required id="product" name="product" class="form-control" >
            <option value="">Select  Product</option>
               
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            
            <option  value="<?php echo e($product->product_initials); ?>"
                  <?php if(isset($orderData) && $orderData[0]->product_initials == $product->product_initials): ?>
            selected
            <?php endif; ?>
            >
            <?php echo e($product->product_name); ?> </option>
            
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          
          </select>
          <div class="alert-message alert-warning"><?php echo e($errors->first('product')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="company"> Company: </label>
        <div class="col-sm-7">
          <input id="company" required name="company" type="text" placeholder="Company"
          class="form-control input-md"
          value="<?php if(isset($orderData[0]->company_name)): ?> <?php echo e($orderData[0]->company_name); ?> <?php endif; ?>">
          <div class="alert-message alert-warning"><?php echo e($errors->first('company')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      
      <!-- Textarea -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea"> Description: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description"
        name="product_description"><?php if(isset($orderData[0]->description)): ?><?php echo e($orderData[0]->description); ?><?php endif; ?></textarea>
        </div>
      </div>
      <!-- Text input-->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="quantity"> Qty: </label>
        <div class="col-sm-7">
          <input id="quantity" required name="quantity" maxlength="3" type="text" pattern="\d{1,3}" placeholder="Qty"
          class="form-control input-md"
          value="<?php if(isset($orderData[0]->quantity)): ?><?php echo e($orderData[0]->quantity); ?><?php endif; ?>">
          <div class="alert-message alert-warning"><?php echo e($errors->first('quantity')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <!-- Text input-->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="order_no"> Order No: </label>
        <div class="col-sm-7">
          <input id="order_no" required name="order_no" type="text" placeholder="Order No"
          class="form-control input-md"
          value="<?php if(isset($orderData[0]->order_no)): ?> <?php echo e($orderData[0]->order_no); ?> <?php endif; ?>">
          <div class="alert-message alert-warning"><?php echo e($errors->first('order_no')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
   <?php if(isset($orderData[0])): ?></fieldset><?php endif; ?>
      <?php if(isset($orderData[0]->order_status)): ?>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="order_status"> Order status: </label>
        <div class="col-sm-7">
          <select required id="order_status" name="order_status" class="form-control" >
            <option value="">Select  Status</option>
            
              <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option  value="<?php echo e($key); ?>"
                  <?php if($orderData[0]->order_status == $key): ?>
            selected
            <?php endif; ?>>
            <?php echo e($status); ?> </option>
            
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </select>
          <div class="alert-message alert-warning"><?php echo e($errors->first('product')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <input type="hidden" value="<?php echo e($orderData[0]->order_id); ?>" name="order_id" />
      <?php endif; ?> 
      
      <!-- Button -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label"></label>
        <div class="col-sm-7">
                 <button id="profile_submit" name="profile_submit"
            class="btn btn-primary"><?php if(isset($orderData[0]->order_no)): ?> Update <?php else: ?> Submit <?php endif; ?></button>
          <?php if(isset($orderData[0]->order_no)): ?> <a id="edit-cancel-button" name="button2id" class="btn  btn-primary" href="<?php echo e(url('/')); ?>">Cancel</a> <?php else: ?>
          <input  class="btn reset  btn-primary" type="reset" value="Reset">
          <a id="edit-cancel-button" name="button2id" class="btn  btn-primary" href="<?php echo e(url('/')); ?>">Cancel</a> <?php endif; ?> </div>
      </div>
    </div>
  </div>
</form>
<?php if(isset($company)): ?>
<div id="pre"  data-field-id="<?php echo e($company); ?>"></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/js/select2.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/typeahead.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/js/orders.js"></script> 
<?php $__env->stopSection(); ?>
<?php $currentRoutes = Route::currentRouteName();?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php if($currentRoutes == 'order'): ?>
    <?php echo Breadcrumbs::render('admin/order/add'); ?>

<?php endif; ?>
 <?php if($currentRoutes == 'edit_order'): ?>
      <?php echo Breadcrumbs::render('admin/order/edit/{order_id}'); ?>

  <?php endif; ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>