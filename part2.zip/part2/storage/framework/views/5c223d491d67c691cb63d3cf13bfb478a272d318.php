<?php $__env->startSection('title', 'Edit Products'); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $getProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5><?php echo e($getTranslatedLang['manage_id_products_heading_edit_product']); ?></h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <form id="form-update-product"  class="form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(url('/')); ?>/admin/product/edit/<?php echo e($product->id); ?>" role="form">
    <!-- Form Name --> 
    <?php echo csrf_field(); ?> 
    <!-- Text input-->
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textinput"><?php echo e($getTranslatedLang['manage_id_products_product_name']); ?></label>
        <div class="col-sm-7">
          <input id="product_name" name="product_name" type="text" placeholder="" class="form-control input-md" value="<?php echo e($product->product_name); ?>" required>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea"><?php echo e($getTranslatedLang['manage_id_products_product_description']); ?></label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description" name="product_description" required><?php echo e($product->product_description); ?></textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Button (Double) -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="button1id"></label>
        <div class="col-sm-7">
         <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Edit') == true)): ?>
          <input type="submit" class="btn btn-primary" value="<?php echo e($getTranslatedLang['manage_id_products_update']); ?>"/>
          <?php endif; ?>
          <a id="edit-cancel-button" name="button2id" class="btn btn-primary" href="<?php echo e(route('product-list')); ?>"><?php echo e($getTranslatedLang['manage_id_products_cancel']); ?></a> </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('admin/product'); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>