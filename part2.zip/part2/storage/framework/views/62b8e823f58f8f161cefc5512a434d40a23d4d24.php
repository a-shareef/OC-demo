   
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(url('/')); ?>/assets/css/jquery-ui.css" />   
<?php $__env->startSection('body'); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/')); ?>/assets/js/jquery.min.js"></script> 

<script src="<?php echo e(url('/')); ?>/assets/js/highstock.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/exporting.js"></script>    
<script src="<?php echo e(url('/')); ?>/assets/js/ftunitschart.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script> 
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/chartValidation.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/metisMenu/jquery.metisMenu.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>