<?php $__env->startSection('title', 'FT Lookup Tool'); ?>
<?php $__env->startSection('content'); ?>

 <link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/cr-1.3.2/r-2.1.1/rr-1.2.0/sc-1.4.2/se-1.2.0/datatables.min.css"/>
<div class="ibox float-e-margins">
<!-- <dt>Search : <input type="text" name="history_details" id="history_details"></dt>
<input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>"> -->
<div class="ibox-title">

<h5>FT Lookup Tool</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
  <div class="ibox-content">
    <div class="form-inline dt-bootstrap">
  <table class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline responsive" cellspacing="0" width="100%" id="users-table">
    <thead>
      <tr>
        <th data-priority="1">Tag #</th>
        <th>Registered Date</th>
        <th>Product Status</th>
        <th data-priority="2">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $retriveProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td data-priority="1"><?php echo e($value->order_sequence); ?></td>
        <td><?php echo e($value->registration_date ? $value->registration_date : '-'); ?></td>
        <td><?php echo e($value->product_status); ?></td>
       <?php 
              $historyLink = '/products/historyDetails/' . userIdEncode($value->order_sequence);
         ?>
        <td data-priority="2"><span class='tooltip-demo1'><a data-toggle='tooltip' data-placement='top' title='Product History Detail' href='<?php echo e($historyLink); ?>' class='btn btn-primary'/>
        <i class='fa fa-history'></i></a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
 
 <script type="text/javascript">
    
    $(document).ready(function() {
     // Adding Datatable and removing sorting feature from Action column 
      $('#users-table').DataTable( {
          "processing": true,
          "columnDefs": [{
              "targets": 3,
              "orderable": false
          }]
      });
});

  </script>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('user/productDetails'); ?>

<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>