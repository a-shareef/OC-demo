<?php $__env->startSection('title', 'Manage Email Templates'); ?>
<?php $__env->startSection('content'); ?> 
<!-- Form Name -->

<form name="insertTemplate" id="insertTemplate" class="form-horizontal" method="POST" action="<?php echo e(route('insertTemplate')); ?>">
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5><?php echo e($getTranslatedLang['manage_email_template_create_new_email_message_template']); ?></h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <?php echo csrf_field(); ?>

    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="Template Name"><?php echo e($getTranslatedLang['manage_email_template_template_name']); ?></label>
        <div class="col-sm-7">
          <input id="template_name" name="template_name" type="text" placeholder="<?php echo e($getTranslatedLang['manage_email_template_template_name']); ?>" class="form-control input-md" required="">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="template_content"><?php echo e($getTranslatedLang['manage_email_template_template_content']); ?></label>
        <div class="col-sm-7">
          <textarea id="template_content" name="template_content" rows="7" class="form-control ckeditor"></textarea>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label"></label>
        <div class="col-sm-7">
          <input type="submit" value="<?php echo e($getTranslatedLang['manage_email_template_add']); ?>" class='btn btn-primary'>
        </div>
      </div>
    </div>
  </div>
 <?=app(JeroenNoten\LaravelCkEditor\CkEditor::class)->editor('template_content');?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/manage-email/add-template'); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>