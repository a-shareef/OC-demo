<!-- resources/views/auth/password.blade.php -->


<?php $__env->startSection('title', 'Product Register'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper" class="gray-bg page-wrapper2">
  <div class="row">
    <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
      <div class="navbar-header"> <a class="logo" href="<?php echo e(url('/')); ?>" ><img src="<?php echo e(url('/')); ?>/assets/images/<?php echo e(siteLogo()); ?>"></a></a></div>
      <ul class="nav navbar-top-links navbar-right">
        <li></li>
      </ul>
    </nav>
  </div>
  <div id="wrapper">
    <div id="page-content-wrapper" class="wrapper wrapper-content animated fadeInRight wrapper2-content">
      <div class="container">
      <div class="row">
      	<div class="col-md-8 col-md-offset-2">

        <div class="ibox">
          <div class="ibox-title">
            <h5>FT Product Registration</h5>
          </div>
          <div class="ibox-content"> <?php echo csrf_field(); ?>

            <?php if(session('status')): ?> 
            <!-- <div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> -->
            <div>
              <p class="msgBannerTxt"> <?php echo e(session('status')); ?> 
                <!-- </div> --> 
              </p>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
            <?php endif; ?>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-sx-12 text-center"> <?php if(session('screenName') == 'existingUser'): ?> <a href="/auth/login" class="btn btn-primary successLoginBtn" id="productemailBtn" type="button">Login</a> <?php else: ?> <a href="<?php echo e(env('FOUNDTHEM_URL')); ?>" target="_blank" class="btn btn-primary successLoginBtn" id="foundtbtn" >FoundThem™</a> <?php endif; ?> </div>
            </div>
          </div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>