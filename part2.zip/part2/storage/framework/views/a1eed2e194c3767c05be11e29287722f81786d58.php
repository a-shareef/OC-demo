<?php 
    $arr = session('arr');
 ?>

<nav class="navbar-default navbar-static-side" role="navigation">
          <div class="sidebar-collapse" id="myNavbar">
            <ul class="nav metismenu" id="side-menu">  
        <?php if(hasrole() == 2): ?>
            <?php if(session('back_role_id')): ?>
                <li <?php if($pagePath == 'admin/dashboard'): ?> class="active dashIcon" <?php else: ?> class="dashIcon" <?php endif; ?>>
                    <a href="<?php echo e(url('/')); ?>/user/backtoadmin">
                       <i class="fa fa-dashboard"></i><span class="nav-label"><?php echo e($languageTrans['admin_dashboard']); ?></span>
                   </a>
               </li>
               <?php else: ?>
               <li <?php if($pagePath == 'admin/dashboard'): ?> class="active dashIcon" <?php else: ?> class="dashIcon" <?php endif; ?>>
                    <a href="<?php echo e(url('/')); ?>/admin/dashboard">
                       <i class="fa fa-dashboard"></i><span class="nav-label"><?php echo e($languageTrans['admin_dashboard']); ?></span>
                   </a>
               </li>
           <?php endif; ?>           
        <?php endif; ?>

        <?php if(hasrole() == 1): ?>        
            <?php if(session('back_role_id')): ?>
                <li <?php if($pagePath == 'admin/dashboard'): ?> class="active dashIcon" <?php else: ?> class="dashIcon" <?php endif; ?>>
                  <a href="<?php echo e(url('/')); ?>/user/backtoadmin">
                      <i class="fa fa-dashboard"></i><span class="nav-label"><?php echo e($languageTrans['sadmin_dashboard']); ?></span>
                  </a>
                </li>
            <?php else: ?>
                <li <?php if($pagePath == 'admin/dashboard'): ?> class="active dashIcon" <?php else: ?> class="dashIcon" <?php endif; ?>>
                  <a href="<?php echo e(url('/')); ?>/admin/dashboard">
                      <i class="fa fa-dashboard"></i><span class="nav-label"><?php echo e($languageTrans['sadmin_dashboard']); ?></span>
                  </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(hasrole() == 4): ?>
        <li <?php if($pagePath == 'agents/dashboard'): ?> class="active dashIcon" <?php else: ?> class="dashIcon" <?php endif; ?>>
          <a href="<?php echo e(url('/')); ?>/agents/dashboard">
             <i class="fa fa-dashboard"></i><span class="nav-label"><?php echo e($languageTrans['agent_dashboard']); ?></span>
          </a>
        </li>
        <?php endif; ?>

        <li
        <?php if($pagePath == 'user/profile' || $pagePath == 'user/profile{user_id?}' || $pagePath == 'user/add'
        || $pagePath == 'user/csa/{userId}' || $pagePath == 'user/admin/{user_id}'): ?>

        class="active profileIcon" <?php else: ?> class="profileIcon" <?php endif; ?>>
        <?php if(empty(session('userId'))): ?>
        <a href="<?php echo e(url('/')); ?>/user/profile">
          <i class="fa fa-user"></i>
                <span class="nav-label"><?php echo e($languageTrans['user_my_profile']); ?></span>
        </a>
        <?php else: ?>
        <a href="<?php echo e(url('/')); ?>/user/profile/<?php echo e(session('userId')); ?>">
          <i class="fa fa-user"></i>
                <span class="nav-label"><?php echo e($languageTrans['user_my_profile']); ?></span>
        </a>
        <?php endif; ?>
      </li>

      <?php if((session('userId')) || (isset($arr) && in_array("FT Product", $arr))): ?>

    
      <li <?php if($pagePath == 'admin/product/user/{user_id}' || $pagePath == 'admin/product/usersproduct/{user_id}'): ?> class="active manageProductIcon"
      <?php else: ?> class="manageProductIcon" <?php endif; ?>>
      <a href="<?php echo e(url('/')); ?>/admin/product/usersproduct/<?php echo e(session('userId')); ?>">
        <i class="fa fa-files-o"></i>
                   <span class="nav-label">FT Product</span>
      </a>
    </li>

    <?php elseif(hasrole() == 2 || hasrole() == 1): ?>

    <li <?php if($pagePath == 'admin/manage-email'): ?> class="active manageEmailIcon"
    <?php else: ?> class="manageEmailIcon" <?php endif; ?>>
    <a href="<?php echo e(url('/')); ?>/admin/manage-email">
      <i class="fa fa-envelope"></i>
                <span class="nav-label"><?php echo e($languageTrans['admin_email_template']); ?></span>
    </a>
  </li>

<li <?php if($pagePath == 'admin/product'): ?> class="active manageMasterProductIcon"
  <?php else: ?> class="manageMasterProductIcon" <?php endif; ?>>
  <a href="<?php echo e(url('/')); ?>/admin/product">
   <i class="fa fa-files-o"></i>
                 <span class="nav-label">Setup FT Product</span>
 </a>
</li>

 <li <?php if($pagePath == 'user/productDetails'): ?> class="active manageMasterProductIcon"
  <?php else: ?> class="manageMasterProductIcon" <?php endif; ?>>
  <a href="<?php echo e(url('/')); ?>/user/productDetails">
   <i class="fa fa-files-o"></i>
                 <span class="nav-label">FT Lookup Tool</span>
 </a>
</li> 

<?php if(hasrole() == 1): ?>

<li <?php if($pagePath == 'admin/manageproduct/{product_id?}' || $pagePath == 'admin/manageproduct'): ?> class="active manageProductIcon"
<?php else: ?> class="manageProductIcon" <?php endif; ?>>
<a href="<?php echo e(url('/')); ?>/admin/manageproduct">
 <i class="fa fa-files-o"></i>
                 <span class="nav-label">Manage FT Products</span>
</a>
</li>

<li <?php if($pagePath == 'user/site-config'): ?> class="active confIcon" <?php else: ?> class="confIcon" <?php endif; ?>>
  <a href="<?php echo e(url('/')); ?>/user/site-config">
    <i class="fa fa-cogs"></i>
                <span class="nav-label"><?php echo e($languageTrans['site_configuration']); ?></span>
  </a>
</li>
<li <?php if($pagePath == 'admin/reports'): ?> class="active reportIcon" <?php else: ?> class="reportIcon" <?php endif; ?>>
 <a href="/admin/reports">
   <i class="fa fa-file-text-o"></i>
                <span class="nav-label">Reports</span>
 </a>
</li>
<?php endif; ?>
<?php endif; ?>
<?php if(empty(session('userId')) && hasrole() == 4): ?>
<li <?php if($pagePath == 'admin/manageproduct/{product_id?}' || $pagePath == 'admin/manageproduct'): ?> class="active manageMasterProductIcon"
<?php else: ?> class="manageMasterProductIcon" <?php endif; ?>>
<a href="<?php echo e(url('/')); ?>/admin/manageproduct">
<i class="fa fa-files-o"></i>
                 <span class="nav-label">Manage FT Products</span>
</a>
</li>
<?php endif; ?>
<li <?php if("/".$pagePath == '/trainingvideos'): ?> class="active videoIcon" <?php else: ?> class="videoIcon" <?php endif; ?>>
<a href="/trainingvideos">
    <i class="fa fa-video-camera"></i>
                <span class="nav-label">Training Videos</span>
  </a>
</li>

<?php if(hasrole() == 1 || hasrole() == 4): ?>
<li class="linkIcon">
  <a href="/direct/profile/<?php echo e(userIdEncode(Auth::id())); ?>/<?php echo e(userIdEncode('PIP')); ?>">
    <i class="fa fa-link"></i>
                <span class="nav-label">UberID PIP</span>
  </a>
</li>
<?php endif; ?>

<?php if((isset($arr) && in_array("Shop", $arr)) || session('userId')): ?>
<li class="shopIcon">
  <a href="http://www.uberid.com/foundthemshop" target="_BLANK">
   <i class="fa fa-shopping-cart"></i>
                   <span class="nav-label"><?php echo e($languageTrans['user_shop']); ?></span>
 </a>
</li>
<?php if(Auth::user()->client_flag == 3 && (hasrole() == 3 || hasrole() == 5 || hasrole() == 6)): ?>
<li class="linkIcon">
  <a href="/direct/profile/<?php echo e(userIdEncode(Auth::id())); ?>/<?php echo e(userIdEncode('PIP')); ?>">
    <i class="fa fa-link"></i>
                <span class="nav-label">UberID PIP</span>
  </a>
</li>
<?php endif; ?>
<?php endif; ?>
<li class="logIcon">
  <a href="<?php echo e(url('/')); ?>/auth/logout">
    <i class="fa fa-sign-out"></i>
                  <span class="nav-label"><?php echo e($languageTrans['user_logout']); ?></span>
  </a>
</li>

</ul>
</div>
</nav>
