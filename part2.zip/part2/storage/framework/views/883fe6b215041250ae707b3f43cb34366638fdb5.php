<!-- resources/views/user/profile.blade.php -->


<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('content'); ?>
<?php  
  $uid = (isset($users->uid))?$users->uid:'';
 ?>
<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span> <?php echo e(session('status')); ?> </div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span> <?php echo e(session('error')); ?> </div>
<?php endif; ?>
<form id="profileForm"  class="form-horizontal" data-toggle="validator" method="POST"
action="<?php echo e(url('/')); ?>/user/profile" role="form" style="display: block;">
  <div class="ibox float-e-margins">
    <div class="ibox-title"> <?php if(isset($users->fk_role_id) && $users->fk_role_id == PROFILE_CS_AGENT): ?>
      <?php if(hasrole() == PROFILE_SUPER_ADMIN && empty($users->email)): ?>
      <h5><?php echo e($transLanguage['edit_csagent_profile']); ?></h5>
      <?php else: ?>
      <h5><?php echo e($transLanguage['edit_csagent_profile']); ?></h5>
      <?php endif; ?>
      <?php elseif(isset($users->fk_role_id) && $users->fk_role_id == PROFILE_ADMIN): ?>
      <h5><?php echo e($transLanguage['edit_admin_profile']); ?></h5>
      <?php else: ?>
      <h5><?php echo e($transLanguage['edit_user_profile']); ?></h5>
      <?php endif; ?>
      <?php echo csrf_field(); ?>

      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="role"></label>
        <div class="col-sm-7"><span class="asterisk_notice">(* Fields marked as mandatory)</span></div>
      </div>
      <!-- Select Basic -->
      
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="user_title"> <?php echo e($transLanguage['edit_title']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <select required id="user_title" name="user_title" class="form-control blurclass" >
            <option value="">Select  <?php echo e($transLanguage['edit_title']); ?></option>
            
        <?php $__currentLoopData = $titleArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
          <option  value="<?php echo e($title); ?>"
              <?php if((old('user_title') ? old('user_title') : $users->   
        
          user_title) == $title): ?>
              selected="selected" <?php endif; ?>>
              <?php echo e($title); ?>

   
        
            </option>
  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          </select>
          <div class="alert-message alert-warning"><?php echo e($errors->first('user_title')); ?></div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="firstname"> <?php echo e($transLanguage['edit_first_name']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <input id="firstname" name="firstname" type="text" placeholder="<?php echo e($transLanguage['edit_first_name']); ?>"
          class="form-control input-md blurclass" pattern="[^0-9]*"  required=""
          value="<?php echo e(old('firstname') ? old('firstname') : $users->first_name); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger"><?php echo e($errors->first('firstname')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="lastname"> <?php echo e($transLanguage['edit_last_name']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <input id="lastname" name="lastname" type="text" placeholder="<?php echo e($transLanguage['edit_last_name']); ?>"
          class="form-control input-md blurclass" pattern="[^0-9]*" required=""
          value="<?php echo e(old('lastname') ? old('lastname') : $users->last_name); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger"><?php echo e($errors->first('lastname')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="email"> <?php echo e($transLanguage['edit_email']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div id="emaildiv" class="col-sm-7">
          <input id="email" name="email" type="email" placeholder="<?php echo e($transLanguage['edit_email']); ?>"
  class="form-control input-md" pattern="[A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z]{2,3}$"
  required value="<?php echo e(old('email') ? old('email') : $users->email); ?>">
          <input id="email_cpy" name="email_cpy" type="hidden" placeholder="<?php echo e($transLanguage['edit_email']); ?>"
  class="form-control input-md" value="<?php echo e(old('email') ? old('email') : $users->email); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger"><?php echo e($errors->first('email')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="row" id="emailPwdid" style="display:none;">
        <div  class="col-md-12 col-sm-12 col-xs-12 " >
          <div class="form-group">
            <label class="col-sm-3 control-label" for="email"> Enter Current Password: </label>
            <div id="emailpassdiv" class="col-sm-7">
              <input type="password" name="emailPassword" id="emailPassword" tabindex="2" class="form-control" placeholder="Enter Current Password">
              <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
              <div class="alert-message alert-danger"><?php echo e($errors->first('email')); ?></div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label emailPasswrd"></label>
            <div class="col-sm-4">
              <input type="hidden" value="<?php echo e($uid); ?>" name="pass_user_id" id="pass_user_id" />
              <input type="button" name="checkEmailPwd" id="checkEmailPwd" class="btn btn-primary" value="Confirm">
            </div>
          </div>
          <div class="hr-line-dashed"></div>
        </div>
      </div>
      <!-- Text input--> 
      
      <!-- Text input-->
    <div class="row">
      <div class="col-sm-10 col-md-5">
        <div class="form-group countary-code">
          <label class="col-sm-7 control-label" for="country_code"> <?php echo e($transLanguage['edit_country_code']); ?>:
              <span class="profile_asterik profile_asterik_mob">*</span> 
          </label>
          <div class="col-sm-3">
          <div class="input-group">
                <input id="countrys_code" type="hidden" value="<?php echo e(old('country_code') ? old('country_code') : $users->country_code); ?>"> 
                <span class="input-group-addon" id="ccPlus">+</span>
                <span class="input-group-addon" id="ccdid" type="text" style="display:none"></span>
                <select required id="country_code" name="country_code" class="form-control country_code_common" required>
                    <option value="">Country Code</option>            
                    <?php if(isset($countryArray)): ?>
                        <?php $__currentLoopData = $countryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryArrays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <option data-ccdid="<?php echo e($countryArrays->id); ?>" value="<?php echo e($countryArrays->countryId); ?>" <?php echo e(isset($cookieData['country_code']) && $cookieData['country_code'] == $countryArrays->id ?  'selected="selected"' : ''); ?>

                        <?php if((old('country_code') ? old('country_code') : $users->country_code)  == $countryArrays->countryId): ?> selected="selected" <?php endif; ?> >
                               <?php echo e($countryArrays->text); ?> - +<?php echo e($countryArrays->id); ?>  
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
          </div>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger"><?php echo e($errors->first('country_code')); ?></div>
            <?php if(isset($countryArray)): ?>
                <div id="countryCo"  data-field-id="<?php echo e(json_encode($countryArray)); ?>"></div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="hidden-lg hidden-md col-xs-12">
        <div class="hr-line-dashed"></div>
      </div>
      <div class="col-sm-10 col-md-5">
        <div class="form-group countary-number">
          <label class="col-sm-3 control-label" for="phone"> <?php echo e($transLanguage['edit_phone']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-md-3 col-sm-7">
          <input id="phone" name="phone" pattern="^\D*(?:\d\D*){10}" type="tel"
          placeholder="<?php echo e($transLanguage['edit_phone']); ?>"
          class="form-control input-md" required=""
          value="<?php echo e(old('phone') ? old('phone') : $users->user_phone); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-danger"><?php echo e($errors->first('phone')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div id="optional_data"> 
        <!-- Text input-->
        <div class="form-group">
          <label class="col-sm-3 control-label" for="address1"> <?php echo e($transLanguage['edit_address_1']); ?>: </label>
          <div class="col-sm-7">
            <input id="address1" name="address1" type="text" placeholder="<?php echo e($transLanguage['edit_address_1']); ?>"
          class="form-control input-md blurclass"
          value="<?php echo e(old('address1') ? old('address1') : $users->street_address1); ?>">
            <div class="alert-message alert-danger"><?php echo e($errors->first('address1')); ?></div>
          </div>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="address2"> <?php echo e($transLanguage['edit_address_2']); ?>: </label>
        <div class="col-sm-7">
          <input id="address2" name="address2" type="text" placeholder="<?php echo e($transLanguage['edit_address_2']); ?>"
          class="form-control input-md blurclass"
          value="<?php echo e(old('address2') ? old('address2') : $users->street_address2); ?>">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="address3"> <?php echo e($transLanguage['edit_address_3']); ?>: </label>
        <div class="col-sm-7">
          <input id="address3" name="address3" type="text" placeholder="<?php echo e($transLanguage['edit_address_3']); ?>"
          class="form-control input-md blurclass"
          value="<?php echo e(old('address3') ? old('address3') : $users->street_address3); ?>">
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="city"> <?php echo e($transLanguage['edit_city']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="city" name="city" type="text" placeholder="<?php echo e($transLanguage['edit_city']); ?>"
          class="form-control input-md blurclass" required="" pattern="[A-z ]+$"
          value="<?php echo e(old('city') ? old('city') : $users->user_city); ?>">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger"><?php echo e($errors->first('city')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="state"> <?php echo e($transLanguage['edit_state_province']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="state" name="state" type="text" placeholder="<?php echo e($transLanguage['edit_state_province']); ?>"
          class="form-control input-md blurclass" required="" pattern="[A-z ]+$"
          value="<?php echo e(old('state') ? old('state') : $users->user_state); ?>">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger"><?php echo e($errors->first('state')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Select Basic -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="country"> <?php echo e($transLanguage['edit_country']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <select required id="country" name="country" class="form-control blurclass">
              <option value="">Select <?php echo e($transLanguage['edit_country']); ?></option>
              
              <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
              <option value="<?php echo e($country->country_code); ?>"
                    <?php if((old('country') ? old('country') : $users->
                   
          
            user_country ) == $country->country_code): ?>
                    selected="selected"
                     <?php endif; ?> >
                    <?php echo e($country->country_name); ?>   
          
              </option>       
            
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
            </select>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger"><?php echo e($errors->first('country')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="zip"> <?php echo e($transLanguage['edit_zip_postcode']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group">
            <input id="zip" name="zip" type="text" placeholder="<?php echo e($transLanguage['edit_zip_postcode']); ?>"
          class="form-control input-md blurclass" required="" style="text-transform:uppercase"
          value="<?php echo e(old('zip') ? old('zip') : $users->user_zip); ?>">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
          <div class="alert-message alert-danger"><?php echo e($errors->first('zip')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <!-- Select Basic -->
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="user_title"> <?php echo e($transLanguage['edit_date_format']); ?>: </label>
        <div class="col-sm-7">
          <select id="date_format" name="date_format" class="form-control blurclass" >      
          
              <?php $__currentLoopData = $dateArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <option  value="<?php echo e($key); ?>"
              <?php if((old('date_format') ? old('date_format') : $users->       
        
          date_format) == $key): ?>
              selected="selected" <?php endif; ?>>
              <?php echo e($date); ?>        
        
            </option>
                     
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
      
          </select>
        </div>
      </div>
      <div class="hr-line-dashed"></div>
      <!-- Text input-->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="dob"> <?php echo e($transLanguage['edit_date_of_birth']); ?>:<span class="profile_asterik profile_asterik_mob">*</span> </label>
        <div class="col-sm-7">
          <div class="input-group date" id="date_of_birth">
            <input id="dob" name="dob" type="text" placeholder=" <?php echo e($transLanguage['edit_date_of_birth']); ?>"
          class="form-control input-md blurclass" required
          value="<?php echo e(old('dob') ? old('dob') : $users->date_of_birth); ?>">
            <span class="input-group-addon"> <span class="glyphicon glyphicon-calendar"></span> </span></div>
          <div class="alert-message alert-danger"><?php echo e($errors->first('dob')); ?></div>
          <span class="profile_asterik">*</span> </div>
      </div>
      <div class="hr-line-dashed"></div>
       <!-- Select Basic -->
        <div class="form-group">
          <label class="col-sm-3 control-label" for="package"> Package </label>
          <div class="col-sm-7">
            <div class="input-group">
              <select id="package_profile" name="package_id" class="blurclass form-control" required >
                  <option value="">Select Package</option>
                    <?php $__currentLoopData = $packageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                      <option  value="<?php echo e($package->id); ?>" <?php if((old('package_id') ? old('package_id') : $users->package_id) == $package->id): ?>
                  selected="selected" <?php endif; ?> >
                        <?php echo e($package->name); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <label class="control-label input-group-addon chk_label">
                <input type="checkbox" class="switch js-switch_11" name="chk_package" value="true"> 
              </label>
            </div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
            <div class="alert-message alert-danger"><?php echo e($errors->first('package')); ?></div>
          </div>
        </div>
        <div class="hr-line-dashed"></div>
     <!-- Button -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="cancel"></label>
        <div class="col-sm-7">
      <?php if($users->email): ?>
        <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('My Profile', 'Edit') == true)): ?>

          <button id="profile_submit" name="profile_submit"
            class="btn btn-primary"> <?php echo e($transLanguage['edit_update']); ?> </button>
        <?php endif; ?> 
      <?php else: ?>
          <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('My Profile', 'Add') == true)): ?>

            <button id="profile_submit" name="profile_submit"
            class="btn btn-primary"> <?php echo e($transLanguage['edit_submit']); ?> </button>
          <?php endif; ?> 
      <?php endif; ?>
          
        <?php if($users->email): ?>
          <input type="button" class="btn btn-secondary" onclick="window.history.go(-1); return false;" value="<?php echo e($transLanguage['edit_cancel']); ?>"/>
          <?php else: ?>
          <input class="btn btn-secondary" type="reset" value="<?php echo e($transLanguage['edit_reset']); ?>">
          <?php endif; ?> </div>
        <div class="col-md-4 col-sm-4 col-xs-4 input-group"> </div>
      </div>
      <?php if($users->email): ?>
      <input type="hidden" value="PUT" name="_method" />
      <input type="hidden" value="<?php echo e($uid); ?>" name="user_id" />
      <?php endif; ?>
      
      
      <?php if(isset($users->fk_role_id) && ($users->fk_role_id == PROFILE_SUPER_ADMIN || $users->fk_role_id == PROFILE_ADMIN)): ?>
      <input type="hidden" value="<?php echo e($users->fk_role_id); ?>" id="role_id"/>
      <?php endif; ?>
      <?php if(isset($users->fk_role_id)): ?>
      <?php if(empty($users->email) && (hasrole() == PROFILE_SUPER_ADMIN || hasrole() == PROFILE_ADMIN || hasrole() == PROFILE_CS_AGENT)): ?>
      <input type="hidden" value="1" id="ajaxEmail" />
      <input type="hidden" name="_token" id="fttoken" value="<?php echo e(csrf_token()); ?>"/>
      <?php endif; ?>
      <input type="hidden" value='<?php echo e($users->fk_role_id); ?>' id="role_id" name="roleId" />
      <?php endif; ?> </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php $currentRoutes = Route::currentRouteName();?>
<?php if($currentRoutes == 'add'): ?>
    <?php echo Breadcrumbs::render('admin/add'); ?>

<?php endif; ?>
<?php if($currentRoutes == 'csa'): ?>
    <?php echo Breadcrumbs::render('user/csa'); ?>

<?php endif; ?>
<?php if($currentRoutes == 'edit_csa'): ?>
    <?php echo Breadcrumbs::render('user/csa/{userId}'); ?>

<?php endif; ?>
<?php if($currentRoutes == 'edit_admin'): ?>
    <?php echo Breadcrumbs::render('user/admin/{userId}'); ?>

<?php endif; ?>
<?php if($currentRoutes == 'profile'): ?>
    <?php echo Breadcrumbs::render('user/profile/{user_id?}'); ?>

<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>  
    ##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac## 
    <link href="<?php echo e(url('/')); ?>/assets/css/select2/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712## 
<script src="<?php echo e(url('/')); ?>/assets/js/select2/select2.full.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/countryCode.js"></script> 
<script src="/assets/js/profile.js"></script> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>