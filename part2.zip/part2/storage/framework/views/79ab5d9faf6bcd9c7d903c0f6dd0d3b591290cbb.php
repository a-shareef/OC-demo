<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
    <meta charset="utf-8"/>
    <title>UberID FoundThem - <?php echo $__env->yieldContent('title'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport"/>
    <meta content="" name="description"/>
    <meta content="" name="author"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/png" href="/assets/images/UberID-Favicon.png"/>
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/style.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/fileinput.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/iCheck/custom.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/switchery/switchery.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/morris/morris-0.4.3.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/style.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/assets/css/responsive.css" rel="stylesheet">
     <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/auth.css">
     <link href="<?php echo e(url('/')); ?>/assets/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet" id="bootstrap-css">
     <link href="<?php echo e(url('/')); ?>/assets/css/common.css" rel="stylesheet">
	 <link href="<?php echo e(url('/')); ?>/assets/css/style.css" rel="stylesheet">
     <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/passwordindicator.css">
     <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="login">
<?php echo $__env->yieldContent('content'); ?>
</body>
<footer>
<script src="<?php echo e(url('/')); ?>/assets/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/validator.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/moment-with-locales.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/bootstrap/js/bootstrap-datetimepicker.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/iCheck/icheck.min.js"></script>
   <script src="<?php echo e(url('/')); ?>/assets/js/switchery/switchery.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(url('/')); ?>/assets/js/GoogleAnalytics.js"></script>
<?php if(empty(session('locationData'))): ?>
<script src="<?php echo e(url('/')); ?>/assets/js/geolocation.js"></script>
<?php endif; ?>
<script src="<?php echo e(url('/')); ?>/assets/js/passwordcheck.js"></script>
<?php echo $__env->yieldContent('script'); ?>
<script type="text/javascript">
 $(".alert").delay(2000).fadeOut();
 $(".alert-message").delay(4000).fadeOut();
    $(".external").click(function(event) {
var confirmation = confirm("Are you sure you want to leave this page? Content will open in a new window");
   if (!confirmation) {     
     event.preventDefault();
   }
 });
</script>
<script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
			var switchlength = $('.switch').length;			
			for(var i = 1;i<=switchlength;i++){
            var elem = document.querySelector('.js-switch_'+ i);
            var switchery = new Switchery(elem, { color: '#ef8623' });
            
			}
            });
			
        </script>
</footer>
</html>
