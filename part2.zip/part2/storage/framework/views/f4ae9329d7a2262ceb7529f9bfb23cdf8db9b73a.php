<?php $__env->startSection('title', 'Add New Product'); ?>
<?php $__env->startSection('content'); ?>
<form id="form-add-product"  class="form-horizontal" data-toggle="validator" method="POST"
action="<?php echo e(url('/')); ?>/admin/product/add" role="form">
  <div class="ibox float-e-margins">
    <div class="ibox-title">
      <h5><?php echo e($getTranslatedLang['manage_id_products_heading_add_new_product']); ?></h5>
      <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
    </div>
    <?php echo csrf_field(); ?>

    <div class="ibox-content">
      <div class="form-group">
        <label class="col-sm-3 control-label" for="product_name"> <?php echo e($getTranslatedLang['manage_id_products_product_name']); ?>: </label>
        <div class="col-sm-7">
          <input id="product_name" name="product_name" type="text" placeholder="Product Name"
   class="form-control input-md" required value="<?php echo e(old('product_name')); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>
      <div class="form-group">
        <label class="col-sm-3 control-label" for="productInitials"> Product Initials: </label>
        <div class="col-sm-7">
          <input id="productInitials" name="productInitials" type="text" placeholder="Product Initials"
   class="form-control input-md" maxlength="2" required value="<?php echo e(old('productInitials')); ?>">
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
          <div class="alert-message alert-warning"><?php echo e($errors->first('productInitials')); ?></div>
        </div>
      </div>
      <div class="hr-line-dashed"></div>      
      <!-- Textarea -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="textarea"> <?php echo e($getTranslatedLang['manage_id_products_product_description']); ?>: </label>
        <div class="col-sm-7">
          <textarea class="form-control" id="product_description" placeholder="Product Description"
    name="product_description" required><?php echo e(old('product_description')); ?></textarea>
          <span class="glyphicon form-control-feedback" aria-hidden="true"></span> </div>
      </div>
      <div class="hr-line-dashed"></div>      
      <!-- Button (Double) -->
      <div class="form-group">
        <label class="col-sm-3 control-label" for="button1id"></label>
        <div class="col-sm-7">
        <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Add') == true)): ?>          
        <input type="submit" class="btn btn-primary" value="<?php echo e($getTranslatedLang['manage_id_products_add']); ?>"/>
        <?php endif; ?>
          <a id="edit-cancel-button" name="button2id" class="btn btn-primary" href="<?php echo e(route('product-list')); ?>"><?php echo e($getTranslatedLang['manage_id_products_cancel']); ?></a> </div>
      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('admin/product/add'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>