 
<?php $__env->startSection('title', 'Tag # Details'); ?>
<?php $__env->startSection('content'); ?>

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag Details:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">

  <?php if(!$viewData->isEmpty()): ?>

  <?php 
    $values =  $viewData[0];
   ?>

   <dl class="dl-horizontal">  
      <div class="hr-line-dashed"></div>
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Product :</dt>
    <dd> <?php echo e($values->product_name); ?> </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Order Number :</dt>
    <dd> <?php echo e($values->order_no); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Company Name :</dt>
    <dd> <?php echo e($values->company_name); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Order Description :</dt>
    <dd> 
      <?php if(!empty($values->description) && isset($values->description)): ?> <?php echo e($values->description); ?> <?php else: ?> <?php echo e('-'); ?> <?php endif; ?>
    </dd>
      <div class="hr-line-dashed"></div>
       <dt>Order Status :</dt>
    <dd> <?php if(!empty($orderStatus) && isset($orderStatus)): ?><?php echo e($orderStatus); ?> <?php else: ?> <?php echo e('-'); ?> <?php endif; ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Order Date :</dt>
    <dd> <?php echo e($values->order_date); ?> </dd>
      <div class="hr-line-dashed"></div>  
    <dt>Product Status :</dt>
    <dd> <?php echo e($values->product_status); ?> </dd>
      <div class="hr-line-dashed"></div>
    <?php if($values->fk_user_id != '' && $values->fk_user_id > 0): ?> 
   
    <dt>User Name :</dt>

    <dd> 
     <?php if(!empty(getUserdetails($values->fk_user_id))): ?>

      <?php echo e(getUserdetails($values->fk_user_id)[0]->first_name); ?> <?php echo e(getUserdetails($values->fk_user_id)[0]->last_name); ?>

      <?php else: ?>
      <?php echo e("No record"); ?>

      <?php endif; ?>
    </dd>
  
    <div class="hr-line-dashed"></div>
     <dt>Registered Date :</dt>
    <dd> <?php echo e($values->registration_date); ?> </dd>
     <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> <?php echo e($reg_ipaddr); ?> </dd>
     <?php endif; ?>
  </dl>
  <?php endif; ?>  

   <?php if($viewData->isEmpty()): ?>
  <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  <?php endif; ?> </div>
  </div>

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag History:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>


<div class="ibox-content">

  <?php if(isset($tagHistory)): ?>
  <ul class="sortable-list connectList agile-list ui-sortable" id="todo"> 

  <?php $__currentLoopData = $tagHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="warning-element ui-sortable-handle" id="task1">
  
  <?php if($values->status == 3): ?>
  <dl class="dl-horizontal">  
      
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>

    <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>Updated By :</dt>

    <dd> 

      <?php if(!empty($values->updated_by) && $values->updated_by > 0): ?>

      <?php if(!empty(getUserdetails($values->updated_by))): ?>
      <?php echo e(getUserdetails($values->updated_by)[0]->first_name); ?> <?php echo e(getUserdetails($values->updated_by)[0]->last_name); ?> 
     

      <?php if($values->updated_by == 1): ?>
      (Super Admin)
      <?php elseif($values->updated_by == 4): ?>
      (CS Agents)
      <?php else: ?>
      (User)
      <?php endif; ?>
      <?php else: ?>
      <?php echo e('No record'); ?>

       <?php endif; ?> 
       <?php endif; ?>
        </dd>

      <div class="hr-line-dashed"></div>
    <dt>Product Last seen :</dt>
    <dd> <?php echo e($values->lastseen_location); ?> </dd>
      <div class="hr-line-dashed"></div>

    <dt>Last seen On :</dt>
    <dd> <?php echo e($values->lastseen_on); ?> <?php echo e($values->lastseen_time); ?> </dd>
    
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>

    <dt>Date :</dt>

    <dd> <?php echo e($values->created_at); ?> </dd>
  </dl>

  <?php elseif($values->status == 4): ?>
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Suspend </dd>
      <div class="hr-line-dashed"></div>
    <?php if($values->updated_by != ''): ?>
    <dt>Suspended By :</dt>

    <?php if(!empty(getUserdetails($values->updated_by))): ?>
    <dd> <?php echo e(getUserdetails($values->updated_by)[0]->first_name); ?> <?php echo e(getUserdetails($values->updated_by)[0]->last_name); ?> </dd>
    <?php else: ?>
    <dd>No record</dd>
    <?php endif; ?>
      <div class="hr-line-dashed"></div>
    <?php endif; ?>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> <?php echo e($values->created_at); ?></dd>
  </dl>
  <?php elseif($values->status == 5): ?>
  <?php if($values->fk_user_id == 0 || $values->fk_user_id == ''): ?>
  <dl class="dl-horizontal">
    <dt>Product Never Registered.</dt>
  </dl> 
      <div class="hr-line-dashed"></div>
  <?php endif; ?>
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> <?php echo e($values->first_name); ?> <?php echo e($values->last_name); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> <?php echo e($values->email); ?> </dd>
      <div class="hr-line-dashed"></div>
    <?php if(!empty($values->country_code) && !empty($values->phone)): ?>
    <dt>Phone :</dt>
    <dd> +<?php echo e($values->country_code); ?> <?php echo e($values->phone); ?> </dd>
      <div class="hr-line-dashed"></div>
    <?php endif; ?>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> <?php echo e($values->created_at); ?> </dd>
  </dl>
  <?php elseif($values->status == 6): ?>
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Lost Found </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> <?php echo e($values->first_name); ?> <?php echo e($values->last_name); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> <?php echo e($values->email); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Phone :</dt>
    <dd> +<?php echo e($values->country_code); ?> <?php echo e($values->phone); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> <?php echo e($values->created_at); ?> </dd>
  </dl>
  <?php elseif($values->status == 7): ?>
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Found Lost </dd>
      <div class="hr-line-dashed"></div>
    <dt>Updated By :</dt>
    <dd> <?php echo e(getUserdetails($values->updated_by)[0]->first_name); ?> <?php echo e(getUserdetails($values->updated_by)[0]->last_name); ?> 
      <?php if($values->updated_by == 1): ?>
      (Super Admin)
      <?php elseif($values->updated_by == 2): ?>
      (Admin)
      <?php elseif($values->updated_by == 4): ?>
      (CS Agents)
      <?php else: ?>
      (User)
      <?php endif; ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Lastseen :</dt>
    <dd> <?php echo e($values->lastseen_location); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Lastseen On :</dt>
    <dd> <?php echo e($values->lastseen_on); ?> <?php echo e($values->lastseen_time); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> <?php echo e($values->created_at); ?></dd>
  </dl>
  <?php elseif($values->status == 8): ?>
  <dl class="dl-horizontal">
    <dt>Tag # :</dt>
    <dd> <?php echo e($values->order_sequence); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Product Status :</dt>
    <dd> Reactivated </dd>
      <div class="hr-line-dashed"></div>
    <dt>Name :</dt>
    <dd> <?php echo e($values->first_name); ?> <?php echo e($values->last_name); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Email :</dt>
    <dd> <?php echo e($values->email); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>IP Address :</dt>
    <dd> <?php echo e($values->ip); ?> &nbsp;&nbsp; Indicated what3words location for the event: <a href="<?php echo e($values->location); ?>" class="external" target="_blank" ><?php echo e($values->location); ?></a> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Remarks :</dt>
    <dd> <?php echo e($values->lastseen_remarks); ?> </dd>
      <div class="hr-line-dashed"></div>
    <dt>Date :</dt>
    <dd> <?php echo e($values->created_at); ?> </dd>
  </dl>
  <?php endif; ?> 
  
  </li><br/>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <?php endif; ?>  
  
  <?php if(!isset($tagHistory[0])): ?>
  <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  <?php endif; ?> </div>
  </div>

<div class="ibox float-e-margins">
<div class="ibox-title">
  <h5>Tag Transfer History:</h5>
  <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
</div>
<div class="ibox-content">
  <?php if(isset($tagTransferHistory['data'][0])): ?> 


  <?php $__currentLoopData = $tagTransferHistory['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  
  <ul class="sortable-list connectList agile-list ui-sortable" id="todo">
    <?php $__currentLoopData = $tagTransferHistory['tagTransferFrom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(!empty($transfer['trans_notes'])): ?>
   <li class="warning-element ui-sortable-handle" id="task1">
                              
    

    <dl class="dl-horizontal">
     
      <dt>Tag # :</dt>
    <dd>
    <?php echo e($transfer['tag_id']); ?>

    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Tag Transferred FROM :</dt>
    <dd>
    <?php echo e($transfer['from_email']); ?>

    </dd>
    <div class="hr-line-dashed"></div>
      <dt>Tag Transferred TO :</dt>
    <dd>
    <?php echo e($transfer['to_email']); ?>

    </dd>
    <div class="hr-line-dashed"></div>
      <dt>Tag Status :</dt>
    <dd>
    <?php echo e($transfer['tag_status']); ?>

    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Notes on Transaction :</dt>
    <dd>
    <?php if(!empty($transfer['trans_notes']) && isset($transfer['trans_notes'])): ?> <?php echo e($transfer['trans_notes']); ?> <?php else: ?> <?php echo e('-'); ?> <?php endif; ?>
    </dd>
     <div class="hr-line-dashed"></div>
      <dt>Tag Transfer Date and Time (UTC) :</dt>
    <dd>
    <?php echo e($transfer['tranfer_date']); ?>

    </dd>
    <div class="hr-line-dashed"></div>
      <dt>SA/A/CS Name :</dt>
    <dd>
    <?php echo e($transfer['name'] . ' ( ' . $transfer['role'] .' )'); ?>

    </dd>
    </li><br/>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

  <?php if(empty($tagTransferHistory['tagTransferFrom'][0]['trans_notes'])): ?>
    <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  <?php endif; ?>
  </dl>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
 <?php if(empty($tagTransferHistory['data'][0])): ?>
    <dl class="dl-horizontal text-center"><strong>No Records Found.</strong></dl>
  <?php endif; ?>

 </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('products/historyDetails/{tagId}'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>