<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?> 
<!-- Form Name --> 

<?php if(session('status')): ?>
<div class="alert alert-success"><span class="glyphicon glyphicon-ok-sign"></span>
  <div> <?php echo e(session('status')); ?> </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger"><span class="glyphicon glyphicon-remove-sign"></span>
  <div> <?php echo e(session('error')); ?> </div>
</div>
<?php endif; ?>

 <?php if(hasrole() == 3 || hasrole() == 5 || hasrole() == 6 || hasrole() == 1): ?>
<div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>Register New Product </h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <?php endif; ?> 
  <!-- Button -->
  <div class="ibox-content">
    <div class="form-group">
      <div class="col-md-12 col-sm-12 col-xs-12 input-group btnSubmit btbCenterMobi"> 
        <!-- <button type="button" id="add_product" name="add_product" class="btn btn-success">Add new product</button> --> 
        
        <?php if(hasrole() == 3 || hasrole() == 5 || hasrole() == 6 || hasrole() == 1): ?>
        <button type="button" id="addProduct" name="addProduct" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Register New Product</button>
        <?php endif; ?> </div>
    </div>
    
    <form class="form-horizontal" method="POST" action="<?php echo e(route('saveFTProduct',  $user_id)); ?>">
      <?php echo csrf_field(); ?>

      <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user_id); ?>" />
      <div id="showProduct" style="display: none;">
        <div class="row">
          <div class="col-sm-7 regCodeNo" id="tagnoerror">
            <div class="input-group">
              <input id="tagno" name="tagno" type="text" class="form-control input-md" pattern="^([A-Za-z]{1,2}[0-9]{6,7})" required="" value="" placeholder="Tag #" onblur="return check_availability()">
              <span class="input-group-btn">
              <button type="submit" id="add_entry" name="add_entry" class="btn btn-primary" value="Add"><i class="fa fa-plus" aria-hidden="true"></i> Add</button>
              </span> </div>
            <span class="glyphicon form-control-feedback" id="glyphicon" aria-hidden="true"></span>
            <div class="alert-message alert-danger" id="tagno_availability_result" style="display: none;"></div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Select Basic -->
<form class="form-horizontal" method="POST">
  <?php echo csrf_field(); ?>

  <div class="tableContentBox showProductBox">
  <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
  <div class="ibox float-e-margins">
  <div class="ibox-title">
    <h5>FT-Product - (<?php echo e(count($retriveProduct)); ?>)</h5>
    <div class="ibox-tools"> <a class="collapse-link"> <i class="fa fa-chevron-up"></i> </a> </div>
  </div>
  <?php if($retriveProduct): ?>
  <div class="ibox-content">
  <div class="table-responsive">
  <table cellspacing="0" cellpadding="0" border="0" width="100%" class="table table-striped table-bordered table-hover dataTables-example dataTable dtr-inline no-footer responsive productDataTable mftprod-table" id="mftprod-table">
    <thead>
      <tr>
        <th data-priority="1">Product Image</th>
        <th >Product Type</th>
        <th >User Description</th>
        <th >Tag #</th>
        <th >Registered Date</th>
        <th >Status</th>
        <th data-priority="2">Action</th>
      </tr>
    </thead>
    <tbody>
    
    <?php $__currentLoopData = $retriveProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td class="productimage"><img src="<?php echo e(URL::asset('/uploads/productavatar/'.$value->product_image)); ?>" id="productimage"></td>
      <td><?php echo e($value->product_name); ?></td>
      <td><?php echo e($value->user_description); ?></td>
      <td><?php echo e($value->order_sequence); ?></td>
      <td> <?php if($value->registration_date != '00-00-0000' && $value->registration_date != 'NULL'  && $value->registration_date != ''): ?> 
        <?php echo e(date('m-d-Y',strtotime($value->registration_date))); ?>

        <?php endif; ?></td>
      <td> <?php echo e($value->product_status); ?></td>
      <td><span class="tooltip-demo">
       <?php if($value->product_status == 'Activated' || $value->product_status == 'Found'): ?> 
       <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Report Lost') == true)): ?>
       <a href='/admin/product/productlost/<?php echo e(userIdEncode($value->id)); ?>' id='reportProductLost' name='reportProductLost' class='btn btn-primary' data-toggle="tooltip" data-placement="top" title="Report Lost"><i class="fa fa-paperclip fa-suspend"></i></a>
        <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
        <?php endif; ?>
        <?php endif; ?>
        <?php if((hasrole() == PROFILE_SUPER_ADMIN) || (accessToVisible('FT Product', 'Add Desc') == true)): ?>
        <a href='/admin/product/usersAddDescription/<?php echo e(userIdEncode($value->id)); ?>' id='addproductdescription' name='addproductdescription' class='btn  btn-primary' title="Add Description" data-toggle="tooltip" data-placement="top" title="Add Description"><i class="fa fa-pencil"></i></a> 
        <?php endif; ?>
        </span></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    
  </table>
  <?php endif; ?>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('admin/product/usersproduct/{user_id}'); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>