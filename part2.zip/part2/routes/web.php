<?php
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*FOR ACCESSTOKEN*/
// First route that user visits on consumer app
Route::get('/api', function () {
    // Build the query parameter string to pass auth information to our request
    $query = http_build_query([
        'client_id' => 1,
        'redirect_uri' => 'http://54.221.48.250/callback',
        'response_type' => 'code',
        // 'scope' => 'conference'
    ]);

    // Redirect the user to the OAuth authorization page
   return redirect("http://34.227.15.40/oauth/authorize?" . $query);
});

// Route::get('/test', function () {
// $dbExt = \DB::connection('mysql2');
   
//     $result = $dbExt->table('user_platform_relationship')
//                      ->select('user_id','package_id','client_flag')
//                      ->where('uid', '=', 12345)
//                      ->get();
//          dd($result);

// });

// Route that user is forwarded back to after approving on server
Route::get('callback', function (Request $request) {
    $http = new GuzzleHttp\Client;

    $response = $http->post('http://34.227.15.40/oauth/token', [
        'form_params' => [
            'grant_type' => 'authorization_code',
            'client_id' => 17, // from admin panel above
            'client_secret' => '82RvVw7QGCtRRw92iTz8k9nkHngS30400V0iyrAE', // from admin panel above
            'redirect_uri' => 'http://54.221.48.250/callback',
            'code' => $request->code // Get code from the callback
        ]
    ]);

   // echo the access token; normally we would save this in the DB
    return json_decode((string) $response->getBody(), true)['access_token'];
});



Route::get('/bonecms_captcha', function(){});
Route::get('register/emailbtn', 'Register\registerController@validemail');
// Manage Language Route Section
Route::group(['middleware' => 'auth'], function () {
    Route::get('home', 'User\DashboardController@index')->name('home');
    Route::get('/user/site-config', 'Profile\SiteConfigurationController@show')->name('siteConfig');
    Route::post('/site-config-logo', 'Profile\SiteConfigurationController@updateLogo');
    Route::post('/site-config-slogan', 'Profile\SiteConfigurationController@updateSlogan');
    Route::get('/resend/activation/{userId}', 'Profile\ProfileController@resendActivation');
    Route::get('/products/details/{tagId}', 'User\DashboardController@fetchLostData')->name('lostfoundreport');
    Route::get('/products/tagTransfer/{tagId}', 'User\DashboardController@fetchTagData');
    Route::post('/products/tagTransfer/', 'User\DashboardController@createTagData')->name('post_tag');
    Route::get('/FtUser/tagTransfer/{userID}/{tag_no}/{from_user}/{t_notes}', 'User\DashboardController@makeFtuser');
    Route::get('/trainingvideos', 'Videos\VideosController@trainingVideos')->name('training_videos');
    Route::get('/videoplayer', 'Videos\VideosController@videoPlayer')->name('videoplayer');

    Route::get('/products/historyDetails/{tagId}', 'User\ProductController@fetchProductHistoryData')->name('taghistory');

});

//Get geolocation
Route::post('/geolocation', function () {
    \Request::session()->put('locationData', \Input::get('data'));
});

//redirects to public profile of user
Route::get('/', 'Auth\LoginController@index');

//Validate password if user changes the email address
Route::post('/user/changeEmailFT', 'Profile\ProfileController@confirmPasswordForEmail');

//redirects to public profile of user
Route::get('/{uniquePin?}', 'User\UserController@index');
Route::get('/user/pin/{uniquePin}', 'Profile\PublicProfileController@showData');

//redirects to account activation link
Route::get('/activate/{encodedEmail}/{to_user?}/{tag_no?}/{from_user?}/{t_notes?}', 'User\UserController@activationValidate');
Route::post('/activate', 'User\UserController@updatePassword');

Route::get('/ftTagTransferCs/{to_user?}/{tag_no?}/{from_user?}/{t_notes?}', 'User\DashboardController@csTagNotification');

// Authentication routes...
Route::get('auth/login', 'Auth\LoginController@showLoginForm');
Route::post('auth/login', 'Auth\LoginController@login');

// Password reset link request routes...
Route::get('password/email', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password_email');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password_email');

// Password reset routes...
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.reset');

Route::get('frontUser/language-change', 'Profile\PublicProfileController@language');
Route::post('user/language-change', 'Profile\ProfileController@language');

//Finder Screen code here

Route::get('finder/finderfront', 'Finder\FinderController@show')->name('finderfront');
Route::post('finder/add', 'Finder\FinderController@add');
Route::post('finder/tagvalidation', 'Finder\FinderController@validTag');

// Show Registered User Details
Route::get('user/detailview/{userId}', 'AdminProductController@showUserDetails');

//products register
Route::get('register/products', 'Register\registerController@index');
Route::post('register/products', 'Register\registerController@checkProduct')->name('register_products');

Route::get('direct/login/{userId}/{platform}', 'Register\registerController@directLogin');
Route::get('direct/profile/{userId}/{platform}', 'Register\registerController@directLoginProfile');
Route::get('/user/backtoadmin', 'User\UserController@goBackAdminUrl');

//user register
Route::get('register/users', 'Register\registerController@showUser')->name('register_users');
Route::post('register/users', 'Register\registerController@saveUser')->name('register_users');
Route::get('register/success', 'Register\registerController@successScreen');

Route::post('user/check-email', 'Register\registerController@getEmail');
Route::post('user/check-email-registration', 'Register\registerController@getEmailRegistration');
Route::post('user/product/tagchecking', 'Finder\FinderController@getTagStatus');
Route::post('user/product/dobvalidation', 'Register\registerController@checkDob');
Route::post('user/product/mobilevalidation', 'Register\registerController@checkMobile');
Route::post('user/product/zipvalidation', 'Register\registerController@checkZip');
Route::post('user/product/sendSupportMail', 'Register\registerController@sendSupportMail');
Route::post('user/product/sendReactivationMail', 'Register\registerController@registrationReactivationMail');

Route::post('user/getTagProductDetails', 'User\ProductController@getTagProductDetails');

Route::get('/user/tagging/{userId}', 'Profile\PublicProfileController@manageTag')->name('tagging');
Route::get('/user/add/tagging/', 'Profile\PublicProfileController@insertTag');
Route::get('/user/delete/tagging/', 'Profile\PublicProfileController@deleteTag');


//After authentication access
Route::group(['middleware' => 'auth'], function () {

    // users group routes
    Route::group(['prefix' => 'user'], function () {
        //get user profile form with/without data

        Route::get('profile/{user_id?}', 'Profile\ProfileController@editUser')->name('profile');

        Route::get('add', 'Profile\ProfileController@addUser')->name('add');

        Route::post('profile', 'Profile\ProfileController@create');
        Route::put('profile', 'Profile\ProfileController@update');

        //CS Agent
        Route::get('csa', 'Profile\ProfileController@addCsa')->name('csa');
        Route::get('csa/{userId?}', 'Profile\ProfileController@editCsa')
            ->name('edit_csa');

       
        Route::get('admin/{user_id}', 'Profile\ProfileController@editAdmin')
            ->name('edit_admin');

    });

    // MANAGE EMAIL TEMPLATE
    Route::get('admin/manage-email', 'ManageEmailController@index')->name('manage_email');

    Route::get('admin/manage-email/assign-template', 'ManageEmailController@assignTemplate')->name('assign_template');;

    Route::post('admin/manage-email/assign-template', [
        'as' => 'assignTemplate', 'uses' => 'ManageEmailController@assignTemplate',
    ]);

    Route::get('admin/manage-email/add-template', 'ManageEmailController@addTemplate')->name('add_template');

    Route::get('admin/manage-email/delete-template{templateId}', [
        'as' => 'deleteTemplate', 'uses' => 'ManageEmailController@deleteTemplate',
    ]);

    Route::post('admin/manage-email/delete-template{templateId}', [
        'as' => 'postDeleteTemplate', 'uses' => 'ManageEmailController@deleteTemplate',
    ]);

    Route::get('/admin/manage-email/edit-template{templateId?}', [
        'as' => 'editTemplate', 'uses' => 'ManageEmailController@editTemplate',
    ]);

    Route::get('/admin/manage-email/activate-template{templateId}', [
        'as' => 'activateTemplate', 'uses' => 'ManageEmailController@activateTemplate',
    ]);

    Route::post('/admin/manage-email/update_template', [
        'as' => 'updateTemplate', 'uses' => 'ManageEmailController@updateTemplate',
    ]);

    Route::post('admin/manage-email/insert-template', [
        'as' => 'insertTemplate', 'uses' => 'ManageEmailController@insertTemplate',
    ]);

    Route::get('admin/product/user/{product_id}/activate', [
        'as' => 'productActivate', 'uses' => 'User\ProductController@productActivate',
    ]);

    Route::get('admin/product/user/{user_id}', [
        'as' => 'displayProduct', 'uses' => 'User\ProductController@prepareAdminProduct',
    ]);

    Route::post('admin/product/user/{user_id}/reportlost', [
        'as' => 'miscProduct', 'uses' => 'User\ProductController@productReportLost',
    ]);

    Route::post('admin/product/user/{user_id}/reactivate', [
        'as' => 'miscProduct', 'uses' => 'User\ProductController@productReactivate',
    ]);

    Route::post('admin/product/user/{user_id}', [
        'as' => 'saveProduct', 'uses' => 'User\ProductController@save',
    ]);

    Route::post('admin/FTproduct/user/{user_id}', [
        'as' => 'saveFTProduct', 'uses' => 'User\ProductController@saveFTProduct',
    ]);

    Route::get('admin/product/usersproduct/{user_id}', [
        'as' => 'displayUsersProduct', 'uses' => 'User\ProductController@prepareUsersProduct',
    ]);

    Route::post('admin/product/usersproduct/{user_id}', [
        'as' => 'displayUsersProduct2', 'uses' => 'User\ProductController@prepareUsersProduct',
    ]);
    //update delegate details

    //admin dashboard
    Route::get('admin/dashboard', 'User\DashboardController@adminShow')->name('admin_dashboard');
    //datatable ajax for admin
    Route::get('admin/data', 'Datatables\DatatablesController@dashboard');
    //Delete user
    Route::post('users/delete', 'Datatables\DatatablesController@userDelete');
    //Show CS Agents dashboard
    Route::get('agents/dashboard', 'User\DashboardController@agentShow');
    //logout
      Route::get('auth/logout', 'Auth\LoginController@logout');

    Route::get('admin/product', [
        'as' => 'product-list', 'uses' => 'AdminProductController@index',
    ]);

    Route::get('admin/product/add', 'AdminProductController@show')->name('add_product');
    Route::post('admin/product/add', 'AdminProductController@add');
    Route::get('admin/product/edit/{product_id}', 'AdminProductController@editProduct')->name('edit_product');
    Route::post('admin/product/edit/{product_id}', 'AdminProductController@updateProduct');
    Route::post('admin/product/delete/{product_id}', 'AdminProductController@deleteProduct');
    Route::post('admin/product/image', 'AdminProductController@updateProductimage');
    Route::get('admin/productavatar/{productid}', 'AdminProductController@deleteProductimage');
    Route::get('admin/order/add', 'Order\OrderController@index')->name('order');
    Route::post('admin/order/update', 'Order\OrderController@update')->name('order_update');
    Route::post('admin/order/delete', 'Order\OrderController@delete');
    Route::get('admin/order/edit/{order_id?}', 'Order\OrderController@edit')->name('edit_order');
    Route::post('admin/order/store', 'Order\OrderController@store')->name('orders');
    Route::post('admin/product/productlost/add', 'AdminProductController@productlostadd')->name('productlostadd');
    Route::post('admin/product/productsuspend/add', 'AdminProductController@productsuspendadd')->name('productsuspendadd');

    Route::get('admin/product/productlost/{product_id?}', 'AdminProductController@productlost')->name('pro_lost');

    Route::get('admin/product/usersAddDescription/{product_id}', 'AdminProductController@productdescriptionAdd')->name('productdesc');

    Route::post('admin/product/usersAddDescription/add', 'AdminProductController@productdescriptionInsert')->name('productdescadd');

    Route::get('admin/product/productsuspend/{product_id?}', 'AdminProductController@productSuspend')->name('pro_suspended');

    Route::post('admin/product/reactivate', 'AdminProductController@productreactivate');

    Route::get('admin/manageproduct/{product_id?}', [
        'as' => 'FT-product-list', 'uses' => 'AdminProductController@manageFTProducts',
    ]);
    Route::post('admin/FT/delete', 'AdminProductController@productFTdelete');

    Route::get('admin/orders/details/{product_id}', 'User\DashboardController@fetchUserData');
    Route::get('admin/reports', 'Reports\ReportsController@getReports')->name('reports_list');
    Route::get('admin/reports/loginhistory/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('login_history_report');
    Route::get('admin/reports/countrywiseusers/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('countrywise_users_report');
    Route::get('admin/reports/countrywiseusersmap/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('countrywise_usersmap_report');
    Route::get('admin/reports/membersaudit/{report_id?}/{ref_id?}', 'Reports\ReportsController@getAuditReport')->name('members_audit_report');
    Route::get('admin/reports/productregistrations/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('product_registrations_report');
    Route::get('admin/reports/userregistrations/{report_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('user_registrations_report');
    Route::get('admin/reports/usregisteredproducts/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('unregisteredproducts_report');
    Route::get('admin/reports/pendingproductsactivation/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('pendingactproducts_report');

    /* FT Chart Code Start */
    
        /* FT Units Chart Code Start */

        Route::get('admin/reports/ftunits/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('ftunits_report');
        Route::get('admin/charts/ftunits/{day?}', 'Reports\ChartsController@ftUnits');

        /* FT Units Chart Code Start */

        /* FT Order Count Chart Code Start */

        Route::get('admin/reports/ftordercount/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('ftordercount_report');
        Route::get('admin/charts/ftordercount/{day?}', 'Reports\ChartsController@ftOrderCount');

        /* FT Order Count Code Start */
        
        /* FT Order Number UID Chart Code Start */

        Route::get('admin/reports/ftordernouid/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('ftordernouid_report');
        Route::get('admin/charts/ftordernouid/{day?}', 'Reports\ChartsController@ftOrderNumberUID');

        /* FT Order Number UID Code Start */
        
        /* CS Main Chart Code Start */

        Route::get('admin/reports/csmainchart/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('csmainchart_report');
        Route::get('admin/charts/csmainchart/{day?}', 'Reports\ChartsController@CSMainChart');

        /* CS Main Chart Code Start */
        
        /* Registration Completions Chart Code Start */

        Route::get('admin/reports/registrationcomp/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('registrationcomp_report');
        Route::get('admin/charts/registrationcomp/{day?}', 'Reports\ChartsController@RegistrationCompletions');

        /* Registration Completions Chart Code Start */
        
        /* Today Chart Code Start */

        Route::get('admin/reports/today/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('today_report');
        Route::get('admin/charts/today/{day?}', 'Reports\ChartsController@Today');

        /* Today Chart Code Start */
        
        /* Registration History Column Graph Chart Code Start */

        Route::get('admin/reports/registrationhistoryc/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('registrationhistoryc_report');
        Route::get('admin/charts/registrationhistoryc/{day?}', 'Reports\ChartsController@RegistrationHistoryc');

        /* Registration History Column Graph Chart Code Start */
        
        /* Registration History Line Graph Chart Code Start */

        Route::get('admin/reports/registrationhistoryl/{report_id?}', 'Reports\ReportsController@getAuditReport')->name('registrationhistoryl_report');
        Route::get('admin/charts/registrationhistoryl/{day?}', 'Reports\ChartsController@RegistrationHistoryl');

        /* Registration History Line Graph Chart Code Start */
        
    /* FT Chart Code End */

    // Report Dashboard
    Route::get('admin/reports/data', 'Reports\ReportsController@reportdashboard');
    Route::get('admin/reports/membersdata', 'Reports\ReportsController@membersDashboard');
    Route::get('admin/reports/membersdetails/{user_id}', 'Reports\ReportsController@membersDetails');
    Route::get('admin/reports/logindata', 'Reports\ReportsController@loginHistoryDashboard');
    Route::post('admin/reports/usercountry', 'Reports\ReportsController@usersCountry');
    Route::get('admin/reports/mapdata', 'Reports\ReportsController@getLatlonbyCountry');
    Route::get('admin/reports/productsdata', 'Reports\ReportsController@productDetailsDashboard');
    Route::get('admin/reports/usersdata', 'Reports\ReportsController@userDetailsDashboard');
    Route::get('admin/reports/unregproductsdata', 'Reports\ReportsController@unregproductDetailsDashboard'); 
    Route::get('admin/reports/pendingproductsdata', 'Reports\ReportsController@pendingproductActivationDashboard');


    Route::get('user/productDetails', 'User\ProductController@productDetails')->name('product_details');

    Route::get('admin/reports/productstatusreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('productstatus_report');
    Route::get('admin/reports/productstatusdata', 'Reports\ReportsController@productStatusDashboard');
    Route::get('admin/reports/foundproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('foundproducts_report');
     Route::get('admin/reports/foundproductsdata', 'Reports\ReportsController@foundProducts');
     Route::get('admin/reports/lostproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('lostproducts_report');
     Route::get('admin/reports/lostproductsdata', 'Reports\ReportsController@lostProducts');
     Route::get('admin/reports/suspendedproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('suspendedproducts_report');
     Route::get('admin/reports/suspendedproductsdata', 'Reports\ReportsController@suspendedProducts');
     Route::get('admin/reports/lostfoundproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('lostfoundproducts_report');
     Route::get('admin/reports/lostfoundproductsdata', 'Reports\ReportsController@lostfoundProducts');
     Route::get('admin/reports/orderedproductsreport/{report_id?}/{orderstatus?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('orderedproducts_report');
      Route::get('admin/reports/orderstatusdata', 'Reports\ReportsController@orderStatusDashboard');
      Route::get('admin/reports/unregisteredproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('unregproducts_report');
      Route::get('admin/reports/unregproddata', 'Reports\ReportsController@unregProductsDashboard');

      Route::get('admin/reports/reactivatedproductsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('reactivatedproducts_report');
     Route::get('admin/reports/reactivatedproductsdata', 'Reports\ReportsController@reactivatedProducts');

     Route::get('admin/reports/registrationattemptsreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('registrations_attempt_report');
     Route::get('admin/reports/regattemptsdata', 'Reports\ReportsController@registrationAttemptsDetailsDashboard'); 

     Route::get('admin/reports/tagtransferreport/{report_id?}/{cust_id?}/{order_id?}/{todate?}/{fdate?}', 'Reports\ReportsController@getAuditReport')->name('tag_transfer_report');

     Route::get('admin/reports/tagtransferproductsdata', 'Reports\ReportsController@tagTransferDashboard'); 

});
