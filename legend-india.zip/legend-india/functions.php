<?php
/**
 * Legend India functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Legend_India
 */

if ( ! function_exists( 'legend_india_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function legend_india_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Legend India, use a find and replace
	 * to change 'legend-india' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'legend-india', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'menu-1' => esc_html__( 'Primary', 'legend-india' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'legend_india_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'legend_india_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function legend_india_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'legend_india_content_width', 640 );
}
add_action( 'after_setup_theme', 'legend_india_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function legend_india_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'legend-india' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'legend-india' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'legend_india_widgets_init' );
/**
* disable emoji 
*/
remove_action( 'wp_head', 'print_emoji_detection_script', 7 ); 
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' ); 
remove_action( 'wp_print_styles', 'print_emoji_styles' ); 
remove_action( 'admin_print_styles', 'print_emoji_styles' );
/**
 * Enqueue scripts and styles.
 */	
function legend_india_scripts() {
	
	wp_enqueue_style( 'legend-india-bootstrap', get_template_directory_uri().'/css/bootstrap.min.css' );
	wp_enqueue_style( 'legend-india-fontawesome', get_template_directory_uri().'/css/font-awesome.min.css' );
	wp_enqueue_style( 'legend-india-style', get_stylesheet_uri() );
	wp_enqueue_style( 'legend-india-railfont', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' );
	wp_enqueue_style( 'legend-india-railfont', 'https://fonts.googleapis.com/css?family=Dancing+Script:400,700' );


	wp_enqueue_script( 'legend-india-jquery', get_template_directory_uri() . '/js/jquery.1.11.1.js', array(), '', true );

	wp_enqueue_script( 'legend-india-bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '', true );
	wp_enqueue_script( 'legend-india-scroll', get_template_directory_uri() . '/js/SmoothScroll.js', array(), '', true );

	wp_enqueue_script( 'legend-india-isotope', get_template_directory_uri() . '/js/jquery.isotope.js', array(), '', true );
	wp_enqueue_script( 'legend-india-main', get_template_directory_uri() . '/js/main.js', array(), '', true );


}
add_action( 'wp_enqueue_scripts', 'legend_india_scripts' );
//add custom post for Home page slider
add_action('init', function() {
 
    $labels = array(
        'name' => _x('Home Box', 'post type general name'),
        'singular_name' => _x('Box', 'post type singular name'),
        'add_new' => _x('Add New Box image', 'Box'),
        'add_new_item' => __('Add New Box image'),
        'edit_item' => __('Edit Box image'),
        'new_item' => __('New Box'),
        'all_items' => __('All Box images'),
        'view_item' => __('View Box'),
        'search_items' => __('Search Box Images'),
        'not_found' => __('No image found'),
        'not_found_in_trash' => __('No image found in Trash'),
        'parent_item_colon' => '',
        'menu_name' => 'Home Box'        
    );
 
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'menu_icon' => 'dashicons-format-image',
        'supports' => array('title', 'editor', 'page-attributes','thumbnail','custom-fields')
    );
    register_post_type('Home Box', $args);
});


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';
