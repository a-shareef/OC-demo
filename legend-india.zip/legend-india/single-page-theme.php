<?php
    /*
        Template Name: Single Page Theme
    */

get_header(); ?>

	<?php

        $args = array("post_type" => "page", "order" => "ASC", "orderby" => "menu_order", "post__not_in" => array('70') );
        $the_query = new WP_Query($args);
    ?>

    <?php 

    if(have_posts()):
    	while($the_query->have_posts()):
    	$the_query->the_post();
        $pId = get_the_ID();

        if($pId == 7)
        {
            get_template_part( 'template-parts/content', get_post_format() );

            echo '<div id="post-70" class="post-70 page type-page status-publish hentry"><div class="container"><h3>Our Team</h3><hr /><div class="row">';
            echo '<div class="col-md-8">
                    <h5>Who we are, What we do and Why we do it.</h5>
                    <p><strong>Mohammad Ali Shaikh</strong> is truly a multi-faceted personality. By profession He is a Graphic Designer and Journalism from Garware Institute of Career Education and Development, (University of Mumbai). He has also been a journalist with publications such as Animation Today Magazine and Mumbai Today (Hindi TV News) from 2005 to 2009. He has also been contributing to various technical print and electronic media through his vast experience in Entertainment, IT and Technology. He has been associated with Garware Institute of Career Education and Development as a Teacher in 2006-2007 Kurla Kalina (University of Mumbai).</p>
                    <p>I am self employeed as a <strong>graphic designer</strong>, specializing in the fields of corporate identity <strong>logo design, web design, print design and branding</strong> with the majority of my time spent designing and implementing marketing promotions from small businessess such as logos, websites, brochures, letterhead, business cards and many more.</p>
                    <p>He has focused on making Concept that are close to grass root and address to the psyche of a commoner and therefore are close to real life. He will bring out majors in the industry through <strong>The Legend India</strong> with his vast experience of 10 years.
                    <p class="text-right"><a>40% Human, 60% Machine - 100% Creative DESIGNER</a></p>
                </div>';
            echo '<div class="col-md-4"><img src="http://localhost/legend/wp-content/uploads/2017/06/alib-278x300.png" alt="Team member" class="alignnone img-responsive" /></div>';
            echo '</div></div></div>';

        }
        elseif( $pId == 9 )
        {
            get_template_part( 'template-parts/content', 'gallery');     
        }
        elseif( $pId == 15 )
        {
            get_template_part( 'template-parts/content', 'contact');
        }
        else
        {
    	    get_template_part( 'template-parts/content', get_post_format() );        
        }
        endwhile; // End of the loop.

        endif;
    ?>

<?php
get_sidebar();
get_footer();