<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Legend_India
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top" <?php body_class(); ?>>
<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top"><img src="http://localhost/legend/wp-content/uploads/2017/06/logo_green.png"></a> </div>
    
    <!-- Collect the nav links for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
   			<?php
        $items = "";
        $args = array("post_type" => "page", "order" => "ASC", "orderby" => "menu_order", "post__not_in" => array('70'));
        $the_query = new WP_Query($args);

        if($the_query->have_posts()): 
        while($the_query->have_posts()):
        $the_query->the_post(); 
        $items .= '<li><a href="#post-'.get_the_ID().'" class="page-scroll">'.get_the_title() .'</a></li>';            
        endwhile;
        endif;
        echo $items;
        ?>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
</nav>

<!-- Header -->
<header id="header">
  <?php
      $args = array(
        'post_type' => 'Home Box',
        'numberposts' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC'        
        );

      $slider = new WP_Query($args);
      $slider = $slider->posts;      
      foreach($slider as $post)
      {
        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
  ?> 
  <div class="intro" style="background: url(<?php echo $thumb[0];?>) no-repeat center center; ">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="intro-text">
            <h1><?php echo $post->post_title; ?></h1>
            <p><?php echo $post->post_content;?></p>
            <a href="#post-7" class="btn btn-custom btn-lg page-scroll">Read More...</a> </div>
        </div>
      </div>
    </div>
  </div>
  <?php } ?>
</header>
