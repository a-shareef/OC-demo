<?php
    /*
        Template Name: gallery page
    */

    ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="section-title text-center center">
		<div class="overlay">
		<?php
		the_title( '<h2>', '</h2><hr />' );
		echo '<p>Welcome to The legend India</p>';
		?>
		</div>
	</div>
	<div class="container">
		<?php

		the_content( sprintf(
			/* translators: %s: Name of current post. */
			wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'legend-india' ), array( 'span' => array( 'class' => array() ) ) ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
			) );

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'legend-india' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
</div><!-- #post-## -->    