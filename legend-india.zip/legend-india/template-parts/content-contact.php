<?php
    /*
        Template Name: contact page
    */

    ?>
	<div id="call-reservation" class="text-center">
  		<div class="container">
    		<h2>Do you have any query?&nbsp;&nbsp; Call us:&nbsp; <strong>+91-99874 86635</strong></h2>
  		</div>
	</div>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container">
		<?php

		the_content( sprintf(
			/* translators: %s: Name of current post. */
			wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'legend-india' ), array( 'span' => array( 'class' => array() ) ) ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
			) );

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'legend-india' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
</div><!-- #post-## contact-->

	